<?php
// This single line handles everything: settings, session, db
require_once '../init.php'; 
include 'header.php';
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .page-header-minimal {
        text-align: center;
        padding: 50px 20px;
        background-color: #f8f9fa;
        border-bottom: 1px solid #eee;
    }
    .page-header-minimal h1 {
        font-size: 36px;
        color: #1a253c;
        margin: 0;
    }
    .content-panel {
        background-color: #fff;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 5px 25px rgba(0,0,0,0.05);
        margin-top: 40px;
        font-size: 16px;
        line-height: 1.8;
    }
    .content-panel h2, .content-panel h3 {
        margin-top: 20px;
        color: #333;
    }
    .content-panel ul, .content-panel ol {
        padding-left: 20px;
    }
</style>

<div class="page-header-minimal">
    <h1>Terms & Conditions</h1>
</div>

<div class="container" style="padding-bottom: 50px;">
    <div class="content-panel">
        <?php 
            // Output the content directly from site settings. 
            // The nl2br() function converts new lines from the textarea into <br> tags for proper formatting.
            echo nl2br($site_settings->terms_conditions ?? 'Terms and Conditions content is not available yet. Please check back later.'); 
        ?>
    </div>
</div>

<?php include 'footer.php'; ?>