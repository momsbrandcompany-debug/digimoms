<?php
// The new, single line that handles everything
require_once '../init.php';

// Get the product ID from the URL...
// ... (rest of the code)
$slug = $_GET['slug'] ?? '';
// Fetch single post by slug
$stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE slug = :slug AND status = 'Published'");
$stmt->execute(['slug' => $slug]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) { die('Article not found.'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo htmlspecialchars($post['title']); ?> - DigiMoms</title>
</head>
<body>
    <!-- Navbar -->
    <main class="container section">
        <h1><?php echo htmlspecialchars($post['title']); ?></h1>
        <img src="../public/uploads/blog_images/<?php echo $post['featured_image']; ?>" alt="" style="max-width:100%; height:auto;">
        
        <!-- Adsterra Ad Placeholder -->
        <div style="margin: 20px auto; text-align: center;">
             <!-- Your Adsterra Ad Code Here -->
             <p>[Adsterra In-article Ad Placeholder]</p>
        </div>
        
        <div class="article-body">
            <?php echo $post['content']; // Outputting raw HTML from a trusted source (admin) ?>
        </div>
    </main>
    <!-- Footer -->
</body>
</html>