<?php
include 'header.php';
// Security check and fetch video link from database based on purchase history
// ... (We will add full security logic later) ...
$video_link = "https://www.youtube.com/embed/VIDEO_ID"; // Placeholder
?>
<div class="container section">
    <h1>Watching Course: [Course Title]</h1>
    <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
        <iframe src="<?php echo $video_link; ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" frameborder="0" allowfullscreen></iframe>
    </div>
</div>
<?php include 'footer.php'; ?>