<?php
// This single line now handles session, db connection, and cookies
require_once '../init.php';
// The header is included after init.php
include 'header.php';

// Fetch latest 8 products for the featured section
// ... rest of the code (no changes needed here)

// Fetch latest products
try {
    $stmt = $pdo->query("SELECT * FROM products WHERE status = 'Active' ORDER BY created_at DESC LIMIT 8");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $products = [];
}
?>

<style>
    /* Hero Section - NEW PRODUCT-FOCUSED BANNER */
    .hero {
        background-image: url('https://images.unsplash.com/photo-1587620962725-abab7fe55159?q=80&w=1931&auto=format&fit=crop');
        background-size: cover;
        background-position: center 30%; /* Focuses more on the laptop screen */
        padding: 100px 0;
        text-align: center;
    }
    .hero-content { background-color: rgba(0, 0, 0, 0.5); display: inline-block; padding: 40px; border-radius: 15px; }
    .hero-content h1 { font-size: 48px; color: #ffffff; margin: 0 0 15px 0; }
    .hero-content p { font-size: 18px; color: #f0f0f0; }

    /* Search Bar */
    .search-bar { width: 100%; max-width: 500px; padding: 15px 25px; font-size: 16px; border-radius: 50px; border: 1px solid #ddd; }
    .search-button { padding: 15px 30px; border: none; background-color: #007bff; color: white; border-radius: 50px; margin-left: -55px; cursor: pointer; }
    
    /* General Section Styles */
    .section { padding: 60px 0; }
    .section.bg-light { background-color: #f8f9fa; }
    .section-title { text-align: center; font-size: 36px; margin-bottom: 10px; color: #1a253c; font-weight: 700; }
    .section-subtitle { text-align: center; font-size: 18px; color: #555; margin-bottom: 40px; max-width: 600px; margin-left: auto; margin-right: auto; }

    /* Trust Section - NEW */
    .trust-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; text-align: center; }
    .trust-card { background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.07); }
    .trust-card .icon { font-size: 48px; color: #007bff; margin-bottom: 15px; }
    .trust-card h3 { font-size: 22px; color: #1a253c; }

    /* Products Grid */
    .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px; }
    .product-card { background-color: #fff; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); text-align: center; overflow: hidden; transition: transform 0.3s; }
    .product-card:hover { transform: translateY(-5px); }
    .product-card img { width: 100%; height: 220px; object-fit: cover; }
    .product-card .content { padding: 20px; }
    .product-card h3 { font-size: 20px; margin: 0 0 10px 0; color: #333; }
    .product-card .price { font-size: 22px; font-weight: bold; color: #28a745; }

    /* Partner Program Section (Extra Feature) */
    .partner-section { text-align: center; }
    .partner-section .highlight { color: #28a745; font-weight: 700; }
</style>

<!-- Hero Section -->
<header class="hero">
    <div class="hero-content">
        <h1>High-Quality Digital Products to Fuel Your Growth</h1>
        <p>From professional courses to ready-to-use templates, find everything you need here.</p>
        <div class="search-bar-container" style="margin-top:30px;">
            <form action="search.php" method="GET">
                <input type="text" name="query" class="search-bar" placeholder="e.g., 'PHP Course' or 'Resume Template'" required>
                <button type="submit" class="search-button">Search</button>
            </form>
        </div>
    </div>
</header>

<!-- Trust Section - NEW -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Why Choose Our Products?</h2>
        <p class="section-subtitle">We are committed to providing value and ensuring a seamless experience for our customers.</p>
        <div class="trust-grid">
            <div class="trust-card">
                <div class="icon">&#128142;</div> <!-- Diamond Icon -->
                <h3>Expert-Crafted Content</h3>
                <p>All our products are created by industry experts to ensure the highest quality and relevance.</p>
            </div>
            <div class="trust-card">
                <div class="icon">&#9889;</div> <!-- Lightning Icon -->
                <h3>Instant & Easy Access</h3>
                <p>Get your digital products immediately after purchase. No waiting, no complex procedures.</p>
            </div>
            <div class="trust-card">
                <div class="icon">&#128737;</div> <!-- Shield Icon -->
                <h3>100% Secure Checkout</h3>
                <p>Your payments are processed through a secure and trusted gateway, keeping your data safe.</p>
            </div>
        </div>
    </div>
</section>

<!-- Featured Products Section -->
<section class="section bg-light">
    <div class="container">
        <h2 class="section-title">Our Featured Products</h2>
        <p class="section-subtitle">A collection of our most popular and highly-rated digital goods.</p>
        <div class="products-grid">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <a href="product.php?id=<?php echo $product['id']; ?>" class="product-card">
                        <img src="../<?php echo htmlspecialchars($product['thumbnail']); ?>" alt="<?php echo htmlspecialchars($product['title']); ?>">
                        <div class="content">
                            <h3><?php echo htmlspecialchars($product['title']); ?></h3>
                            <div class="price">₹<?php echo htmlspecialchars($product['sale_price']); ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="grid-column: 1 / -1; text-align: center;">Featured products will be available soon.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Extra Feature: Partner Program -->
<section class="section">
    <div class="container partner-section">
        <h2 class="section-title">Extra Feature: Join Our Partner Program</h2>
        <p class="section-subtitle">Love our products? Share them and earn a significant income. It's a win-win situation!</p>
        <p style="font-size: 18px; max-width: 700px; margin: 0 auto 30px auto;">
            As a partner, you can earn a <span class="highlight">60% commission</span> on every sale you refer. Plus, build a team and get a <span class="highlight">10% lifetime commission</span> from their sales. We also provide opportunities to host your own paid seminars.
        </p>
        <a href="become_partner.php" style="background-color: #28a745; color: white; padding: 15px 35px; border-radius: 50px; font-size: 18px; font-weight: 600;">Learn More About Partnership</a>
    </div>
</section>

<?php
// Include the footer file
include 'footer.php';
?>