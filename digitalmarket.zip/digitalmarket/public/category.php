<?php
require_once '../db_config.php';
require_once '../config.php'; // Including our new config file
$category_name = $_GET['name'] ?? 'Unknown';
try {
    $stmt = $pdo->prepare("SELECT id, title, sale_price, market_price, thumbnail FROM products WHERE status = 'Active' AND category = :category ORDER BY created_at DESC");
    $stmt->bindParam(':category', $category_name, PDO::PARAM_STR);
    $stmt->execute();
    $products_in_category = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { die("Error: " . $e->getMessage()); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category: <?php echo htmlspecialchars($category_name); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar"><!-- ... Navbar ... --></nav>
    <main class="section container">
        <h1 class="page-title">Category: <?php echo htmlspecialchars($category_name); ?></h1>
        <div class="products-grid">
            <?php if (count($products_in_category) > 0): ?>
                <?php foreach ($products_in_category as $product): ?>
                    <a href="product_details.php?id=<?php echo $product['id']; ?>" class="product-card">
                        <!-- THE FIX: Using BASE_URL for the image path -->
                        <img src="<?php echo BASE_URL . htmlspecialchars($product['thumbnail']); ?>" alt="<?php echo htmlspecialchars($product['title']); ?>">
                        <div class="product-content">
                           <!-- ... content ... -->
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?><p>No products found in this category.</p><?php endif; ?>
        </div>
    </main>
</body>
</html>