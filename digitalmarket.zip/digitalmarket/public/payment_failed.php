<?php include 'header.php'; ?>
<div style="text-align:center; padding: 50px;">
    <h1 style="color:#dc3545;">&#10060; Payment Failed</h1>
    <p>Your transaction could not be completed. Please try again.</p>
    <a href="index.php">Back to Homepage</a>
</div>
<?php include 'footer.php'; ?>