</main>
    
    <footer style="padding: 60px 0 20px 0; background-color: #1a253c; color: #ccc;">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 40px; text-align: left; margin-bottom: 40px;">
                <div class="footer-col">
                    <h4 style="color: #fff;"><?php echo htmlspecialchars($site_settings->website_name ?? 'DigiMoms'); ?></h4>
                    <p>Your mission statement or short about text.</p>
                </div>
                <div class="footer-col">
                    <h4 style="color: #fff;">Quick Links</h4>
                    <p><a href="privacy.php" style="color:#ccc;">Privacy Policy</a></p>
                    <p><a href="terms.php" style="color:#ccc;">Terms & Conditions</a></p>
                    <p><a href="refund.php" style="color:#ccc;">Refund Policy</a></p>
                </div>
                <div class="footer-col">
                    <h4 style="color: #fff;">Contact Us</h4>
                    <p>Email: <?php echo htmlspecialchars($site_settings->contact_email ?? ''); ?></p>
                    <p>WhatsApp: <?php echo htmlspecialchars($site_settings->contact_phone ?? ''); ?></p>
                </div>
            </div>
            <div style="text-align: center; border-top: 1px solid #344059; padding-top: 20px;">
                &copy; <?php echo date("Y"); ?> <?php echo htmlspecialchars($site_settings->website_name ?? 'DigiMoms'); ?>. All Rights Reserved.
            </div>
        </div>
    </footer>

</body>
</html>