<?php
require_once '../init.php';
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
if ($product_id == 0) { header("Location: index.php"); exit; }
try {
    $stmt = $pdo->prepare("SELECT title, category, download_file_link FROM products WHERE id = :id");
    $stmt->execute(['id' => $product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$product) { header("Location: index.php"); exit; }
} catch (PDOException $e) { die("Database error."); }
include 'header.php';
$is_logged_in = (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true);
?>
<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .success-body { background-color: #f4f7fa; padding: 50px 0; display: flex; align-items: center; justify-content: center; min-height: 60vh; }
    .success-panel { background-color: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 5px 25px rgba(0,0,0,0.08); text-align: center; max-width: 500px; margin: auto; }
    .success-icon { font-size: 60px; color: #28a745; }
    .success-panel h1 { font-size: 28px; margin: 20px 0 10px 0; }
    .success-panel p { color: #555; font-size: 16px; line-height: 1.6; }
    .action-button { display: inline-block; margin-top: 20px; padding: 15px 30px; color: white !important; font-size: 18px; text-decoration: none; border-radius: 50px; }
    .btn-download { background: #28a745; }
    .btn-account { background: #007bff; }
    .home-link { margin-top: 20px; display: block; color: #007bff; }
</style>
<div class="success-body">
    <div class="success-panel">
        <div class="success-icon">&#10004;</div>
        <h1>Purchase Successful!</h1>
        <p>Thank you for your order of <strong>"<?php echo htmlspecialchars($product['title']); ?>"</strong>.</p>
        <?php 
        if ($is_logged_in) {
            echo '<p>You can access your item from your "My Account" page.</p>';
            echo '<a href="my_account.php" class="action-button btn-account">Go to My Order History</a>';
        } else {
            if ($product['category'] !== 'Courses') {
                echo '<p>Your download is ready! Click the button below.</p>';
                $download_url = rtrim(BASE_URL, '/') . '/' . str_replace('../', '', $product['download_file_link']);
                echo '<a href="' . htmlspecialchars($download_url) . '" class="action-button btn-download" download>Download Now</a>';
            }
        }
        ?>
        <a href="index.php" class="home-link">Back to Homepage</a>
    </div>
</div>
<?php include 'footer.php'; ?>