<?php
// This single line handles everything we need to start
require_once '../init.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Diagnostic Tool</title>
    <style>
        body { font-family: monospace; background-color: #f4f7f6; padding: 20px; }
        .panel { background-color: #fff; border: 1px solid #ddd; border-radius: 8px; margin-bottom: 20px; }
        .panel-header { background-color: #e9ecef; padding: 10px 15px; font-weight: bold; border-bottom: 1px solid #ddd; }
        .panel-body { padding: 15px; }
        .check { display: flex; align-items: center; margin-bottom: 10px; font-size: 16px; }
        .check .label { width: 300px; }
        .check .value { font-weight: bold; }
        .status-ok { color: #28a745; }
        .status-error { color: #dc3545; }
        .db-result { background-color: #f8f9fa; padding: 10px; border: 1px solid #ccc; margin-top: 10px; white-space: pre-wrap; word-wrap: break-word; }
    </style>
</head>
<body>
    <h1>System State Diagnostic Tool</h1>
    <p>This tool helps us understand the current state of the system to find the root cause of the problem.</p>

    <!-- Session State Panel -->
    <div class="panel">
        <div class="panel-header">1. Session Status</div>
        <div class="panel-body">
            <div class="check">
                <span class="label">User Logged In Status:</span>
                <?php if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true): ?>
                    <span class="value status-ok">LOGGED IN</span>
                <?php else: ?>
                    <span class="value status-error">NOT LOGGED IN</span>
                <?php endif; ?>
            </div>
            <div class="check">
                <span class="label">User ID in Session:</span>
                <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): ?>
                    <span class="value status-ok"><?php echo htmlspecialchars($_SESSION['user_id']); ?></span>
                <?php else: ?>
                    <span class="value status-error">NOT SET</span>
                <?php endif; ?>
            </div>
            <div class="check">
                <span class="label">User Mobile in Session:</span>
                <?php if (isset($_SESSION['user_mobile']) && !empty($_SESSION['user_mobile'])): ?>
                    <span class="value status-ok"><?php echo htmlspecialchars($_SESSION['user_mobile']); ?></span>
                <?php else: ?>
                    <span class="value status-error">NOT SET</span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Database Query Panel -->
    <div class="panel">
        <div class="panel-header">2. Purchase History Database Check</div>
        <div class="panel-body">
            <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): 
                $user_id_for_debug = $_SESSION['user_id'];
            ?>
                <p>Checking the `sales` table for a user with ID: <strong><?php echo $user_id_for_debug; ?></strong></p>
                <?php
                try {
                    $stmt_debug = $pdo->prepare("SELECT COUNT(*) FROM sales WHERE buyer_id = :user_id");
                    $stmt_debug->execute(['user_id' => $user_id_for_debug]);
                    $purchase_count = $stmt_debug->fetchColumn();

                    if ($purchase_count > 0) {
                        echo "<div class='check'><span class='label'>Result:</span> <span class='value status-ok'>SUCCESS! Found " . $purchase_count . " purchase(s) for this user in the database.</span></div>";
                        
                        // Let's fetch the actual data
                        $stmt_data = $pdo->prepare("SELECT s.id as sale_id, s.product_id, p.title FROM sales s JOIN products p ON s.product_id = p.id WHERE s.buyer_id = :user_id");
                        $stmt_data->execute(['user_id' => $user_id_for_debug]);
                        $purchases_debug = $stmt_data->fetchAll(PDO::FETCH_ASSOC);
                        echo "<div class='db-result'><strong>Data Found:</strong><br>" . print_r($purchases_debug, true) . "</div>";

                    } else {
                        echo "<div class='check'><span class='label'>Result:</span> <span class='value status-error'>FAILURE! Found 0 purchases for this user in the database.</span></div>";
                        echo "<p><strong>Possible Reason:</strong> The `buyer_id` in the `sales` table is not being set correctly when a purchase is made.</p>";
                    }
                } catch (PDOException $e) {
                    echo "<div class='check'><span class='label'>Result:</span> <span class='value status-error'>DATABASE ERROR!</span></div>";
                    echo "<div class='db-result'>Error Message: " . $e->getMessage() . "</div>";
                }
            else:
            ?>
                <p class="status-error">Cannot check database because User ID is not set in the session.</p>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>