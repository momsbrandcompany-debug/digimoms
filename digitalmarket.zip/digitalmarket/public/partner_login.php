<?php
session_start();
// If partner is already logged in, redirect to their dashboard
if (isset($_SESSION["partner_loggedin"]) && $_SESSION["partner_loggedin"] === true) {
    header("location: ../partner/index.php");
    exit;
}

require_once '../db_config.php';

$mobile = $password = "";
$login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile = trim($_POST["mobile"]);
    $password = trim($_POST["password"]);

    if (empty($mobile) || empty($password)) {
        $login_err = "Please enter mobile and password.";
    } else {
        $sql = "SELECT id, name, password, status FROM partners WHERE mobile = :mobile";
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":mobile", $mobile, PDO::PARAM_STR);
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        // CRITICAL: Check if partner status is 'Approved'
                        if ($row["status"] !== 'Approved') {
                            $login_err = "Your account is not approved yet or has been blocked.";
                        } elseif (password_verify($password, $row["password"])) {
                            // Password is correct, start a new session
                            session_start();
                            $_SESSION["partner_loggedin"] = true;
                            $_SESSION["partner_id"] = $row["id"];
                            $_SESSION["partner_name"] = $row["name"];
                            header("location: ../partner/dashboard.php");
                        } else {
                            $login_err = "Invalid mobile number or password.";
                        }
                    }
                } else {
                    $login_err = "Invalid mobile number or password.";
                }
            } else {
                echo "Oops! Something went wrong.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Partner Login</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7f6; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .wrapper { width: 360px; padding: 30px; background-color: #fff; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #28a745; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        .btn { padding: 12px; width: 100%; border-radius: 5px; border: none; color: white; background-color: #28a745; font-size: 16px; cursor: pointer; }
        .btn:hover { background-color: #218838; }
        .alert { padding: 10px; color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px; margin-bottom: 15px; text-align: center;}
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Partner Login</h2>
        <?php if(!empty($login_err)) echo '<div class="alert">' . $login_err . '</div>'; ?>
        <form action="partner_login.php" method="post">
            <div class="form-group">
                <label>Mobile Number</label>
                <input type="text" name="mobile" class="form-control" required>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <input type="submit" class="btn" value="Login">
            </div>
             <p style="text-align:center;">Not a partner yet? <a href="become_a_partner.php">Register here</a></p>
        </form>
    </div>
</body>
</html>