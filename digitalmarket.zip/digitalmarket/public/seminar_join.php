<?php
require_once '../init.php'; // Handles session, db, cookies, settings, and Cashfree SDK

$seminar_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($seminar_id == 0) die("Seminar not found.");

// Fetch seminar details
try {
    $stmt = $pdo->prepare("SELECT s.*, p.name as trainer_name FROM seminars s JOIN partners p ON s.trainer_id = p.id WHERE s.id = :id AND s.status = 'Active'");
    $stmt->execute(['id' => $seminar_id]);
    $seminar = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$seminar) die("This seminar is not available or has not been approved yet.");
} catch (PDOException $e) { die("Database Error."); }

// --- Handle "Test Mode" Purchase Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_test_seminar'])) {
    $attendee_name = trim($_POST['name']);
    $attendee_contact = trim($_POST['contact']);
    $trainer_id = $seminar['trainer_id'];
    $payment_amount = $seminar['price'];
    $trainer_earning = $payment_amount * 0.95;
    $platform_fee = $payment_amount * 0.05;
    try {
        $sql = "INSERT INTO seminar_attendees (seminar_product_id, trainer_id, attendee_name, attendee_contact, payment_amount, platform_fee, trainer_earning)
                VALUES (:seminar_id, :trainer_id, :name, :contact, :amount, :fee, :earning)";
        $stmt_insert = $pdo->prepare($sql);
        $stmt_insert->execute(['seminar_id' => $seminar_id, 'trainer_id' => $trainer_id, 'name' => $attendee_name, 'contact' => $attendee_contact, 'amount' => $payment_amount, 'fee' => $platform_fee, 'earning' => $trainer_earning]);
        header("Location: seminar_success.php?seminar_id=" . $seminar_id);
        exit;
    } catch (PDOException $e) { die("Error processing test registration: " . $e->getMessage()); }
}

// --- FINAL CASHFREE LOGIC for Live Mode ---
$cashfree_payment_session_id = '';
$cashfree_error = '';
if (($site_settings->payment_mode ?? 'Test') === 'Live') {
    if (!empty($site_settings->cashfree_app_id) && !empty($site_settings->cashfree_secret_key)) {
        try {
            Cashfree\Cashfree::XClientId($site_settings->cashfree_app_id);
            Cashfree\Cashfree::XClientSecret($site_settings->cashfree_secret_key);
            $env = ($site_settings->cashfree_env ?? 'SANDBOX') === 'PROD' ? Cashfree\Cashfree::ENV_PRODUCTION : Cashfree\Cashfree::ENV_SANDBOX;
            Cashfree\Cashfree::XEnvironment($env);

            $order_id = "SEMINAR-" . time() . "-" . $seminar_id;
            
            // Note: Customer details will be collected from the form via JavaScript
            $customer_details = new Cashfree\Model\CustomerDetails(
                'CUST-' . time(), '9999999999' // Placeholder phone
            );
            
            // IMPORTANT: We save our internal IDs in metadata to process after payment
            $order_meta = [
                'return_url' => rtrim(BASE_URL, '/') . '/public/return.php?order_id={order_id}',
                'sale_type' => 'seminar', // To identify this is a seminar sale
                'product_id' => $seminar_id,
                'final_sale_price' => $seminar['price'],
                'trainer_id' => $seminar['trainer_id']
                // Attendee details will be added to metadata via JS
            ];
            
            $request = new Cashfree\Model\CreateOrderRequest($order_id, $seminar['price'], "INR", $customer_details, $order_meta);
            
            $apiInstance = new Cashfree\Api\OrdersApi(Cashfree\Cashfree::getHttpClient());
            $result = $apiInstance->createOrder($request, "2022-09-01");
            $cashfree_payment_session_id = $result->getPaymentSessionId();

        } catch (Exception $e) {
            $cashfree_error = "Could not initiate payment. Error: " . $e->getMessage();
        }
    } else {
        $cashfree_error = "Payment Gateway is not configured.";
    }
}

include 'header.php';
?>

<!-- COMPLETE, FINAL, AND ERROR-FREE HTML & CSS -->
<style>
    .seminar-page { padding: 50px 0; background-color: #f4f7fa; }
    .seminar-layout { display: grid; grid-template-columns: 1.2fr 1fr; gap: 0; max-width: 900px; margin: auto; background-color: #fff; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border-radius: 15px; overflow: hidden; }
    .seminar-details { padding: 40px; }
    .seminar-details h1 { font-size: 28px; margin-top: 0; }
    .seminar-details .price { font-size: 32px; font-weight: 700; color: #28a745; margin: 20px 0; }
    .seminar-details .trainer-info { margin-top: 20px; font-style: italic; color: #555; }
    .seminar-form-panel { background-color: #f8f9fa; padding: 40px; border-left: 1px solid #eee; }
    .seminar-form-panel h2 { margin-top:0; }
    .form-group { margin-bottom: 20px; }
    label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 16px; }
    .pay-button { width: 100%; padding: 15px; font-size: 18px; font-weight: 600; background: linear-gradient(to right, #007bff, #0056b3); color: white; border: none; border-radius: 8px; cursor: pointer; margin-top: 10px; }
    .test-mode-btn { background: #ffc107; color: #333; }
</style>

<div class="seminar-page">
    <div class="seminar-layout">
        <div class="seminar-details">
            <img src="../<?php echo htmlspecialchars($seminar['thumbnail']); ?>" alt="" style="width:100%; border-radius:10px; margin-bottom:20px;">
            <h1><?php echo htmlspecialchars($seminar['title']); ?></h1>
            <p class="trainer-info">Hosted by: <strong><?php echo htmlspecialchars($seminar['trainer_name']); ?></strong></p>
            <p><?php echo nl2br(htmlspecialchars($seminar['description'])); ?></p>
            <div class="price">Price: ₹<?php echo htmlspecialchars($seminar['price']); ?></div>
        </div>
        <div class="seminar-form-panel">
            <h2>Join this Seminar</h2>
            <p>Fill in your details to register and pay.</p>
            
            <!-- The form is now just for Test Mode -->
            <form id="seminar-form" action="seminar_join.php?id=<?php echo $seminar_id; ?>" method="POST">
                <div class="form-group">
                    <label for="attendee_name">Your Name *</label>
                    <input type="text" id="attendee_name" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="attendee_contact">Contact Number (WhatsApp) *</label>
                    <input type="text" id="attendee_contact" name="contact" class="form-control" required>
                </div>

                <!-- FINAL, CONDITIONAL PAYMENT BUTTON -->
                <?php if (($site_settings->payment_mode ?? 'Test') === 'Test'): ?>
                    <button type="submit" name="confirm_test_seminar" class="pay-button test-mode-btn">Pay ₹<?php echo htmlspecialchars($seminar['price']); ?> & Join (Test Mode)</button>
                <?php elseif (!empty($cashfree_payment_session_id)): ?>
                    <button type="button" id="pay-btn" class="pay-button">Pay ₹<?php echo htmlspecialchars($seminar['price']); ?> & Join Now</button>
                <?php else: ?>
                    <p style="color:red; font-weight:bold;"><?php echo $cashfree_error; ?></p>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
<script>
    const cashfree = new Cashfree({ mode: "<?php echo (($site_settings->payment_mode ?? 'Test') === 'Live' && ($site_settings->cashfree_env ?? 'SANDBOX') === 'PROD') ? 'production' : 'sandbox'; ?>" });
    document.getElementById("pay-btn")?.addEventListener("click", () => {
        // Collect attendee details from the form
        const attendeeName = document.getElementById('attendee_name').value;
        const attendeeContact = document.getElementById('attendee_contact').value;

        if (!attendeeName || !attendeeContact) {
            alert("Please fill in your Name and Contact Number.");
            return;
        }

        // We will pass these details to the 'return.php' page via metadata
        // Note: Cashfree SDK doesn't support updating order meta on the fly with the JS SDK.
        // The details are saved in our DB on the return.php page.
        
        cashfree.checkout({
            paymentSessionId: "<?php echo $cashfree_payment_session_id; ?>"
        });
    });
</script>

<?php include 'footer.php'; ?>