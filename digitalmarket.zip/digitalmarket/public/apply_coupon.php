<?php
require_once '../init.php'; // Handles session, db connection etc.

header('Content-Type: application/json');

$coupon_code = isset($_POST['coupon_code']) ? strtoupper(trim($_POST['coupon_code'])) : '';
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

if (empty($coupon_code) || $product_id == 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid coupon or product.']);
    exit;
}

try {
    $stmt_product = $pdo->prepare("SELECT sale_price FROM products WHERE id = :id");
    $stmt_product->execute(['id' => $product_id]);
    $product = $stmt_product->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'Product not found.']);
        exit;
    }

    $original_price = $product['sale_price'];

    $stmt_coupon = $pdo->prepare(
        "SELECT * FROM coupons 
         WHERE coupon_code = :code AND status = 'Active' AND (product_id = :product_id OR product_id IS NULL)"
    );
    $stmt_coupon->execute(['code' => $coupon_code, 'product_id' => $product_id]);
    $coupon = $stmt_coupon->fetch(PDO::FETCH_ASSOC);

    if ($coupon) {
        $discount_value = $coupon['discount_value'];
        $discount_amount = ($original_price * $discount_value) / 100;
        $final_price = $original_price - $discount_amount;

        echo json_encode([
            'success' => true,
            'message' => 'Coupon applied successfully!',
            'discount_amount' => number_format($discount_amount, 2),
            'final_price' => number_format($final_price, 2)
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired coupon.']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error.']);
}
?>