<?php
// Initialize the session
session_start();

// If user is already logged in, redirect them to their account page
if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true) {
    header("location: my_account.php");
    exit;
}

require_once "../db_config.php";

$mobile = $password = "";
$mobile_err = $password_err = $login_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if mobile is empty
    if (empty(trim($_POST["mobile"]))) {
        $mobile_err = "Please enter your mobile number.";
    } else {
        $mobile = trim($_POST["mobile"]);
    }
    
    // Check if password is empty
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if (empty($mobile_err) && empty($password_err)) {
        $sql = "SELECT id, mobile, password FROM users WHERE mobile = :mobile";
        
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":mobile", $param_mobile, PDO::PARAM_STR);
            $param_mobile = $mobile;
            
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        $id = $row["id"];
                        $hashed_password = $row["password"];
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["user_loggedin"] = true;
                            $_SESSION["user_id"] = $id;
                            $_SESSION["user_mobile"] = $mobile;                            
                            
                            // Redirect user to the home page
                            header("location: index.php");
                        } else {
                            $login_err = "Invalid mobile number or password.";
                        }
                    }
                } else {
                    $login_err = "No account found with that mobile number.";
                }
            } else {
                $login_err = "Oops! Something went wrong. Please try again.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7f6; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .wrapper { width: 380px; padding: 30px; background-color: #fff; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #0056b3; margin-top: 0; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        .help-block { color: #dc3545; font-size: 13px; }
        .btn { padding: 12px; width: 100%; border: none; color: white; background-color: #007bff; font-size: 16px; cursor: pointer; border-radius: 5px; }
        .alert { padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center; }
        .alert-danger { background-color: #f8d7da; color: #721c24; }
        .alert-success { background-color: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Customer Login</h2>
        <p>Please enter your credentials to login.</p>
        
        <?php 
        if (!empty($login_err)) {
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        if (isset($_GET['status']) && $_GET['status'] == 'registered') {
            echo '<div class="alert alert-success">Registration successful! Please login to continue.</div>';
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Mobile Number</label>
                <input type="text" name="mobile" class="form-control" value="<?php echo $mobile; ?>">
                <span class="help-block"><?php echo $mobile_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn" value="Login">
            </div>
            <p style="text-align:center;">
                <a href="forgot_password.php">Forgot Password?</a>
            </p>
            <p style="text-align:center;">
                Don't have an account? <a href="register.php">Sign up now</a>.
            </p>
        </form>
    </div>
</body>
</html>