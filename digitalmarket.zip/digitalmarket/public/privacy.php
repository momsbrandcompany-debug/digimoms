<?php
require_once '../init.php';
include 'header.php';
?>
<div class="container" style="padding: 40px 0;">
    <h1>Privacy Policy</h1>
    <div style="background-color:#fff; padding:30px; border-radius:10px; line-height:1.7;">
        <?php echo $site_settings->privacy_policy ?? 'Content not available.'; ?>
    </div>
</div>
<?php include 'footer.php'; ?>