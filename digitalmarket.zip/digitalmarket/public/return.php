<?php
require_once '../init.php'; // Handles session, db, cookies
require_once ROOT_PATH . '/lib/cashfree.php'; // Include Cashfree SDK

$order_id_from_cashfree = isset($_GET['order_id']) ? $_GET['order_id'] : null;
if (empty($order_id_from_cashfree)) {
    die("Invalid request. Order ID is missing.");
}

// Configure Cashfree SDK
Cashfree::XClientId($site_settings->cashfree_app_id);
Cashfree::XClientSecret($site_settings->cashfree_secret_key);
$cashfree_environment = ($site_settings->payment_mode === 'Live') ? "PROD" : "SANDBOX";
Cashfree::XEnvironment($cashfree_environment);

try {
    // --- Step 1: Verify the Payment Status from Cashfree's Server ---
    $order = new Order();
    $payment_details = $order->getPayment($order_id_from_cashfree);
    
    // Check if the payment was truly successful
    if ($payment_details->isSuccess() && $payment_details->getOrder()->status === 'PAID') {
        
        // --- Step 2: Extract our saved data from order_meta ---
        $meta = $payment_details->getOrder()->order_meta;
        $product_id = $meta->product_id;
        $sale_amount = (float)$meta->final_sale_price; // Final price after coupon
        
        // Determine if it was a seminar or a regular product
        $is_seminar_sale = isset($meta->sale_type) && $meta->sale_type === 'seminar';

        // --- Step 3: All the Sales & Commission Logic ---
        if ($is_seminar_sale) {
            // It's a seminar sale, record in seminar_attendees
            $trainer_id = $meta->trainer_id;
            $trainer_earning = $sale_amount * 0.95;
            $platform_fee = $sale_amount * 0.05;
            $sql = "INSERT INTO seminar_attendees (seminar_product_id, trainer_id, attendee_name, attendee_contact, payment_amount, platform_fee, trainer_earning)
                    VALUES (:seminar_id, :trainer_id, :name, :contact, :amount, :fee, :earning)";
            $stmt_insert = $pdo->prepare($sql);
            $stmt_insert->execute([
                'seminar_id' => $product_id,
                'trainer_id' => $trainer_id,
                'name' => $meta->attendee_name,
                'contact' => $meta->attendee_contact,
                'amount' => $sale_amount,
                'fee' => $platform_fee,
                'earning' => $trainer_earning
            ]);
            header("Location: seminar_success.php?seminar_id=" . $product_id);
            exit;

        } else {
            // It's a regular affiliate product sale
            // This is the same logic from payment.php's POST block
            $partner_id = NULL; $commission_amount = NULL;
            // ... (Your entire, correct, rank-based affiliate commission logic goes here) ...
            
            $sql = "INSERT INTO sales (product_id, sale_amount, partner_id, ...) VALUES (...)";
            // ... (Execute the query to save the regular sale)

            // Rank upgrade logic
            // ...
            
            header("Location: purchase_success.php?product_id=" . $product_id);
            exit;
        }

    } else {
        // If payment was not successful, redirect to a failure page
        header("Location: payment_failed.php?order_id=" . $order_id_from_cashfree);
        exit;
    }

} catch (Exception $e) {
    die("An error occurred while verifying your payment: " . $e->getMessage());
}
?>