<?php
// This single line handles everything: settings, session, db
require_once '../init.php'; 
include 'header.php';
?>

<!-- We can re-use the same CSS from the terms.php page -->
<style>
    .page-header-minimal { text-align: center; padding: 50px 20px; background-color: #f8f9fa; border-bottom: 1px solid #eee; }
    .page-header-minimal h1 { font-size: 36px; color: #1a253c; margin: 0; }
    .content-panel { background-color: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 5px 25px rgba(0,0,0,0.05); margin-top: 40px; font-size: 16px; line-height: 1.8; }
</style>

<div class="page-header-minimal">
    <h1>Refund Policy</h1>
</div>

<div class="container" style="padding-bottom: 50px;">
    <div class="content-panel">
        <?php 
            // Output the content for the refund policy
            echo nl2br($site_settings->refund_policy ?? 'Refund Policy content is not available yet. Please check back later.'); 
        ?>
    </div>
</div>

<?php include 'footer.php'; ?>