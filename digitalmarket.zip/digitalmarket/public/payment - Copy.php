<?php
require_once '../init.php'; // This now loads Cashfree as well
include 'header.php';

// --- Prepare Data for the Page ---
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
// ... (Your existing correct PHP logic for fetching the product, security check)
// ... (and setting $is_logged_in)

$customer_phone = $is_logged_in ? $_SESSION['user_mobile'] : '9999999999'; // Default for guest
$customer_email = 'guest@example.com'; // Default for guest

// --- Cashfree Order Creation Logic ---
$cashfree_payment_session_id = '';
$error_message = '';
// Only try to create a Cashfree order if we are in Live mode and have keys
if ($site_settings->payment_mode === 'Live' && !empty($site_settings->cashfree_app_id) && !empty($site_settings->cashfree_secret_key)) {
    try {
        Cashfree::XClientId($site_settings->cashfree_app_id);
        Cashfree::XClientSecret($site_settings->cashfree_secret_key);
        $cashfree_environment = "PROD"; // Live mode
        Cashfree::XEnvironment($cashfree_environment);

        $order = new Order([
            'order_id' => 'DIGIMOMS-PROD-' . time() . '-' . $product_id,
            'order_amount' => $product['sale_price'],
            'order_currency' => 'INR',
            'customer_details' => [
                'customer_id' => 'CUST-' . ($is_logged_in ? $_SESSION['user_id'] : time()),
                'customer_phone' => $customer_phone,
                'customer_email' => $customer_email
            ],
            'order_meta' => [
                'return_url' => rtrim(BASE_URL, '/') . '/public/return.php?order_id={order_id}',
                'product_id' => $product_id // We pass our product ID here
            ],
            'order_note' => 'Purchase of: ' . $product['title']
        ]);
        $cashfree_payment_session_id = $order->create()->payment_session_id;
    } catch (Exception $e) {
        $error_message = "Could not initiate payment. Error: " . $e->getMessage();
    }
}
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .checkout-body { background-color: #f4f7fa; padding: 50px 0; }
    .checkout-grid { display: grid; grid-template-columns: 1.5fr 1fr; gap: 30px; }
    .panel { background-color: #fff; border-radius: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); }
    .panel-header { padding: 20px; border-bottom: 1px solid #eee; }
    .panel-header h2 { margin: 0; font-size: 22px; }
    .panel-body { padding: 25px; }
    .pay-button { width: 100%; padding: 15px; font-size: 18px; font-weight: 600; background: linear-gradient(to right, #007bff, #0056b3); color: white; border: none; border-radius: 8px; }
    .error-box { background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-top: 20px; }
</style>

<div class="checkout-body">
    <div class="container">
        <!-- The form is ONLY needed for Test Mode -->
        <form id="payment-form" action="payment_demo_process.php" method="POST">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <input type="hidden" name="final_sale_price" id="final-sale-price" value="<?php echo $product['sale_price']; ?>">
            
            <div class="checkout-grid">
                <div class="panel">
                    <div class="panel-header"><h2>Contact Information</h2></div>
                    <div class="panel-body">
                        <?php if ($is_logged_in): ?>
                            <p>Linked to account: <strong><?php echo $_SESSION['user_mobile']; ?></strong>.</p>
                        <?php else: ?>
                            <div class="form-group"><label>Name (Optional)</label><input type="text" id="guest_name" name="name" class="form-control"></div>
                            <div class="form-group"><label>Email (Optional)</label><input type="email" id="guest_email" name="email" class="form-control"></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header"><h2>Order Summary</h2></div>
                    <div class="panel-body order-summary">
                        <p class="product-title"><?php echo htmlspecialchars($product['title']); ?></p><hr>
                        <div class="price-line"><span>Subtotal</span><span>₹<?php echo htmlspecialchars($product['sale_price']); ?></span></div>
                        <div class="price-line discount" id="discount-line" style="display: none;"><span>Discount</span><span id="discount-amount">- ₹0.00</span></div><hr>
                        <div class="price-line total-line"><strong>Total</strong><strong id="total-price">₹<?php echo htmlspecialchars($product['sale_price']); ?></strong></div>
                        <div class="form-group" style="margin-top:20px;"><label>Coupon</label><div class="coupon-box"><input type="text" id="coupon-input" class="form-control"><button type="button" onclick="applyCoupon()">Apply</button></div><div id="coupon-message"></div></div>

                        <!-- FINAL PAYMENT BUTTON LOGIC -->
                        <?php if ($site_settings->payment_mode === 'Test'): ?>
                            <button type="submit" class="pay-button">Confirm Purchase (Test Mode)</button>
                        <?php elseif (!empty($cashfree_payment_session_id)): ?>
                            <button type="button" id="pay-btn" class="pay-button">Pay with Cashfree</button>
                        <?php else: ?>
                            <div class="error-box">
                                <?php echo htmlspecialchars($error_message ?: 'Payment gateway is currently unavailable. Please check your admin settings.'); ?>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Cashfree JS SDK -->
<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
<script>
    // --- JavaScript to launch Cashfree ---
    const cashfree = new Cashfree({ mode: "<?php echo ($site_settings->payment_mode === 'Live') ? 'production' : 'sandbox'; ?>" });
    document.getElementById("pay-btn")?.addEventListener("click", () => {
        // Update customer details for Cashfree if it's a guest
        let customerDetails = {
            customerId: "CUST-<?php echo $is_logged_in ? $_SESSION['user_id'] : time(); ?>",
            customerPhone: "<?php echo $customer_phone; ?>",
            customerEmail: "<?php echo $customer_email; ?>"
        };
        if (!<?php echo json_encode($is_logged_in); ?>) {
            customerDetails.customerEmail = document.getElementById('guest_email').value || 'guest@example.com';
        }
        
        cashfree.checkout({
            paymentSessionId: "<?php echo $cashfree_payment_session_id; ?>",
            customer: customerDetails
        });
    });

    // Your AJAX for coupon remains the same
    function applyCoupon() { /* ... */ }
</script>

<?php include 'footer.php'; ?>