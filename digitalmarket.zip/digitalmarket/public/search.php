<?php
require_once '../init.php'; // Handles session, db, cookies, settings
include 'header.php';

// Get the search query from the URL (this logic is correct)
$search_query = isset($_GET['query']) ? trim($_GET['query']) : '';
$results = [];

if (!empty($search_query)) {
    try {
        // The advanced "YouTube-like" search logic (this is correct)
        $sql = "SELECT *, MATCH(title, description, category) AGAINST(:query IN NATURAL LANGUAGE MODE) AS relevance
                FROM products 
                WHERE MATCH(title, description, category) AGAINST(:query IN NATURAL LANGUAGE MODE)
                ORDER BY relevance DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['query' => $search_query]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) { $results = []; }
}
?>

<!-- COMPLETE AND FINAL CSS FOR THIS PAGE -->
<style>
    .search-header { text-align: center; padding: 50px 0; background-color: #f8f9fa; }
    .search-header h1 { font-size: 36px; color: #1a253c; margin: 0; }
    .search-header p { font-size: 18px; color: #555; }
    .search-header .highlight { color: #007bff; font-weight: 600; }
    
    .results-section { padding: 40px 0; }

    /* --- THIS IS THE FINAL FIX for the Grid and Thumbnail --- */
    .results-grid {
        display: grid;
        /* We now define a fixed number of columns, like on the homepage */
        grid-template-columns: repeat(4, 1fr); /* 4 columns for desktop */
        gap: 25px;
    }
    
    /* Responsive adjustments for smaller screens */
    @media (max-width: 992px) {
        .results-grid { grid-template-columns: repeat(3, 1fr); }
    }
    @media (max-width: 768px) {
        .results-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 576px) {
        .results-grid { grid-template-columns: 1fr; } /* 1 column for mobile */
    }

    .product-card { 
        background-color: #fff; 
        border-radius: 12px; 
        box-shadow: 0 5px 20px rgba(0,0,0,0.08); 
        overflow: hidden; 
        text-decoration: none; 
        color: #333;
        display: flex;
        flex-direction: column;
        transition: transform 0.3s;
    }
    .product-card:hover { transform: translateY(-5px); }
    
    .product-card-thumbnail img {
        width: 100%;
        height: 200px;
        /* 'object-fit: cover;' is kept as it's the best way to handle various image ratios without distortion. 
           If you want the full image to show, 'contain' can be used, but it may leave empty spaces. 'cover' is standard. */
        object-fit: cover; 
    }
    .product-card-content { padding: 20px; flex-grow: 1; display: flex; flex-direction: column; text-align: center; }
    .product-card-title { font-size: 18px; margin: 0 0 10px 0; flex-grow: 1; }
    .product-card-price { font-size: 20px; font-weight: bold; color: #28a745; margin-top: auto; }
    .no-results { text-align: center; padding: 50px; font-size: 18px; }
</style>

<div class="search-header">
    <div class="container">
        <h1>Search Results</h1>
        <p>Showing results for: <span class="highlight">"<?php echo htmlspecialchars($search_query); ?>"</span></p>
    </div>
</div>

<div class="results-section">
    <div class="container">
        <?php if (!empty($results)): ?>
            <div class="results-grid">
                <?php foreach ($results as $product): ?>
                    <a href="product.php?id=<?php echo $product['id']; ?>" class="product-card">
                        <div class="product-card-thumbnail">
                            <img src="../<?php echo htmlspecialchars($product['thumbnail']); ?>" alt="<?php echo htmlspecialchars($product['title']); ?>">
                        </div>
                        <div class="product-card-content">
                            <h3 class="product-card-title"><?php echo htmlspecialchars($product['title']); ?></h3>
                            <p class="product-card-price">₹<?php echo htmlspecialchars($product['sale_price']); ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-results">
                <p>😔 No products found matching your search.</p>
                <p>Please try a different keyword or browse our categories.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>