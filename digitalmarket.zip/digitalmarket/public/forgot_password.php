<?php
// init.php handles session, db, cookies
require_once '../init.php'; 

$message = '';
$message_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile = trim($_POST['mobile']);
    $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = :mobile");
    $stmt->execute(['mobile' => $mobile]);
    $user = $stmt->fetch();

    if ($user) {
        try {
            // Check if there is already a pending request for this user to avoid spam
            $stmt_check = $pdo->prepare("SELECT id FROM password_resets WHERE user_id = :user_id AND status = 'Pending'");
            $stmt_check->execute(['user_id' => $user['id']]);

            if ($stmt_check->rowCount() > 0) {
                $message = "You already have a pending password reset request. Please wait for the admin to send the link.";
                $message_type = 'error';
            } else {
                $sql = "INSERT INTO password_resets (user_id, user_mobile, token, expires_at, status) 
                        VALUES (:user_id, :mobile, :token, :expires, 'Pending')";
                $stmt_insert = $pdo->prepare($sql);
                
                // --- THIS IS THE FIX ---
                // Set the expiry time to 2 hours from now.
                $expires_time = date('Y-m-d H:i:s', strtotime('+2 hours'));

                $stmt_insert->execute([
                    'user_id' => $user['id'],
                    'mobile' => $mobile,
                    'token' => 'pending_generation',
                    'expires' => $expires_time // Use the new future time
                ]);
                
                $message = "Your password reset request has been sent successfully. Our team will send you a reset link on WhatsApp shortly.";
                $message_type = 'success';
            }
        } catch (PDOException $e) {
            $message = "Could not submit your request. Error: " . $e->getMessage();
            $message_type = 'error';
        }
    } else {
        $message = "No account found with that mobile number.";
        $message_type = 'error';
    }
}

// Now include the header
include 'header.php';
?>

<!-- HTML AND CSS FOR THE FORGOT PASSWORD PAGE -->
<style>
    .form-page-container {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 20px;
        background-color: #f4f7f6;
    }
    .wrapper {
        width: 100%;
        max-width: 400px;
        padding: 30px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        text-align: center;
    }
    .wrapper h2 {
        color: #0056b3;
        margin-top: 0;
    }
    .form-group {
        margin-bottom: 20px;
        text-align: left;
    }
    label {
        display: block;
        margin-bottom: 5px;
        font-weight: 600;
    }
    .form-control {
        width: 100%;
        padding: 12px;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-sizing: border-box;
    }
    .btn {
        padding: 12px;
        width: 100%;
        border: none;
        color: white;
        background-color: #007bff;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
    }
    .alert {
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    .alert-success { background-color: #d4edda; color: #155724; }
    .alert-error { background-color: #f8d7da; color: #721c24; }
</style>

<div class="form-page-container">
    <div class="wrapper">
        <h2>Forgot Your Password?</h2>
        <p>No problem. Enter your registered mobile number below and we'll help you out.</p>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form action="forgot_password.php" method="post">
            <div class="form-group">
                <label for="mobile">Mobile Number</label>
                <input type="text" id="mobile" name="mobile" class="form-control" required>
            </div>
            <div class="form-group">
                <input type="submit" class="btn" value="Send Request">
            </div>
            <p style="margin-top: 20px;"><a href="login.php">Back to Login</a></p>
        </form>
    </div>
</div>

<?php
// Finally, include the footer
include 'footer.php';
?>