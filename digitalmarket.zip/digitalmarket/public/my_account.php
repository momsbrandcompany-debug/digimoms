<?php
require_once '../init.php';
include 'header.php';

if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

// --- FETCH PURCHASE HISTORY (Your correct and complete logic) ---
$purchases = [];
try {
    $stmt_purchases = $pdo->prepare("SELECT p.id, p.title, p.thumbnail, p.category, p.download_file_link FROM sales s JOIN products p ON s.product_id = p.id WHERE s.buyer_id = :user_id ORDER BY s.sale_date DESC");
    $stmt_purchases->execute(['user_id' => $user_id]);
    $purchases = $stmt_purchases->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { /* Error handling */ }

// --- THIS IS THE FIX: Fetch all necessary columns for the meeting ---
$upcoming_meetings = [];
try {
    // Select all columns (*) to ensure we get meeting_link
    $stmt_meetings = $pdo->query("SELECT * FROM live_meetings WHERE meeting_date >= CURDATE() ORDER BY meeting_date ASC LIMIT 5");
    $upcoming_meetings = $stmt_meetings->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { /* Error handling */ }

// --- NEW LOGIC: Check if this user has ever purchased a video course (for passcode) ---
$has_purchased_course = false;
try {
    $stmt_check_course = $pdo->prepare("SELECT s.id FROM sales s JOIN products p ON s.product_id = p.id WHERE s.buyer_id = :user_id AND p.category = 'Courses' LIMIT 1");
    $stmt_check_course->execute(['user_id' => $user_id]);
    if ($stmt_check_course->rowCount() > 0) {
        $has_purchased_course = true;
    }
} catch (PDOException $e) { /* Handle error if needed */ }
?>

<!-- COMPLETE CSS FOR THIS PAGE (Your code is restored and enhanced) -->
<style>
    .account-header { text-align: center; padding: 50px 0; background-color: #f8f9fa; border-bottom: 1px solid #ddd; }
    .account-header h1 { font-size: 36px; color: #1a253c; }
    
    .account-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 40px; padding: 40px 0; }
    
    .purchase-list { list-style: none; padding: 0; margin: 0; }
    .purchase-item { display: flex; align-items: center; background-color: #fff; border: 1px solid #eee; border-radius: 10px; padding: 20px; margin-bottom: 20px; }
    .purchase-item img { width: 120px; height: 80px; object-fit: cover; border-radius: 8px; margin-right: 20px; }
    .purchase-info { flex-grow: 1; }
    .purchase-info h3 { margin: 0 0 10px 0; font-size: 20px; }
    .purchase-actions a { display: inline-block; padding: 10px 20px; color: white !important; text-decoration: none; border-radius: 5px; font-weight: 500; text-align: center; }
    .btn-watch { background-color: #007bff; } .btn-download { background-color: #28a745; }

    .noticeboard-panel { background-color: #fff; border: 1px solid #eee; border-radius: 10px; padding: 25px; height: fit-content; }
    .noticeboard-panel h2 { margin-top: 0; font-size: 22px; border-bottom: 1px solid #ddd; padding-bottom: 15px; }
    .meeting-item { padding: 15px 0; border-bottom: 1px solid #f0f0f0; }
    .meeting-item:last-child { border-bottom: none; }
    .meeting-item .date { font-weight: 600; color: #007bff; }
    .meeting-item .title { font-size: 18px; margin: 5px 0; color: #333; }
    /* NEW STYLES for the Join Link and Passcode */
    .meeting-join-link { display: inline-block; background-color: #4285F4; color: white !important; padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: 500; margin-top: 10px; }
    .passcode-box { margin-top: 10px; }
    .passcode-visible { background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; font-weight: bold; }
    .passcode-hidden { background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; font-size: 14px; }
    .passcode-hidden a { color: #721c24; font-weight: 600; text-decoration: underline; }
</style>

<div class="account-header">
    <div class="container">
        <h1>My Account</h1>
        <p>Access your purchases and check the upcoming live seminar schedule.</p>
    </div>
</div>

<div class="container">
    <div class="account-layout">
        <!-- Left Column: Purchase History - YOUR CODE IS RESTORED -->
        <div>
            <h2>My Purchase History</h2>
            <?php if (!empty($purchases)): ?>
                <ul class="purchase-list">
                    <?php foreach ($purchases as $item): ?>
                        <li class="purchase-item">
                            <img src="../<?php echo htmlspecialchars($item['thumbnail']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                            <div class="purchase-info">
                                <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                                <p>Category: <?php echo htmlspecialchars($item['category']); ?></p>
                            </div>
                            <div class="purchase-actions">
                                <?php if ($item['category'] === 'Courses'): ?>
                                    <a href="watch_course.php?id=<?php echo $item['id']; ?>" class="btn-watch">Watch Course</a>
                                <?php else: ?>
                                    <a href="../<?php echo htmlspecialchars($item['download_file_link']); ?>" class="btn-download" download>Download File</a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="text-align:center; padding: 20px; background-color: #f8f9fa; border-radius: 8px;">You have not made any purchases yet.</p>
            <?php endif; ?>
        </div>
        
        <!-- Right Column: Live Seminar Noticeboard - NOW WITH LINK AND CONDITIONAL PASSCODE -->
        <div class="noticeboard-panel">
            <h2>Live Seminar Schedule</h2>
            <?php if (!empty($upcoming_meetings)): ?>
                <?php foreach ($upcoming_meetings as $meeting): ?>
                    <div class="meeting-item">
                        <div class="date"><?php echo date('d M Y, h:i A', strtotime($meeting['meeting_date'])); ?></div>
                        <div class="title"><?php echo htmlspecialchars($meeting['meeting_title']); ?></div>
                        
                        <!-- THIS IS THE FIX: The join link is now displayed -->
                        <a href="<?php echo htmlspecialchars($meeting['meeting_link']); ?>" class="meeting-join-link" target="_blank">Join with Google Meet</a>

                        <!-- Conditional Passcode Logic -->
                        <div class="passcode-box">
                        <?php if ($has_purchased_course): ?>
                            <?php if ($meeting['is_active']): ?>
                                <div class="passcode-visible">
                                    Passcode: <?php echo htmlspecialchars($meeting['passcode']); ?>
                                </div>
                            <?php else: ?>
                                <div class="passcode-hidden" style="background-color: #e2e3e5; color: #383d41;">Passcode will be revealed when the meeting is active.</div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="passcode-hidden">
                                Passcode is only visible to course students. <a href="products.php">Buy a course</a> to get access.
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No upcoming seminars are scheduled at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>