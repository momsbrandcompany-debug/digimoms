<?php include 'header.php'; ?>
<div style="text-align:center; padding: 50px;">
    <h1>&#10004; Registration Successful!</h1>
    <p>Thank you for joining. The trainer will contact you shortly on your provided contact number with the meeting details.</p>
    <a href="index.php">Back to Homepage</a>
</div>
<?php include 'footer.php'; ?>