<?php
require_once '../init.php';
include 'header.php';

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($product_id === 0) {
    echo "<div class='container' style='padding:20px;'><p>Invalid Product ID.</p></div>";
    include 'footer.php';
    exit;
}

// Fetch the product from the database
try {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id AND status = 'Active'");
    $stmt->execute(['id' => $product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$product) {
        echo "<div class='container' style='padding:20px;'><p>Product not found or is inactive.</p></div>";
        include 'footer.php';
        exit;
    }
} catch (PDOException $e) { die("Error: Could not fetch product details."); }

// Final "Buy Now" button logic
$buy_now_link = "payment.php?product_id=" . $product['id'];
if ($product['category'] === 'Courses' && (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true)) {
    $_SESSION['redirect_url'] = "product.php?id=" . $product['id'];
    $buy_now_link = "login.php";
}

// Affiliate link generation for logged-in partners
$affiliate_link = "";
if (isset($_SESSION['partner_loggedin']) && $_SESSION['partner_loggedin'] === true) {
    $base_url = rtrim(BASE_URL, '/') . '/public/product.php';
    $affiliate_link = $base_url . "?id=" . $product_id . "&ref=" . $_SESSION['partner_id'];
}
?>
<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .product-details-grid { display: grid; grid-template-columns: 1fr 1.2fr; gap: 50px; align-items: flex-start; margin-top: 40px; }
    .product-image img { width: 100%; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,.1); }
    .product-info h1 { font-size: 36px; color: #1a253c; margin-top: 0; margin-bottom: 15px; }
    .product-info .price { font-size: 32px; font-weight: 700; color: #28a745; margin-bottom: 20px; }
    .product-info .price .market-price { text-decoration: line-through; color: #aaa; font-size: 20px; margin-right: 15px; }
    .product-meta { list-style: none; padding: 20px 0; margin: 20px 0; border-top: 1px solid #eee; border-bottom: 1px solid #eee; }
    .product-meta li { padding: 10px 0; display: flex; font-size: 16px; color: #555; }
    .product-meta li strong { color: #333; margin-right: 10px; width: 120px; flex-shrink: 0; }
    .product-description { font-size: 17px; line-height: 1.7; color: #444; }
    .buy-now-btn { background-color: #007bff; color: #fff !important; padding: 18px 40px; font-size: 20px; font-weight: 700; text-decoration: none; border-radius: 50px; display: inline-block; margin-top: 20px; }
    .affiliate-box { margin-top: 30px; padding: 20px; background-color: #e9f4ff; border: 2px dashed #007bff; border-radius: 10px; text-align: center; }
    .affiliate-box h3 { margin-top: 0; color: #0056b3; }
    .affiliate-box input { width: 80%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; text-align: center; }
    .affiliate-box button { padding: 10px 15px; margin-left: 10px; background-color: #28a745; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
    .login-prompt { background-color: #fff3cd; color: #856404; padding: 15px; border-radius: 8px; margin-top: 20px; border: 1px solid #ffeeba; }
</style>
<main class="section container">
    <div class="product-details-grid">
        <div class="product-image"><img src="../<?php echo htmlspecialchars($product['thumbnail']); ?>" alt="<?php echo htmlspecialchars($product['title']); ?>"></div>
        <div class="product-info">
            <h1><?php echo htmlspecialchars($product['title']); ?></h1>
            <div class="price">
                <?php if (!empty($product['market_price']) && $product['market_price'] > 0): ?><span class="market-price">₹<?php echo htmlspecialchars($product['market_price']); ?></span><?php endif; ?>
                ₹<?php echo htmlspecialchars($product['sale_price']); ?>
            </div>
            <div class="product-description"><p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p></div>
            <ul class="product-meta">
                <?php if (!empty($product['category'])): ?><li><strong>Category:</strong> <?php echo htmlspecialchars($product['category']); ?></li><?php endif; ?>
                <?php if (!empty($product['file_size'])): ?><li><strong>File Size:</strong> <?php echo htmlspecialchars($product['file_size']); ?></li><?php endif; ?>
                <?php if (!empty($product['file_format'])): ?><li><strong>File Format:</strong> <?php echo htmlspecialchars($product['file_format']); ?></li><?php endif; ?>
            </ul>
            <a href="<?php echo $buy_now_link; ?>" class="buy-now-btn">Buy Now</a>
            <?php if ($product['category'] === 'Courses' && (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true)): ?>
                <div class="login-prompt"><strong>Note:</strong> You must log in to purchase this course.</div>
            <?php endif; ?>
            <?php if (!empty($affiliate_link)): ?>
            <div class="affiliate-box">
                <h3>Your Affiliate Link</h3><p>Share this link to earn commission!</p>
                <input type="text" value="<?php echo htmlspecialchars($affiliate_link); ?>" id="affiliateLink" readonly><button onclick="copyLink()">Copy</button>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<script>function copyLink() { var copyText = document.getElementById("affiliateLink"); copyText.select(); document.execCommand("copy"); alert("Link Copied!"); }</script>
<?php include 'footer.php'; ?>