<?php
require_once '../db_config.php';

$order_id = $_GET['order_id'] ?? null;
if (!$order_id) {
    die("Invalid download link.");
}

try {
    // 1. Check if the order is valid and payment is completed
    $order_stmt = $pdo->prepare("SELECT product_id FROM orders WHERE id = ? AND payment_status = 'Completed'");
    $order_stmt->execute([$order_id]);
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        die("Sorry, this order is not valid or payment is not complete.");
    }

    // 2. Get the product file path
    $product_id = $order['product_id'];
    $product_stmt = $pdo->prepare("SELECT download_file_link FROM products WHERE id = ?");
    $product_stmt->execute([$product_id]);
    $product = $product_stmt->fetch(PDO::FETCH_ASSOC);

    $file_path_relative = $product['download_file_link'];
    if (!$file_path_relative) {
        die("File link is missing for this product.");
    }

    // Construct the full server path
    $file_path_full = '../' . $file_path_relative;

    // 3. Force download the file
    if (file_exists($file_path_full)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream'); // Generic type for any file
        header('Content-Disposition: attachment; filename="' . basename($file_path_full) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path_full));
        readfile($file_path_full);
        exit;
    } else {
        die("File not found on the server. Please contact support.");
    }

} catch (Exception $e) {
    die("An error occurred: " . $e->getMessage());
}
?>