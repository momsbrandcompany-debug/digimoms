<?php
session_start();
// If user is already logged in, redirect to account page
if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true) {
    header("location: my_account.php");
    exit;
}

require_once '../db_config.php';

$mobile = $password = $confirm_password = "";
$mobile_err = $password_err = $confirm_password_err = $general_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate mobile number
    if (empty(trim($_POST["mobile"]))) {
        $mobile_err = "Please enter a mobile number.";
    } elseif (!preg_match('/^[0-9]{10,13}$/', trim($_POST["mobile"]))) {
        $mobile_err = "Please enter a valid 10 to 13 digit mobile number.";
    } else {
        // Prepare a select statement to check if mobile already exists
        $sql = "SELECT id FROM users WHERE mobile = :mobile";
        
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":mobile", $param_mobile, PDO::PARAM_STR);
            $param_mobile = trim($_POST["mobile"]);
            
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $mobile_err = "This mobile number is already registered.";
                } else {
                    $mobile = trim($_POST["mobile"]);
                }
            } else {
                $general_err = "Oops! Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Passwords do not match.";
        }
    }
    
    // Check for errors before inserting into database
    if (empty($mobile_err) && empty($password_err) && empty($confirm_password_err) && empty($general_err)) {
        
        $sql = "INSERT INTO users (mobile, password) VALUES (:mobile, :password)";
         
        if ($stmt = $pdo->prepare($sql)) {
            $stmt->bindParam(":mobile", $param_mobile, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
            
            $param_mobile = $mobile;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password
            
            if ($stmt->execute()) {
                // Redirect to login page with a success message
                header("location: login.php?status=registered");
            } else {
                $general_err = "Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7f6; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .wrapper { width: 380px; padding: 30px; background-color: #fff; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #0056b3; margin-top: 0; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        .help-block { color: #dc3545; font-size: 13px; }
        .btn { padding: 12px; width: 100%; border: none; color: white; background-color: #007bff; font-size: 16px; cursor: pointer; border-radius: 5px; }
        .general-error { padding: 10px; background-color: #f8d7da; color: #721c24; border-radius: 5px; margin-bottom: 15px; text-align: center; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Create Your Account</h2>
        <p>Fill out this form to register and buy video courses.</p>
        
        <?php if(!empty($general_err)) echo '<div class="general-error">' . $general_err . '</div>'; ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Mobile Number</label>
                <input type="text" name="mobile" class="form-control" value="<?php echo $mobile; ?>">
                <span class="help-block"><?php echo $mobile_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password (min. 6 characters)</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control">
                <span class="help-block"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn" value="Register">
            </div>
            <p style="text-align:center;">Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
    </div>
</body>
</html>