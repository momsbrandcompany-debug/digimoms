<?php
require_once '../init.php';
include 'header.php';

if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

// --- FETCH PURCHASE HISTORY (THIS PART IS NOW CORRECT AND COMPLETE) ---
$purchases = [];
try {
    $stmt_purchases = $pdo->prepare("SELECT p.id, p.title, p.thumbnail, p.category, p.download_file_link FROM sales s JOIN products p ON s.product_id = p.id WHERE s.buyer_id = :user_id ORDER BY s.sale_date DESC");
    $stmt_purchases->execute(['user_id' => $user_id]);
    $purchases = $stmt_purchases->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { /* Error handling */ }

// --- Fetch Upcoming Live Meetings (This part is correct) ---
$upcoming_meetings = [];
try {
    $stmt_meetings = $pdo->query("SELECT meeting_title, meeting_date FROM live_meetings WHERE meeting_date >= CURDATE() ORDER BY meeting_date ASC LIMIT 5");
    $upcoming_meetings = $stmt_meetings->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { /* Error handling */ }
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .account-header { text-align: center; padding: 50px 0; background-color: #f8f9fa; border-bottom: 1px solid #ddd; }
    .account-header h1 { font-size: 36px; color: #1a253c; }
    
    .account-layout { 
        display: grid; 
        grid-template-columns: 2fr 1fr; /* 2/3 for purchases, 1/3 for seminars */
        gap: 40px; 
        padding: 40px 0; 
    }
    
    /* STYLES FOR PURCHASE HISTORY ARE RESTORED AND COMPLETE */
    .purchase-list { list-style: none; padding: 0; margin: 0; }
    .purchase-item { 
        display: flex; 
        align-items: center; 
        background-color: #fff; 
        border: 1px solid #eee; 
        border-radius: 10px; 
        padding: 20px; 
        margin-bottom: 20px; 
        transition: box-shadow 0.3s;
    }
    .purchase-item:hover { box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
    .purchase-item img { 
        width: 120px; 
        height: 80px; 
        object-fit: cover; 
        border-radius: 8px; 
        margin-right: 20px; 
    }
    .purchase-info { flex-grow: 1; }
    .purchase-info h3 { margin: 0 0 10px 0; font-size: 20px; }
    .purchase-actions a { 
        display: inline-block; 
        padding: 10px 20px; 
        color: white !important; 
        text-decoration: none; 
        border-radius: 5px; 
        font-weight: 500; 
        min-width: 120px;
        text-align: center;
    }
    .btn-watch { background-color: #007bff; } 
    .btn-download { background-color: #28a745; }

    /* Styles for the noticeboard are correct */
    .noticeboard-panel { background-color: #fff; border: 1px solid #eee; border-radius: 10px; padding: 25px; height: fit-content; }
    .noticeboard-panel h2 { margin-top: 0; font-size: 22px; border-bottom: 1px solid #ddd; padding-bottom: 15px; }
    .meeting-item { padding: 15px 0; border-bottom: 1px solid #f0f0f0; }
    .meeting-item:last-child { border-bottom: none; }
    .meeting-item .date { font-weight: 600; color: #007bff; }
    .meeting-item .title { font-size: 18px; margin: 5px 0; color: #333; }
</style>

<div class="account-header">
    <div class="container">
        <h1>My Account</h1>
        <p>Access your purchases and check the upcoming live seminar schedule.</p>
    </div>
</div>

<div class="container">
    <div class="account-layout">
        <!-- Left Column: Purchase History - THIS ENTIRE SECTION IS NOW COMPLETE AND CORRECT -->
        <div>
            <h2>My Purchase History</h2>
            <?php if (!empty($purchases)): ?>
                <ul class="purchase-list">
                    <?php foreach ($purchases as $item): ?>
                        <li class="purchase-item">
                            <img src="../<?php echo htmlspecialchars($item['thumbnail']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
                            <div class="purchase-info">
                                <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                                <p>Category: <?php echo htmlspecialchars($item['category']); ?></p>
                            </div>
                            <div class="purchase-actions">
                                <?php if ($item['category'] === 'Courses'): ?>
                                    <a href="watch_course.php?id=<?php echo $item['id']; ?>" class="btn-watch">Watch Course</a>
                                <?php else: ?>
                                    <a href="../<?php echo htmlspecialchars($item['download_file_link']); ?>" class="btn-download" download>Download File</a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="text-align:center; padding: 20px; background-color: #f8f9fa; border-radius: 8px;">You have not made any purchases yet.</p>
            <?php endif; ?>
        </div>
        
        <!-- Right Column: Live Seminar Noticeboard (This is correct) -->
        <div class="noticeboard-panel">
            <h2>Live Seminar Schedule</h2>
            <?php if (!empty($upcoming_meetings)): ?>
                <?php foreach ($upcoming_meetings as $meeting): ?>
                    <div class="meeting-item">
                        <div class="date"><?php echo date('d M Y, h:i A', strtotime($meeting['meeting_date'])); ?></div>
                        <div class="title"><?php echo htmlspecialchars($meeting['meeting_title']); ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No upcoming seminars are scheduled at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>