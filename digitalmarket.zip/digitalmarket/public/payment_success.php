<?php
// No session_start() needed here.
require_once '../db_config.php';
include 'header.php';

$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
if ($product_id == 0) die("Invalid request.");

$stmt = $pdo->prepare("SELECT title, category, download_file_link FROM products WHERE id = :id");
$stmt->execute(['id' => $product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$product) die("Could not find purchase details.");

// We can add an auto-download script if a file link exists
$download_url = !empty($product['download_file_link']) ? '../' . $product['download_file_link'] : '#';
?>
<style>
    .success-body { background-color: #f4f7fa; padding: 50px 0; display: flex; align-items: center; justify-content: center; min-height: 60vh; }
    .success-panel { background-color: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 5px 25px rgba(0,0,0,0.08); text-align: center; max-width: 500px; }
    .success-icon { font-size: 60px; color: #28a745; line-height: 1; }
    .success-panel h1 { font-size: 28px; color: #1a253c; margin: 20px 0 10px 0; }
    .success-panel p { color: #555; font-size: 16px; line-height: 1.6; }
    .download-button { display: inline-block; margin-top: 20px; padding: 15px 30px; background: linear-gradient(to right, #28a745, #218838); color: white !important; font-size: 18px; font-weight: 600; text-decoration: none; border-radius: 50px; }
    .home-link { margin-top: 20px; display: block; color: #007bff; font-weight: 500; }
</style>

<div class="success-body">
    <div class="success-panel">
        <div class="success-icon">&#10004;</div>
        <h1>Payment Successful!</h1>
        <p>Thank you for purchasing <strong>"<?php echo htmlspecialchars($product['title']); ?>"</strong>.</p>
        
        <?php if ($product['category'] === 'Courses'): ?>
            <p>You can now access your course anytime from your "My Account" page.</p>
            <a href="my_account.php" class="download-button">Go to My Courses</a>
        <?php elseif (!empty($product['download_file_link'])): ?>
            <p>Your download should start automatically. If it doesn't, click the button below.</p>
            <a href="<?php echo htmlspecialchars($download_url); ?>" class="download-button" download>Download Now</a>
            
            <!-- JavaScript for automatic download -->
            <script>
                window.onload = function() {
                    window.location.href = '<?php echo $download_url; ?>';
                };
            </script>
        <?php endif; ?>

        <a href="index.php" class="home-link">Back to Homepage</a>
    </div>
</div>

<?php include 'footer.php'; ?>