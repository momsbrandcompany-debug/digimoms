<?php
require_once dirname(__DIR__, 2) . '/init.php';
include dirname(__DIR__) . '/header.php';

// Fetch all posts with category names
try {
    $stmt = $pdo->query("SELECT bp.*, bc.name as category_name FROM blog_posts bp LEFT JOIN blog_categories bc ON bp.category_id = bc.id WHERE bp.status = 'Published' ORDER BY bp.created_at DESC");
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { $posts = []; }
?>

<!-- COMPLETE CSS FOR THIS PAGE (Edutips Style) -->
<style>
    .blog-page-header { text-align: center; padding: 60px 20px; background-color: #f8f9fa; }
    .blog-page-header h1 { font-size: 42px; color: #1a253c; margin: 0; }
    .blog-page-header p { font-size: 18px; color: #555; max-width: 600px; margin: 10px auto 0 auto; }
    .blog-section { padding: 50px 0; }
    .blog-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 30px; }
    .post-card { 
        background-color: #fff; 
        border-radius: 15px; 
        box-shadow: 0 8px 25px rgba(0,0,0,0.08); 
        overflow: hidden; 
        text-decoration: none; 
        color: #333; 
        display: flex;
        flex-direction: column;
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .post-card:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(0,0,0,0.12); }
    .post-card-thumbnail img { width: 100%; height: 220px; object-fit: cover; }
    .post-card-content { padding: 25px; display: flex; flex-direction: column; flex-grow: 1; }
    .post-card-category { display: inline-block; background-color: #e9f4ff; color: #007bff; padding: 6px 15px; border-radius: 50px; font-size: 13px; font-weight: 600; margin-bottom: 15px; align-self: flex-start; }
    .post-card-title { font-size: 22px; margin: 0 0 15px 0; line-height: 1.4; flex-grow: 1; }
    .post-card-meta { font-size: 14px; color: #777; margin-top: auto; }
</style>

<div class="blog-page-header">
    <div class="container">
        <h1>Our Blog & Articles</h1>
        <p>Explore our latest articles, insights, and stories to stay updated and learn something new.</p>
    </div>
</div>

<div class="blog-section">
    <div class="container">
        <div class="blog-grid">
            <?php if (!empty($posts)): ?>
                <?php foreach ($posts as $post): ?>
                    <a href="../single_post.php?id=<?php echo $post['id']; ?>" class="post-card">
                        <div class="post-card-thumbnail">
                            <img src="../../<?php echo htmlspecialchars($post['thumbnail']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>">
                        </div>
                        <div class="post-card-content">
                            <span class="post-card-category"><?php echo htmlspecialchars($post['category_name']); ?></span>
                            <h2 class="post-card-title"><?php echo htmlspecialchars($post['title']); ?></h2>
                            <p class="post-card-meta">Published on <?php echo date('d M Y', strtotime($post['created_at'])); ?></p>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="grid-column: 1 / -1; text-align:center;">No blog posts have been published yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include dirname(__DIR__) . '/footer.php'; ?>