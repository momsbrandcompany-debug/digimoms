/* Style for the custom highlighted text */
.custom-highlight {
    background-color: #fff3cd; /* A light yellow background */
    color: #856404;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
}
/* Style for the custom highlighted button */
.custom-highlight-btn {
    display: inline-block;
    background-color: #007bff;
    color: white !important;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    margin: 10px 0;
}