<?php
require_once '../init.php';

$message = '';
$message_type = 'error';
$show_form = false;
$token = htmlspecialchars($_GET['token'] ?? '');

if (empty($token)) {
    $message = "No reset token provided.";
} else {
    // Check if the token is valid AND has not expired
    $stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = :token AND status = 'Pending' AND expires_at > NOW()");
    $stmt->execute(['token' => $token]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($request) {
        $show_form = true; // Token is valid, show the form
    } else {
        $message = "This password reset link is either invalid, has expired, or has already been used. Please request a new one.";
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && $show_form) {
    $posted_token = htmlspecialchars($_POST['token'] ?? '');
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Double-check token on POST
    if ($posted_token !== $token) {
        $message = "Token mismatch. Invalid request.";
        $show_form = false;
    } elseif (strlen($new_password) < 6) {
        $message = "Password must be at least 6 characters long.";
    } elseif ($new_password !== $confirm_password) {
        $message = "Passwords do not match.";
    } else {
        // All checks passed, update password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt_update_user = $pdo->prepare("UPDATE users SET password = :password WHERE id = :user_id");
        $stmt_update_user->execute(['password' => $hashed_password, 'user_id' => $request['user_id']]);

        // Mark token as used
        $stmt_update_token = $pdo->prepare("UPDATE password_resets SET status = 'Completed' WHERE id = :id");
        $stmt_update_token->execute(['id' => $request['id']]);

        $message = "Password has been reset successfully! You can now log in.";
        $message_type = 'success';
        $show_form = false;
    }
}

include 'header.php';
?>

<!-- Your HTML and CSS from the previous correct version will work perfectly -->
<div class="form-page-container">
    <div class="wrapper">
        <h2>Set a New Password</h2>
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if ($show_form): ?>
            <form action="reset_password.php" method="post">
                <input type="hidden" name="token" value="<?php echo $token; ?>">
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" name="new_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                <input type="submit" class="btn" value="Reset Password">
            </form>
        <?php else: ?>
            <p><a href="login.php">Back to Login</a></p>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>