<?php
// No PHP code needed here at the top anymore, as init.php handles it.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DigiMoms - Empowering Futures</title>
    <style>
        /* General Styles */
        body { font-family: 'Segoe UI', sans-serif; margin: 0; background-color: #ffffff; color: #333; }
        .container { width: 90%; max-width: 1200px; margin: 0 auto; }
        a { text-decoration: none; }
        
        /* Navbar Styles */
        .navbar { background-color: #ffffff; padding: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 1000; }
        .navbar-content { display: flex; justify-content: space-between; align-items: center; }
        .navbar .logo { font-size: 26px; font-weight: 700; color: #007bff; }
        
        .nav-links { display: flex; align-items: center; gap: 25px; }
        .nav-links a { color: #333; font-weight: 500; transition: color 0.3s; }
        .nav-links a:hover { color: #007bff; }
        
        .nav-links .button { background-color: #007bff; color: white !important; padding: 10px 22px; border-radius: 50px; }
        .nav-links .button-partner { background-color: #ffc107; color: #333 !important; padding: 10px 22px; border-radius: 50px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container navbar-content">
            <a href="index.php" class="logo">DigiMoms</a>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="products.php">Category</a>
                <a href="http://localhost/digitalmarket/blog/index.php">Blog</a>
                <a href="become_partner.php">Become A Partner</a>
                <a href="partner_login.php" class="button-partner">Partner Login</a>
                <?php if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true): ?>
                    <a href="my_account.php" class="button">My Account</a>
                <?php else: ?>
                    <a href="login.php" class="button">Login / Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <main>