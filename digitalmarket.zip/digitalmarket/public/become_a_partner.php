<?php
session_start();
require_once '../db_config.php';

$message = '';
$message_type = '';
$form_data = []; // To repopulate form on error

// Check for a referral ID in the URL, e.g., become_a_partner.php?ref=1
$parent_partner_id = isset($_GET['ref']) ? (int)$_GET['ref'] : NULL;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Repopulate form data array to keep user's input on error
    $form_data = $_POST;

    // Sanitize and retrieve ALL fields from the form
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $mobile = isset($_POST['mobile']) ? trim($_POST['mobile']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $age = isset($_POST['age']) && !empty($_POST['age']) ? (int)$_POST['age'] : NULL;
    $profession = isset($_POST['profession']) ? trim($_POST['profession']) : '';
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';
    $payment_details = isset($_POST['payment_details']) ? trim($_POST['payment_details']) : '';
    
    // Retrieve parent partner ID from the hidden form field
    $parent_partner_id_from_form = isset($_POST['parent_partner_id']) ? (int)$_POST['parent_partner_id'] : NULL;

    // --- Validation ---
    if (empty($name) || empty($mobile) || empty($email) || empty($password) || empty($payment_details)) {
        $message = "Please fill in all required fields: Name, Mobile, Email, Password, and Payment Details.";
        $message_type = 'error';
    } else {
        // Check for duplicate mobile or email
        $stmt = $pdo->prepare("SELECT id FROM partners WHERE mobile = :mobile OR email = :email");
        $stmt->execute(['mobile' => $mobile, 'email' => $email]);
        if ($stmt->rowCount() > 0) {
            $message = "A partner with this mobile number or email already exists.";
            $message_type = 'error';
        } else {
            // --- If all checks pass, insert into database ---
            try {
                $sql = "INSERT INTO partners (name, mobile, email, password, age, profession, address, payment_details, parent_partner_id) 
                        VALUES (:name, :mobile, :email, :password, :age, :profession, :address, :payment_details, :parent_partner_id)";
                $stmt = $pdo->prepare($sql);
                
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':mobile', $mobile);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', password_hash($password, PASSWORD_DEFAULT));
                $stmt->bindParam(':age', $age, PDO::PARAM_INT);
                $stmt->bindParam(':profession', $profession);
                $stmt->bindParam(':address', $address);
                $stmt->bindParam(':payment_details', $payment_details);
                $stmt->bindParam(':parent_partner_id', $parent_partner_id_from_form, PDO::PARAM_INT);

                if ($stmt->execute()) {
                    $message = "Application submitted successfully! It is now under review.";
                    $message_type = 'success';
                    $form_data = []; // Clear form data on success
                } else {
                    $message = "Something went wrong. Please try again.";
                    $message_type = 'error';
                }
            } catch (PDOException $e) {
                $message = "Database error: " . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Become a Partner</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7f6; display: flex; align-items: center; justify-content: center; padding: 40px 0; }
        .wrapper { width: 100%; max-width: 600px; padding: 40px; background-color: #fff; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #0056b3; margin-bottom: 10px;}
        p { text-align: center; color: #555; margin-top: 0; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { margin-bottom: 0; }
        .full-width { grid-column: 1 / -1; }
        label { display: block; margin-bottom: 5px; font-weight: 600; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; font-size: 16px; }
        .btn { padding: 15px; width: 100%; border: none; color: white; background-color: #28a745; font-size: 16px; cursor: pointer; border-radius: 5px; font-weight: 600; }
        .alert { padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center; font-weight: 500; }
        .alert-success { background-color: #d4edda; color: #155724; }
        .alert-error { background-color: #f8d7da; color: #721c24; }
        .referral-info { background-color: #e9f4ff; color: #0056b3; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 20px; font-weight: 500; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Partner Registration Form</h2>
        <p>Join our team and start your earning journey today!</p>
        
        <?php if ($message): ?><div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div><?php endif; ?>
        
        <?php if ($parent_partner_id): ?>
            <div class="referral-info">You are being referred by Partner ID: <?php echo $parent_partner_id; ?></div>
        <?php endif; ?>
        
        <form action="become_a_partner.php<?php if ($parent_partner_id) echo '?ref=' . $parent_partner_id; ?>" method="post">
            <input type="hidden" name="parent_partner_id" value="<?php echo $parent_partner_id; ?>">
            <div class="form-grid">
                <div class="form-group full-width">
                    <label>Full Name *</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($form_data['name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Mobile (Login ID) *</label>
                    <input type="text" name="mobile" class="form-control" value="<?php echo htmlspecialchars($form_data['mobile'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>" required>
                </div>
                <div class="form-group full-width">
                    <label>Password *</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Age</label>
                    <input type="number" name="age" class="form-control" value="<?php echo htmlspecialchars($form_data['age'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Profession</label>
                    <input type="text" name="profession" class="form-control" value="<?php echo htmlspecialchars($form_data['profession'] ?? ''); ?>">
                </div>
                <div class="form-group full-width">
                    <label>Address</label>
                    <textarea name="address" class="form-control"><?php echo htmlspecialchars($form_data['address'] ?? ''); ?></textarea>
                </div>
                <div class="form-group full-width">
                    <label>Payment Details (UPI ID / Bank Account) *</label>
                    <input type="text" name="payment_details" class="form-control" placeholder="For receiving payments" value="<?php echo htmlspecialchars($form_data['payment_details'] ?? ''); ?>" required>
                </div>
                <div class="form-group full-width">
                    <input type="submit" class="btn" value="Submit Application">
                </div>
            </div>
        </form>
    </div>
</body>
</html>