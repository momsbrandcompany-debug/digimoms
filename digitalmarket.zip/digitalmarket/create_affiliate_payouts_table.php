<?php
require_once 'db_config.php';
try {
    // Drop the old 'payout_requests' table if it exists
    $pdo->exec("DROP TABLE IF EXISTS payout_requests");
    // Create the new, clearly named table
    $sql = "CREATE TABLE IF NOT EXISTS affiliate_payouts (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        partner_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes TEXT NULL,
        FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'affiliate_payouts' created and old 'payout_requests' table removed.</p>";
} catch (PDOException $e) { /* ... */ }
?>