<?php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS payout_requests (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        partner_id INT NOT NULL,
        request_amount DECIMAL(10, 2) NOT NULL,
        status ENUM('Pending', 'Completed', 'Rejected') NOT NULL DEFAULT 'Pending',
        request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed_date DATETIME NULL,
        admin_notes TEXT NULL,
        FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE CASCADE
    )";

    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'payout_requests' has been created successfully.</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not create table. Error: " . $e->getMessage() . "</p>");
}
?>