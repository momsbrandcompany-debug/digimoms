<?php
require_once 'db_config.php';
try {
    // Step 1: Create the new 'blog_categories' table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS blog_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE
        )
    ");
    echo "<p>'blog_categories' table created successfully.</p>";

    // Step 2: Update the 'blog_posts' table to use category ID and add highlight feature
    // Drop the old category_name column if it exists
    try { $pdo->exec("ALTER TABLE blog_posts DROP COLUMN category_name"); } catch (PDOException $e) { /* Ignore if it doesn't exist */ }

    // Add new columns
    $pdo->exec("ALTER TABLE blog_posts ADD COLUMN category_id INT NULL AFTER title");
    $pdo->exec("ALTER TABLE blog_posts ADD COLUMN is_highlighted BOOLEAN NOT NULL DEFAULT 0 AFTER status");
    $pdo->exec("ALTER TABLE blog_posts ADD FOREIGN KEY (category_id) REFERENCES blog_categories(id) ON DELETE SET NULL");
    
    echo "<h1>Success!</h1><p>Blog system database has been fully updated.</p>";

} catch (PDOException $e) {
    die("<h1>Error!</h1><p>" . $e->getMessage() . "</p>");
}
?>