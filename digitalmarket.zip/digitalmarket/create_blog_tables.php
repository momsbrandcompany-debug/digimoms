<?php
// create_blog_tables.php
require_once 'db_config.php';

try {
    // 1. Create blog_categories table
    $sql_categories = "CREATE TABLE IF NOT EXISTS blog_categories (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL UNIQUE,
        slug VARCHAR(100) NOT NULL UNIQUE
    )";
    $pdo->exec($sql_categories);
    echo "Table 'blog_categories' created successfully.<br>";

    // 2. Create blog_posts table
    $sql_posts = "CREATE TABLE IF NOT EXISTS blog_posts (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        category_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) NOT NULL UNIQUE,
        content TEXT NOT NULL,
        featured_image VARCHAR(255) NULL,
        status ENUM('Published', 'Draft') NOT NULL DEFAULT 'Published',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES blog_categories(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql_posts);
    echo "Table 'blog_posts' created successfully.<br>";

    echo "Blog module tables are ready!";

} catch(PDOException $e) {
    die("ERROR: Could not execute script. " . $e->getMessage());
}

// Close connection
unset($pdo);
?>