<?php
require_once 'db_config.php';

try {
    // Check if the 'rank' column already exists to avoid errors
    $stmt_check = $pdo->query("SHOW COLUMNS FROM `partners` LIKE 'rank'");
    $column_exists = $stmt_check->fetch();

    if ($column_exists) {
        echo "<h1>Already Updated!</h1><p>The 'rank' column already exists in the 'partners' table.</p>";
    } else {
        // SQL statement to add the new 'rank' column
        // All new partners will start as 'Bronze' by default.
        $sql = "ALTER TABLE partners ADD COLUMN `rank` ENUM('Bronze', 'Silver', 'Gold') NOT NULL DEFAULT 'Bronze' AFTER `status`";
        $pdo->exec($sql);
        echo "<h1>Success!</h1><p>The 'rank' column has been added to the 'partners' table successfully.</p>";
    }

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not alter the table. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>