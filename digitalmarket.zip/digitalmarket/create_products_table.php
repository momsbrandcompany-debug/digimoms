<?php
// create_products_table.php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS products (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        thumbnail VARCHAR(255) NOT NULL,
        demo_preview_link VARCHAR(255) NULL,
        market_price DECIMAL(10, 2) DEFAULT 0.00,
        sale_price DECIMAL(10, 2) NOT NULL,
        download_file_link VARCHAR(255) NULL,
        course_video_link VARCHAR(255) NULL,
        description TEXT NULL,
        file_size VARCHAR(50) NULL,
        file_format VARCHAR(50) NULL,
        status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )";

    $pdo->exec($sql);
    echo "Table 'products' created successfully.";

} catch(PDOException $e) {
    die("ERROR: Could not able to execute $sql. " . $e->getMessage());
}

// Close connection
unset($pdo);
?>