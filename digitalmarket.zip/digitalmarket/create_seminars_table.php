<?php
require_once 'db_config.php';

try {
    // This is a completely new and separate table for seminars
    $sql = "CREATE TABLE IF NOT EXISTS seminars (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        thumbnail VARCHAR(255) NULL,
        price DECIMAL(10, 2) NOT NULL,
        trainer_id INT NOT NULL,
        status ENUM('Pending', 'Active', 'Inactive', 'Completed') NOT NULL DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (trainer_id) REFERENCES partners(id) ON DELETE CASCADE
    )";

    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'seminars' has been created successfully.</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not create 'seminars' table. Error: " . $e->getMessage() . "</p>");
}
?>