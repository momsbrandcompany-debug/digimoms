<?php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS coupons (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        coupon_code VARCHAR(50) NOT NULL UNIQUE,
        discount_type ENUM('percentage', 'fixed') NOT NULL DEFAULT 'percentage',
        discount_value DECIMAL(10, 2) NOT NULL,
        partner_id INT NULL, -- Link to the partner who created it
        product_id INT NULL, -- Optional: to make it product-specific
        usage_limit INT NOT NULL DEFAULT 100,
        times_used INT NOT NULL DEFAULT 0,
        status ENUM('Pending', 'Active', 'Expired', 'Blocked') NOT NULL DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
    )";

    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'coupons' has been created successfully.</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not create table. Error: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>
