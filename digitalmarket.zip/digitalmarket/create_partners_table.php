<?php
// create_partners_table.php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS partners (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        mobile VARCHAR(15) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        age INT NULL,
        profession VARCHAR(100) NULL,
        alternative_mobile VARCHAR(15) NULL,
        address TEXT NULL,
        payment_details TEXT NULL COMMENT 'Stores UPI ID or Bank Details',
        aadhar_card_path VARCHAR(255) NULL,
        status ENUM('Pending', 'Approved', 'Blocked') NOT NULL DEFAULT 'Pending',
        referred_by_partner_id INT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )";

    $pdo->exec($sql);
    echo "Table 'partners' created successfully.";

} catch(PDOException $e) {
    die("ERROR: Could not able to execute $sql. " . $e->getMessage());
}

// Close connection
unset($pdo);
?>