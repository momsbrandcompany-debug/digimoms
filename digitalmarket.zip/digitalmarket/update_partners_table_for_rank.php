<?php
require_once 'db_config.php';
try {
    $sql = "ALTER TABLE partners ADD COLUMN rank ENUM('Bronze', 'Silver', 'Gold') NOT NULL DEFAULT 'Bronze' AFTER status";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>'rank' column added to 'partners' table.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not alter table. " . $e->getMessage() . "</p>");
}
?>