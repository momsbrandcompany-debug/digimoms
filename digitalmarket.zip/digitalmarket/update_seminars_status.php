<?php
require_once 'db_config.php';
try {
    // Modify the 'status' column in the 'seminars' table to include 'Completed'
    $sql = "ALTER TABLE seminars MODIFY COLUMN `status` ENUM('Pending', 'Active', 'Inactive', 'Completed') NOT NULL DEFAULT 'Pending'";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>'seminars' table has been updated to include 'Completed' status.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not update table. Error: " . $e->getMessage() . "</p>");
}
?>