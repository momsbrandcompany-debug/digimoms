<?php
// --- STEP 1: INITIALIZATION AND ACTION PROCESSING (BEFORE ANY HTML) ---
// We start the session and include db_config manually before any output.
session_start();
require_once '../db_config.php';

// Check if admin is logged in
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// --- Handle Link Generation Action ---
if (isset($_GET['action']) && $_GET['action'] === 'generate' && isset($_GET['id'])) {
    $request_id = (int)$_GET['id'];
    try {
        // Generate a secure, unique token
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour')); // Link is valid for 1 hour

        $sql = "UPDATE password_resets SET token = :token, expires_at = :expires WHERE id = :id AND status = 'Pending'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['token' => $token, 'expires' => $expires, 'id' => $request_id]);
        
        // This header call will now work correctly
        header("Location: password_resets.php?status=generated");
        exit; // IMPORTANT: Always exit after a header redirect.
    } catch (PDOException $e) {
        header("Location: password_resets.php?status=error");
        exit;
    }
}

// --- STEP 2: FETCH DATA FOR DISPLAY ---
// Now that all processing is done, we can fetch the data needed for the page.
try {
    $stmt = $pdo->query("SELECT * FROM password_resets ORDER BY status = 'Pending' DESC, request_date DESC");
    $all_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $all_requests = [];
    $error_message = "Database Error: " . $e->getMessage();
}


// --- STEP 3: INCLUDE THE VISUAL HEADER ---
// Now we can safely include the HTML header.
include 'header.php';
?>

<!-- HTML AND CSS FOR THE PAGE -->
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .table-panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: top; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; background-color: #f8f9fa; }
    .btn-action { text-decoration: none; padding: 8px 15px; border-radius: 5px; color: white; font-weight: 500; }
    .btn-generate { background-color: #007bff; }
    .link-display { display: flex; align-items: center; gap: 10px; }
    .link-input { flex-grow: 1; padding: 8px; border: 1px solid #ddd; border-radius: 4px; background-color: #f9f9f9; }
    .copy-btn { padding: 8px 12px; border: none; background-color: #28a745; color: white; cursor: pointer; border-radius: 4px; }
    .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: 600; }
    .status-Pending { background-color: #ffc107; color: #333; }
    .status-Completed { background-color: #6c757d; color: white; }
</style>

<h1 class="page-header">Password Reset Requests</h1>

<?php if (isset($error_message)) echo '<div class="alert-error">' . $error_message . '</div>'; ?>
<?php if (isset($_GET['status']) && $_GET['status'] == 'generated') echo '<div class="alert-success" style="background-color: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">Link generated successfully! You can now copy it and send it to the user.</div>'; ?>

<div class="table-panel">
    <table class="table">
        <thead>
            <tr>
                <th>User Mobile</th>
                <th>Request Date</th>
                <th>Status</th>
                <th>Reset Link / Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($all_requests)): ?>
                <?php foreach ($all_requests as $request): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($request['user_mobile']); ?></strong></td>
                        <td><?php echo date('d M Y, h:i A', strtotime($request['request_date'])); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $request['status']; ?>"><?php echo $request['status']; ?></span>
                        </td>
                        <td>
                            <?php if ($request['status'] === 'Pending' && $request['token'] === 'pending_generation'): ?>
                                <a href="password_resets.php?action=generate&id=<?php echo $request['id']; ?>" class="btn-action btn-generate">Generate Link</a>
                            <?php elseif ($request['status'] === 'Pending' && $request['token'] !== 'pending_generation'): ?>
                                <?php $reset_link = "http://localhost/digitalmarket/public/reset_password.php?token=" . $request['token']; ?>
                                <div class="link-display">
                                    <input type="text" value="<?php echo $reset_link; ?>" class="link-input" readonly>
                                    <button class="copy-btn" onclick="copyToClipboard(this)">Copy</button>
                                </div>
                            <?php else: // Status is 'Completed' ?>
                                Link Used
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align:center; padding: 20px;">No password reset requests found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
function copyToClipboard(button) {
    // Find the input field next to the button
    let inputField = button.previousElementSibling;
    inputField.select();
    inputField.setSelectionRange(0, 99999); // For mobile devices
    document.execCommand("copy");
    button.innerText = "Copied!";
    setTimeout(function(){ button.innerText = "Copy"; }, 2000); // Reset button text after 2 seconds
}
</script>

<?php include 'footer.php'; ?>