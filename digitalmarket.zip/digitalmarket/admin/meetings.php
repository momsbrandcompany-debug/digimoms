<?php
include 'header.php'; // Includes admin session check, db connection etc.

$message = '';
$message_type = '';

// --- Handle Actions (Add, Activate, Delete) ---
// This part is now at the top to prevent "headers already sent" errors.
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_meeting'])) {
    // Add a new meeting
    $title = trim($_POST['title']);
    $link = trim($_POST['link']);
    $passcode = trim($_POST['passcode']);
    $datetime = $_POST['datetime']; // This is the value from the form field

    // --- THIS IS THE FIX ---
    // The column in the database is `meeting_date`, not `datetime`.
    try {
        $sql = "INSERT INTO live_meetings (meeting_title, meeting_link, passcode, meeting_date, is_active) 
                VALUES (:title, :link, :passcode, :meeting_date, 0)"; // Using the correct column name `:meeting_date`
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'title' => $title, 
            'link' => $link, 
            'passcode' => $passcode, 
            'meeting_date' => $datetime // Passing the value to the correct parameter
        ]);
        header("Location: meetings.php?status=added");
        exit;
    } catch (PDOException $e) {
        // Redirect with an error message
        header("Location: meetings.php?status=error&msg=" . urlencode($e->getMessage()));
        exit;
    }
}

if (isset($_GET['action']) && isset($_GET['id'])) {
    $meeting_id = (int)$_GET['id'];
    $action = $_GET['action'];

    if ($action === 'activate') {
        $pdo->exec("UPDATE live_meetings SET is_active = 0"); // Deactivate all others first
        $stmt = $pdo->prepare("UPDATE live_meetings SET is_active = 1 WHERE id = :id");
        $stmt->execute(['id' => $meeting_id]);
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM live_meetings WHERE id = :id");
        $stmt->execute(['id' => $meeting_id]);
    }
    header("Location: meetings.php?status=success");
    exit;
}

// --- Fetch Data for Display ---
$all_meetings = $pdo->query("SELECT * FROM live_meetings ORDER BY meeting_date DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
    /* Re-use admin styles - no changes needed here */
    .page-header { font-size: 28px; color: #1a253c; }
    .panel { background-color:#fff; padding:25px; border-radius:8px; box-shadow:0 4px 15px rgba(0,0,0,0.07); margin-bottom:30px; }
    .btn-action { text-decoration:none; padding:5px 10px; border-radius:4px; color:white; margin-right:5px; font-size:13px; }
    .btn-activate { background-color:#28a745; }
    .btn-delete { background-color:#dc3545; }
    .active-row { background-color: #d4edda !important; font-weight: bold; }
    .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
    .alert-success { background-color: #d4edda; color: #155724; }
    .alert-error { background-color: #f8d7da; color: #721c24; }
</style>

<h1 class="page-header">Live Meeting Scheduler</h1>

<?php if(isset($_GET['status'])): ?>
    <?php if($_GET['status'] == 'added'): ?>
        <div class="alert alert-success">New meeting scheduled successfully.</div>
    <?php elseif($_GET['status'] == 'success'): ?>
        <div class="alert alert-success">Action completed successfully.</div>
    <?php elseif($_GET['status'] == 'error'): ?>
        <div class="alert alert-error">An error occurred: <?php echo htmlspecialchars($_GET['msg'] ?? 'Please try again.'); ?></div>
    <?php endif; ?>
<?php endif; ?>


<!-- Form to schedule a new meeting -->
<div class="panel">
    <h2 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:15px;">Schedule a New Meeting</h2>
    <form action="meetings.php" method="POST">
        <div class="form-group" style="margin-bottom:15px;">
            <label>Meeting Title</label>
            <input type="text" name="title" class="form-control" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
        </div>
        <div class="form-group" style="margin-bottom:15px;">
            <label>Date and Time</label>
            <input type="datetime-local" name="datetime" class="form-control" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
        </div>
        <div class="form-group" style="margin-bottom:15px;">
            <label>Meeting Link (Zoom, etc.)</label>
            <input type="url" name="link" class="form-control" required placeholder="https://..." style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
        </div>
        <div class="form-group" style="margin-bottom:15px;">
            <label>Meeting Passcode</label>
            <input type="text" name="passcode" class="form-control" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
        </div>
        <button type="submit" name="add_meeting" style="padding:10px 20px; border:none; background-color:#007bff; color:white; cursor:pointer; border-radius:5px;">Schedule Meeting</button>
    </form>
</div>

<!-- List of all scheduled meetings -->
<div class="panel">
    <h2 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:15px;">Scheduled Meetings</h2>
    <table class="table" style="width:100%; border-collapse:collapse;">
        <thead>
            <tr><th>Date & Time</th><th>Title</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php if (!empty($all_meetings)): ?>
                <?php foreach ($all_meetings as $meeting): ?>
                    <tr class="<?php if($meeting['is_active']) echo 'active-row'; ?>">
                        <td><?php echo date('d M Y, h:i A', strtotime($meeting['meeting_date'])); ?></td>
                        <td><?php echo htmlspecialchars($meeting['meeting_title']); ?></td>
                        <td><?php echo $meeting['is_active'] ? '<strong>Active</strong>' : 'Inactive'; ?></td>
                        <td>
                            <?php if (!$meeting['is_active']): ?>
                                <a href="meetings.php?action=activate&id=<?php echo $meeting['id']; ?>" class="btn-action btn-activate">Activate</a>
                            <?php endif; ?>
                            <a href="meetings.php?action=delete&id=<?php echo $meeting['id']; ?>" class="btn-action btn-delete" onclick="return confirm('Are you sure you want to delete this meeting?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align:center; padding:20px;">No meetings scheduled yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>