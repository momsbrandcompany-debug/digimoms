<?php
// Start session and include database connection centrally
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../db_config.php'; // Correctly include the db config

// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - DigiMoms</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f7fA;
            margin: 0;
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #1a253c;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            font-size: 24px;
            font-weight: 700;
            border-bottom: 1px solid #344059;
        }
        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li a {
            display: block;
            color: #ccc;
            padding: 18px 20px;
            text-decoration: none;
            transition: background-color 0.3s, color 0.3s;
        }
        .sidebar-nav li a:hover, .sidebar-nav li a.active {
            background-color: #007bff;
            color: white;
        }
        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
            padding: 0;
        }
        .top-navbar {
            background-color: #ffffff;
            padding: 15px 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }
        .top-navbar a {
            background-color: #dc3545;
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
        .page-content {
            padding: 30px;
        }
        .page-header {
            font-size: 28px;
            color: #1a253c;
            margin-top: 0;
            margin-bottom: 20px;
        }
        /* Form Styles */
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        .btn-submit {
            padding: 12px 25px;
            border: none;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>


<!-- পুরোনো script ট্যাগটি মুছে এটি পেস্ট করুন -->
<script src="https://cdn.tiny.cloud/1/y2b6hsioildxg1ss1x6sud2xi4i9t74y25jat2xayptem5hd/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: 'textarea#post_content',
    plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
    toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
  });
</script>
</head>
<body>


</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            DigiMoms
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="products.php" class="active">Products</a></li>
            <li><a href="blog_manager.php">Blog Manager</a></li>
            <li><a href="partners.php">Partners</a></li>
            <li><a href="coupons.php">Coupon Management</a></li>
            <li><a href="sales.php">Sales Report</a></li>
            <li><a href="payouts.php">Payout Requests</a></li>
            <li><a href="password_resets.php">Password Resets</a></li>
            <li><a href="meetings.php">Live Meetings</a></li>
            <li><a href="trainers.php">Trainer Applications</a></li>
            <li><a href="seminars.php">Seminar Approvals</a></li>
            <li><a href="trainer_payouts.php">Trainer Payouts</a></li>
            <li><a href="#">Customers</a></li>
            <li><a href="#">Orders</a></li>
            <li><a href="#">Settings</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="top-navbar">
            <span>Welcome, <b><?php echo htmlspecialchars($_SESSION["admin_username"]); ?></b></span>
            <a href="logout.php" style="margin-left: 20px;">Logout</a>
        </div>
        <div class="page-content">