<?php
include 'header.php';
require_once '../db_config.php';

// Fetch all products from the database
try {
    $stmt = $pdo->query("SELECT id, title, category, sale_price, status, thumbnail FROM products ORDER BY created_at DESC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Could not retrieve products: " . $e->getMessage());
}
?>

<style>
    .product-table { width: 100%; border-collapse: collapse; }
    .product-table th, .product-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    .product-table th { background-color: #f2f2f2; font-weight: 600; }
    .product-table td img { width: 80px; height: auto; border-radius: 5px; }
    .actions a { text-decoration: none; padding: 5px 10px; border-radius: 4px; color: white; margin-right: 5px; }
    .btn-edit { background-color: #007bff; }
    .btn-delete { background-color: #dc3545; }
    .add-new-btn {
        display: inline-block;
        background-color: #28a745;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        margin-bottom: 20px;
        font-weight: 600;
    }
</style>

<div style="display: flex; justify-content: space-between; align-items: center;">
    <h1 class="page-header">Manage Products</h1>
    <a href="add_product.php" class="add-new-btn">Add New Product</a>
</div>


<div class="form-container">
    <table class="product-table">
        <thead>
            <tr>
                <th>Thumbnail</th>
                <th>Title</th>
                <th>Category</th>
                <th>Sale Price (₹)</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($products) > 0): ?>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><img src="../<?php echo htmlspecialchars($product['thumbnail']); ?>" alt="<?php echo htmlspecialchars($product['title']); ?>"></td>
                        <td><?php echo htmlspecialchars($product['title']); ?></td>
                        <td><?php echo htmlspecialchars($product['category']); ?></td>
                        <td><?php echo htmlspecialchars($product['sale_price']); ?></td>
                        <td><?php echo htmlspecialchars($product['status']); ?></td>
                        <td class="actions">
                            <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn-edit">Edit</a>
                            <a href="delete_product.php?id=<?php echo $product['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this product? This action cannot be undone.');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align: center;">No products found. Please add a new product.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
include 'footer.php';
?>
