<?php
// --- admin/init.php ---

// 1. Start or resume the session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Database Configuration (Path is relative to this file's location)
require_once __DIR__ . '/../db_config.php';

// 3. Admin Authentication Check
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    if (basename($_SERVER['PHP_SELF']) !== 'login.php') {
        header("location: login.php");
        exit;
    }
}
?>