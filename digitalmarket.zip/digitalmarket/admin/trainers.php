<?php
require_once 'init.php'; // Handles admin session, db connection, and auth

// --- THIS IS THE FIX: Handle status change on the correct table ('partners') ---
if (isset($_GET['action']) && isset($_GET['partner_id'])) {
    $partner_id_to_update = (int)$_GET['partner_id'];
    $action = $_GET['action'];
    
    try {
        if ($action === 'approve') {
            // When approved, update the status in the 'partners' table
            $stmt = $pdo->prepare("UPDATE partners SET trainer_status = 'approved' WHERE id = :id");
            $stmt->execute(['id' => $partner_id_to_update]);
        } elseif ($action === 'reject') {
            // When rejected, update the status in the 'partners' table
            $stmt = $pdo->prepare("UPDATE partners SET trainer_status = 'rejected' WHERE id = :id");
            $stmt->execute(['id' => $partner_id_to_update]);
        }
        header("Location: trainers.php?status=success");
        exit;
    } catch (PDOException $e) {
        header("Location: trainers.php?status=error");
        exit;
    }
}

// Fetch all partners who have applied to be a trainer
// We select from the 'partners' table where the status is not 'none'
try {
    $stmt_apps = $pdo->query(
        "SELECT id, name, mobile, govt_id_path, trainer_status 
         FROM partners 
         WHERE trainer_status != 'none' 
         ORDER BY trainer_status = 'pending' DESC, id DESC"
    );
    $applications = $stmt_apps->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $applications = [];
    $error_message = "Database Error: " . $e->getMessage();
}

include 'header.php';
?>

<!-- Your entire beautiful HTML and CSS from the previous step is restored and improved -->
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .table-panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: middle; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; background-color: #f8f9fa; }
    .id-proof-link { font-weight: 600; text-decoration: none; color: #007bff; }
    .btn-action { text-decoration: none; padding: 8px 15px; border-radius: 5px; color: white; font-weight: 500; font-size: 14px; }
    .btn-approve { background-color: #28a745; }
    .btn-reject { background-color: #dc3545; }
    .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: 600; }
    .status-pending { background-color: #ffc107; color: #333; }
    .status-approved { background-color: #17a2b8; color: white; }
    .status-rejected { background-color: #6c757d; color: white; }
</style>

<h1 class="page-header">Trainer Applications</h1>

<div class="table-panel">
    <table class="table">
        <thead>
            <tr>
                <th>Partner Name</th>
                <th>Mobile</th>
                <th>Govt. ID Proof</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($applications)): ?>
                <?php foreach ($applications as $app): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($app['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($app['mobile']); ?></td>
                        <td>
                            <?php if (!empty($app['govt_id_path'])): ?>
                                <a href="../<?php echo htmlspecialchars($app['govt_id_path']); ?>" target="_blank" class="id-proof-link">View ID</a>
                            <?php else: ?>
                                Not Provided
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="status-badge status-<?php echo strtolower($app['trainer_status']); ?>">
                                <?php echo ucfirst($app['trainer_status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($app['trainer_status'] === 'pending'): ?>
                                <a href="trainers.php?action=approve&partner_id=<?php echo $app['id']; ?>" class="btn-action btn-approve">Approve</a>
                                <a href="trainers.php?action=reject&partner_id=<?php echo $app['id']; ?>" class="btn-action btn-reject">Reject</a>
                            <?php else: ?>
                                Action Taken
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align:center; padding: 20px;">No trainer applications found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>