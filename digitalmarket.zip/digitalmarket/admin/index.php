<?php
// header.php includes session check and db connection
include 'header.php';

// --- Fetching Dashboard Statistics ---
try {
    // 1. Total Sales Amount (Total Revenue)
    $total_revenue = $pdo->query("SELECT SUM(sale_amount) FROM sales")->fetchColumn();

    // 2. Total Number of Sales
    $total_sales_count = $pdo->query("SELECT COUNT(id) FROM sales")->fetchColumn();

    // 3. Total Partners (Approved)
    $total_partners = $pdo->query("SELECT COUNT(id) FROM partners WHERE status = 'Approved'")->fetchColumn();
    
    // 4. Total Commission Paid (This will be 0 for now, we will build this later)
    $total_commission_paid = 0.00;

} catch (PDOException $e) {
    // In case of error, set default values
    $total_revenue = 0;
    $total_sales_count = 0;
    $total_partners = 0;
    $total_commission_paid = 0;
    echo "Database error: " . $e->getMessage(); // Show error for debugging
}
?>
<style>
    .page-header { font-size: 28px; color: #1a253c; margin-top: 0; margin-bottom: 20px; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .stat-card { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px S10px rgba(0,0,0,0.08); border-left: 5px solid #007bff; }
    .stat-card h3 { margin: 0 0 10px 0; font-size: 16px; color: #555; text-transform: uppercase; }
    .stat-card .amount { font-size: 32px; font-weight: 700; color: #2c3e50; }
    .stat-card.sales { border-left-color: #28a745; }
    .stat-card.partners { border-left-color: #ffc107; }
    .stat-card.commission { border-left-color: #dc3545; }
</style>

<h1 class="page-header">Admin Dashboard</h1>

<div class="stats-grid">
    <div class="stat-card sales">
        <h3>Total Revenue</h3>
        <p class="amount">₹<?php echo number_format($total_revenue ?? 0, 2); ?></p>
    </div>
    <div class="stat-card">
        <h3>Total Sales</h3>
        <p class="amount"><?php echo $total_sales_count ?? 0; ?></p>
    </div>
    <div class="stat-card partners">
        <h3>Active Partners</h3>
        <p class="amount"><?php echo $total_partners ?? 0; ?></p>
    </div>
    <div class="stat-card commission">
        <h3>Total Commission Paid</h3>
        <p class="amount">₹<?php echo number_format($total_commission_paid, 2); ?></p>
    </div>
</div>

<!-- We can add charts and recent activity here in a future step -->

<?php
// Include the footer
include 'footer.php';
?>