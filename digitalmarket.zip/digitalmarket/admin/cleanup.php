<?php
require_once 'init.php'; // Handles admin session, db connection

$message = '';
$message_type = 'info';

// --- Handle the Cleanup Action ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_cleanup'])) {
    if (isset($_POST['confirmation_text']) && $_POST['confirmation_text'] === 'DELETE ALL DATA') {
        
        $tables_to_truncate = [
            'seminar_attendees',
            'sales',
            'payout_history',
            'password_resets',
            'seminars',
            'coupons',
        ];

        $tables_to_delete_from = [
            'partners',
            'users'
        ];

        try {
            // Disable foreign key checks to avoid errors when truncating tables
            $pdo->exec('SET foreign_key_checks = 0');

            foreach ($tables_to_truncate as $table) {
                // Check if table exists before truncating
                $stmt_check = $pdo->query("SHOW TABLES LIKE '{$table}'");
                if ($stmt_check->rowCount() > 0) {
                    $pdo->exec("TRUNCATE TABLE `{$table}`");
                }
            }

            foreach ($tables_to_delete_from as $table) {
                // Check if table exists before deleting
                $stmt_check = $pdo->query("SHOW TABLES LIKE '{$table}'");
                if ($stmt_check->rowCount() > 0) {
                    $pdo->exec("DELETE FROM `{$table}`");
                }
            }

            // IMPORTANT: Re-enable foreign key checks
            $pdo->exec('SET foreign_key_checks = 1');

            $message = "System cleanup successful! All transactional data, users, and partners have been deleted. Your products, blogs, and admins remain safe.";
            $message_type = 'success';

        } catch (PDOException $e) {
            // Re-enable foreign key checks even if an error occurs
            $pdo->exec('SET foreign_key_checks = 1');
            $message = "An error occurred during cleanup: " . $e->getMessage();
            $message_type = 'error';
        }
    } else {
        $message = "Confirmation text did not match. Cleanup process aborted.";
        $message_type = 'error';
    }
}

include 'header.php';
?>

<!-- Your entire beautiful HTML and CSS from the previous correct version are restored -->
<style>
    .page-header { font-size: 28px; color: #dc3545; }
    .cleanup-panel { background-color: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); border: 2px solid #dc3545; }
    .cleanup-panel h2 { color: #dc3545; margin-top: 0; }
    .warning-list { list-style-type: '⚠️'; padding-left: 20px; }
    .warning-list li { margin-bottom: 10px; }
    .confirmation-form { margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px; }
    .form-group { margin-bottom: 20px; }
    label { font-weight: 600; display: block; margin-bottom: 8px; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 16px; }
    .btn-danger { width: 100%; padding: 15px; border: none; background-color: #dc3545; color: white; font-size: 18px; cursor: pointer; border-radius: 8px; font-weight: 700; }
    .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 500; }
    .alert-success { background-color: #d4edda; color: #155724; }
    .alert-error { background-color: #f8d7da; color: #721c24; }
</style>

<h1 class="page-header">System Data Cleanup</h1>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
<?php endif; ?>

<div class="cleanup-panel">
    <h2><span class="icon">🚨</span> Extreme Danger Zone!</h2>
    <p>This action is irreversible and will permanently delete all transactional data from your website. Please read the following points carefully before proceeding.</p>

    <ul class="warning-list">
        <li>All <strong>Sales, Payouts, Seminar Attendees,</strong> and <strong>Password Resets</strong> will be deleted.</li>
        <li>All <strong>Partner, Trainer,</strong> and <strong>Student/User</strong> accounts will be deleted.</li>
        <li>All created <strong>Seminars</strong> and <strong>Coupons</strong> will be deleted.</li>
        <li>Your <strong>Products, Blog Posts, Blog Categories, and Admin Accounts</strong> will <strong>NOT</strong> be deleted.</li>
    </ul>

    <p>This is useful for cleaning up test data before launching your website. <strong>DO NOT</strong> perform this action on a live site unless you are absolutely sure.</p>

    <form class="confirmation-form" action="cleanup.php" method="POST" onsubmit="return confirm('FINAL WARNING:\n\nThis action cannot be undone. Are you absolutely sure?');">
        <div class="form-group">
            <label for="confirmation_text">To confirm, please type "DELETE ALL DATA" in the box below:</label>
            <input type="text" id="confirmation_text" name="confirmation_text" class="form-control" autocomplete="off" required>
        </div>
        <button type="submit" name="confirm_cleanup" class="btn-danger">I Understand, Delete All Transactional Data</button>
    </form>
</div>

<?php include 'footer.php'; ?>