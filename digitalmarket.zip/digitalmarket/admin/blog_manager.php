<?php
require_once 'init.php';
$edit_mode = false;
$post_to_edit = null;

// --- Handle DELETE Action ---
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM blog_posts WHERE id = ?");
    $stmt->execute([$delete_id]);
    header("Location: blog_manager.php?status=deleted"); exit;
}

// --- Handle ADD or EDIT Action on POST ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $category_id = (int)$_POST['category_id'];
    $content = $_POST['content']; // Do not escape HTML content from the form
    
    // Thumbnail handling
    $thumbnail_path = $_POST['existing_thumbnail'] ?? '';
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        // ... (File upload logic)
    }

    if (isset($_POST['update_post'])) { // UPDATE existing post
        $post_id = (int)$_POST['post_id'];
        $sql = "UPDATE blog_posts SET title = ?, category_id = ?, content = ?, thumbnail = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$title, $category_id, $content, $thumbnail_path, $post_id]);
        header("Location: blog_manager.php?status=updated"); exit;
    } else { // ADD new post
        $sql = "INSERT INTO blog_posts (title, category_id, content, thumbnail, status) VALUES (?, ?, ?, ?, 'Published')";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$title, $category_id, $content, $thumbnail_path]);
        header("Location: blog_manager.php?status=added"); exit;
    }
}

// --- Prepare data for the page ---
if (isset($_GET['edit_id'])) {
    $edit_mode = true;
    $stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->execute([$_GET['edit_id']]);
    $post_to_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}
$posts = $pdo->query("SELECT bp.*, bc.name as cat_name FROM blog_posts bp LEFT JOIN blog_categories bc ON bp.category_id = bc.id ORDER BY bp.id DESC")->fetchAll(PDO::FETCH_ASSOC);
$categories = $pdo->query("SELECT * FROM blog_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>

<style>
    .highlight-instruction { background-color: #e9f4ff; border-left: 4px solid #007bff; padding: 15px; margin-bottom: 20px; }
    .highlight-instruction code { background-color: #d1d1d1; padding: 2px 5px; border-radius: 3px; }
</style>

<h1 class="page-header"><?php echo $edit_mode ? 'Edit Blog Post' : 'Blog Manager'; ?></h1>

<div class="panel">
    <h2 class="panel-title"><?php echo $edit_mode ? 'Update Post Details' : 'Add a New Post'; ?></h2>
    <form action="blog_manager.php<?php if($edit_mode) echo '?edit_id=' . ($post_to_edit['id'] ?? ''); ?>" method="POST" enctype="multipart/form-data">
        <?php if ($edit_mode): ?><input type="hidden" name="post_id" value="<?php echo $post_to_edit['id']; ?>"><input type="hidden" name="existing_thumbnail" value="<?php echo $post_to_edit['thumbnail']; ?>"><?php endif; ?>

        <div class="form-group"><label>Post Title</label><input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($post_to_edit['title'] ?? ''); ?>" required></div>
        <div class="form-group"><label>Thumbnail Image</label><input type="file" name="thumbnail" class="form-control" <?php if(!$edit_mode) echo 'required'; ?>></div>
        <div class="form-group">
            <label>Category</label>
            <select name="category_id" class="form-control" required>
                <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>" <?php if(isset($post_to_edit['category_id']) && $post_to_edit['category_id'] == $cat['id']) echo 'selected'; ?>><?php echo htmlspecialchars($cat['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label>Content</label>
            <div class="highlight-instruction">
                <p><strong>How to Highlight:</strong> To highlight text, use HTML tags. Example: `This is <b>bold</b> text.` or `This is a <a href="your-link">link</a>`.</p>
                <p>For special highlights: `This is a <span class="custom-highlight">special text</span>.`</p>
            </div>
            <textarea name="content" class="form-control" rows="15"><?php echo htmlspecialchars($post_to_edit['content'] ?? ''); ?></textarea>
        </div>
        
        <?php if ($edit_mode): ?>
            <button type="submit" name="update_post" class="btn-primary">Update Post</button>
        <?php else: ?>
            <button type="submit" name="save_post" class="btn-primary">Publish Post</button>
        <?php endif; ?>
    </form>
</div>

<div class="panel">
    <h2 class="panel-title">Existing Blog Posts</h2>
    <table class="table">
        <thead><tr><th>Title</th><th>Category</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($posts as $post): ?>
            <tr>
                <td><?php echo htmlspecialchars($post['title']); ?></td>
                <td><?php echo htmlspecialchars($post['cat_name']); ?></td>
                <td>
                    <a href="blog_manager.php?edit_id=<?php echo $post['id']; ?>">Edit</a> |
                    <a href="blog_manager.php?delete_id=<?php echo $post['id']; ?>" onclick="return confirm('Are you sure?');">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>