<?php
require_once 'init.php'; // Handles admin session, db connection

// --- Handle All Actions (Add, Update, Delete) ---
$edit_mode = false;
$category_to_edit = null;

// Handle form submissions for ADD or UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    // Auto-generate a URL-friendly slug from the name
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    
    if (isset($_POST['update_category'])) {
        // --- UPDATE existing category ---
        $id = (int)$_POST['category_id'];
        $stmt = $pdo->prepare("UPDATE blog_categories SET name = :name, slug = :slug WHERE id = :id");
        $stmt->execute(['name' => $name, 'slug' => $slug, 'id' => $id]);
        header("Location: blog_categories.php?status=updated");
        exit;
    } else { // It's an ADD request
        // --- ADD new category ---
        try {
            $stmt = $pdo->prepare("INSERT INTO blog_categories (name, slug) VALUES (:name, :slug)");
            $stmt->execute(['name' => $name, 'slug' => $slug]);
            header("Location: blog_categories.php?status=added");
            exit;
        } catch (PDOException $e) {
            // Handle case where name/slug is not unique
            header("Location: blog_categories.php?status=error");
            exit;
        }
    }
}

// Handle DELETE action from URL
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM blog_categories WHERE id = :id");
    $stmt->execute(['id' => $id]);
    header("Location: blog_categories.php?status=deleted");
    exit;
}

// Handle EDIT mode (to show data in the form)
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $edit_mode = true;
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM blog_categories WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $category_to_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch all categories to display in the list
$categories = $pdo->query("SELECT * FROM blog_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); margin-bottom: 30px; }
    .table-panel { margin-top: 30px; }
    .form-inline { display: flex; gap: 10px; align-items: flex-end; }
    .form-group { flex-grow: 1; }
    .btn-primary, .btn-secondary { padding: 10px 20px; border: none; cursor: pointer; border-radius: 5px; font-size: 15px; text-decoration: none; color: white; }
    .btn-primary { background-color: #007bff; }
    .btn-secondary { background-color: #6c757d; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
    .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
</style>

<h1 class="page-header">Blog Categories</h1>

<?php if(isset($_GET['status'])) echo '<div class="alert">Action completed successfully!</div>'; ?>

<div class="panel">
    <h2><?php echo $edit_mode ? 'Edit Category' : 'Add New Category'; ?></h2>
    <form class="form-inline" action="blog_categories.php" method="POST">
        <?php if ($edit_mode): ?>
            <input type="hidden" name="category_id" value="<?php echo $category_to_edit['id']; ?>">
        <?php endif; ?>
        <div class="form-group">
            <label>Category Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($category_to_edit['name'] ?? ''); ?>" required>
        </div>
        <?php if ($edit_mode): ?>
            <button type="submit" name="update_category" class="btn-primary">Update</button>
            <a href="blog_categories.php" class="btn-secondary">Cancel</a>
        <?php else: ?>
            <button type="submit" name="add_category" class="btn-primary">Add Category</button>
        <?php endif; ?>
    </form>
</div>

<div class="panel table-panel">
    <h2>Existing Categories</h2>
    <table class="table">
        <thead><tr><th>Category Name</th><th>URL Slug</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($categories as $cat): ?>
            <tr>
                <td><?php echo htmlspecialchars($cat['name']); ?></td>
                <td><?php echo htmlspecialchars($cat['slug']); ?></td>
                <td>
                    <a href="blog_categories.php?action=edit&id=<?php echo $cat['id']; ?>">Edit</a> | 
                    <a href="blog_categories.php?action=delete&id=<?php echo $cat['id']; ?>" onclick="return confirm('Are you sure? Deleting a category will also delete all posts within it.');" style="color:red;">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>