<?php
include 'header.php';
require_once '../db_config.php';

// Handle status change if a form is submitted
// Check if the form was submitted by checking for the 'change_status' button value
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_status'])) {
    $partner_id = $_POST['partner_id'];
    $new_status = $_POST['new_status'];

    try {
        $stmt = $pdo->prepare("UPDATE partners SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $partner_id]);
        // To see the change immediately, we don't need to do anything else as the page will reload
    } catch (PDOException $e) {
        echo "<div class='alert alert-danger'>Error updating status: " . $e->getMessage() . "</div>";
    }
}

// Fetch all partners from the database
try {
    // We will also fetch some basic earning stats (this is a placeholder for now)
    $stmt = $pdo->query("SELECT id, name, mobile, email, status FROM partners ORDER BY created_at DESC");
    $partners = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching partners: " . $e->getMessage());
}
?>

<h1 class="page-header">Partner Management</h1>

<div class="form-container">
    <table width="100%" border="1" style="border-collapse: collapse; text-align: left;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th style="padding: 10px;">Partner Name</th>
                <th style="padding: 10px;">Contact Info</th>
                <th style="padding: 10px;">Status</th>
                <th style="padding: 10px;">Total Sales (Count)</th>
                <th style="padding: 10px;">Total Earnings</th>
                <th style="padding: 10px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($partners) > 0): ?>
                <?php foreach ($partners as $partner): ?>
                <tr>
                    <td style="padding: 10px;"><?php echo htmlspecialchars($partner['name']); ?></td>
                    <td style="padding: 10px;"><?php echo htmlspecialchars($partner['mobile']); ?></td>
                    <td style="padding: 10px;">
                        <!-- UPDATED FORM: Now more reliable -->
                        <form action="partners.php" method="POST" style="display:flex; align-items: center; gap: 10px;">
                            <input type="hidden" name="partner_id" value="<?php echo $partner['id']; ?>">
                            <select name="new_status" class="form-control" style="padding: 5px; width: 120px;">
                                <option value="Pending" <?php if($partner['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                <option value="Approved" <?php if($partner['status'] == 'Approved') echo 'selected'; ?>>Approved</option>
                                <option value="Blocked" <?php if($partner['status'] == 'Blocked') echo 'selected'; ?>>Blocked</option>
                            </select>
                            <button type="submit" name="change_status" value="update" class="btn-submit" style="padding: 5px 10px; font-size: 14px;">Update</button>
                        </form>
                    </td>
                    <!-- Placeholder columns for sales and earnings -->
                    <td style="padding: 10px;">0</td>
                    <td style="padding: 10px;">₹0.00</td>
                    <td style="padding: 10px;">
                        <a href="view_partner.php?id=<?php echo $partner['id']; ?>" style="text-decoration:none; background-color:#007bff; color:white; padding:5px 10px; border-radius:3px;">View</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6" style="padding: 10px; text-align: center;">No partners found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>```