<?php
require_once 'init.php'; // Handles admin session, db connection

// This query is similar to the Sales Report but focuses on the order itself
try {
    $stmt = $pdo->query(
        "SELECT 
            s.id as order_id,
            s.sale_date,
            s.sale_amount,
            p.title as product_name,
            u.mobile as customer_mobile,
            s.buyer_info as guest_info,
            partner.name as partner_name
         FROM sales s
         LEFT JOIN products p ON s.product_id = p.id
         LEFT JOIN users u ON s.buyer_id = u.id
         LEFT JOIN partners partner ON s.partner_id = partner.id
         ORDER BY s.sale_date DESC"
    );
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $orders = [];
    $error_message = "Database Error: " . $e->getMessage();
}

include 'header.php';
?>
<!-- COMPLETE CSS FOR THIS PAGE (can reuse styles from customers.php) -->
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .table-panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: middle; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; background-color: #f8f9fa; }
</style>

<h1 class="page-header">Order Management</h1>

<div class="table-panel">
    <p>This page lists all sales transactions that have occurred on the website.</p>
    <table class="table">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Product</th>
                <th>Customer Details</th>
                <th>Sale Amount</th>
                <th>Referred By (Partner)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($orders)): ?>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>#<?php echo $order['order_id']; ?></td>
                        <td><?php echo date('d M Y, h:i A', strtotime($order['sale_date'])); ?></td>
                        <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                        <td>
                            <?php if ($order['customer_mobile']): ?>
                                Registered: <strong><?php echo htmlspecialchars($order['customer_mobile']); ?></strong>
                            <?php else: ?>
                                Guest: <small><?php echo htmlspecialchars($order['guest_info']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><strong>₹<?php echo number_format($order['sale_amount'], 2); ?></strong></td>
                        <td><?php echo htmlspecialchars($order['partner_name'] ?? 'N/A'); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center; padding: 20px;">No orders have been placed yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>