<?php
require_once 'init.php';

// --- Handle 'Mark as Paid' Action for Trainer Payout ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['mark_trainer_paid'])) {
    $trainer_id = (int)$_POST['trainer_id'];
    $amount = (float)$_POST['amount'];
    $notes = trim($_POST['notes']);

    if ($amount > 0) {
        try {
            $sql = "INSERT INTO trainer_payouts (trainer_id, amount, notes) VALUES (:trainer_id, :amount, :notes)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['trainer_id' => $trainer_id, 'amount' => $amount, 'notes' => $notes]);
            header("Location: trainer_payouts.php?status=paid_success");
            exit;
        } catch (PDOException $e) {
            header("Location: trainer_payouts.php?status=error");
            exit;
        }
    }
}

// --- Fetch ALL trainers and calculate their eligible seminar earnings ---
$payout_data = [];
try {
    $stmt_trainers = $pdo->query("SELECT id, name, payment_details FROM partners WHERE trainer_status = 'approved'");
    $trainers = $stmt_trainers->fetchAll(PDO::FETCH_ASSOC);

    foreach ($trainers as $trainer) {
        $trainer_id = $trainer['id'];

        // 1. Total Seminar Earnings (from COMPLETED seminars only)
        $stmt_earning = $pdo->prepare(
            "SELECT SUM(sa.trainer_earning) 
             FROM seminar_attendees sa
             JOIN seminars s ON sa.seminar_product_id = s.id
             WHERE sa.trainer_id = :id AND s.status = 'Completed'"
        );
        $stmt_earning->execute(['id' => $trainer_id]);
        $total_earning = $stmt_earning->fetchColumn() ?? 0;
        
        // 2. Total Paid to this trainer
        $stmt_paid = $pdo->prepare("SELECT SUM(amount) FROM trainer_payouts WHERE trainer_id = :id");
        $stmt_paid->execute(['id' => $trainer_id]);
        $total_paid = $stmt_paid->fetchColumn() ?? 0;

        $current_due = $total_earning - $total_paid;
        
        // Only show trainers who have earnings
        if ($total_earning > 0) {
            $payout_data[] = [
                'id' => $trainer_id,
                'name' => $trainer['name'],
                'payment_details' => $trainer['payment_details'],
                'total_earning' => $total_earning,
                'total_paid' => $total_paid,
                'current_due' => $current_due
            ];
        }
    }
} catch (PDOException $e) {
    $error_message = "Database Error: " . $e->getMessage();
}

include 'header.php';
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .table-panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: top; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; background-color: #f8f9fa; }
    .due-amount { color: #dc3545; font-weight: bold; font-size: 18px; }
    .action-form { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .action-form input { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
    .action-form button { padding: 8px 12px; border: none; background-color: #28a745; color: white; cursor: pointer; border-radius: 4px; }
    .alert-success { background-color: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
</style>

<h1 class="page-header">Trainer Payouts <small>(from Completed Seminars)</small></h1>

<?php if (isset($_GET['status']) && $_GET['status'] == 'paid_success') echo '<div class="alert-success">Payment recorded successfully!</div>'; ?>

<div class="table-panel">
    <p>This report shows the total eligible earnings (from <strong>Completed</strong> seminars only) for each trainer. Payouts recorded here are final.</p>
    <table class="table">
        <thead>
            <tr>
                <th>Trainer Details</th>
                <th>Total Eligible Earning</th>
                <th>Total Paid</th>
                <th>Current Due</th>
                <th>Mark a New Payment</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($payout_data)): ?>
                <?php foreach ($payout_data as $payout): ?>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars($payout['name']); ?></strong><br>
                            <small>Details: <?php echo htmlspecialchars($payout['payment_details']); ?></small>
                        </td>
                        <td>₹<?php echo number_format($payout['total_earning'], 2); ?></td>
                        <td>₹<?php echo number_format($payout['total_paid'], 2); ?></td>
                        <td><strong class="due-amount">₹<?php echo number_format($payout['current_due'], 2); ?></strong></td>
                        <td>
                            <?php if ($payout['current_due'] > 0): ?>
                                <form class="action-form" action="trainer_payouts.php" method="POST" onsubmit="return confirm('Are you sure you have completed this payment? This action cannot be undone.');">
                                    <input type="hidden" name="trainer_id" value="<?php echo $payout['id']; ?>">
                                    <input type="number" name="amount" placeholder="Amount Paid" step="0.01" max="<?php echo $payout['current_due']; ?>" required>
                                    <input type="text" name="notes" placeholder="Transaction ID (Optional)">
                                    <button type="submit" name="mark_trainer_paid">Confirm Paid</button>
                                </form>
                            <?php else: ?>
                                All Dues Cleared
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align:center; padding:20px;">No eligible seminar earnings to be paid out yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>