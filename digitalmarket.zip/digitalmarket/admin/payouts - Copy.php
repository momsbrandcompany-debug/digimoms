<?php
include 'header.php'; // Includes admin session check, db connection etc.

// --- Handle Payout Action (Mark as Completed or Reject) ---
if (isset($_POST['action'])) {
    $request_id = (int)$_POST['request_id'];
    $action = $_POST['action'];
    $admin_notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

    if ($action === 'complete' || $action === 'reject') {
        try {
            $new_status = ($action === 'complete') ? 'Completed' : 'Rejected';
            $processed_date = date('Y-m-d H:i:s');
            
            $sql = "UPDATE payout_requests SET status = :status, processed_date = :date, admin_notes = :notes WHERE id = :id AND status = 'Pending'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'status' => $new_status,
                'date' => $processed_date,
                'notes' => $admin_notes,
                'id' => $request_id
            ]);
            
            header("Location: payouts.php?status=success");
            exit;
        } catch (PDOException $e) {
            header("Location: payouts.php?status=error");
            exit;
        }
    }
}

// --- Fetch All Pending and Recent Payout Requests ---
try {
    $stmt = $pdo->query(
        "SELECT pr.*, p.name as partner_name, p.payment_details 
         FROM payout_requests pr 
         JOIN partners p ON pr.partner_id = p.id
         ORDER BY pr.status = 'Pending' DESC, pr.request_date DESC"
    );
    $all_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // --- Calculate Total Pending Payout Amount ---
    $total_pending_amount = $pdo->query("SELECT SUM(request_amount) FROM payout_requests WHERE status = 'Pending'")->fetchColumn() ?? 0;

} catch (PDOException $e) {
    $all_requests = [];
    $total_pending_amount = 0;
    echo "Database Error: " . $e->getMessage();
}

// Function to calculate a partner's current balance
function get_partner_balance($pdo, $partner_id) {
    // 1. Total Earnings
    $stmt_direct = $pdo->prepare("SELECT SUM(commission_amount) FROM sales WHERE partner_id = :id");
    $stmt_direct->execute(['id' => $partner_id]);
    $direct_earnings = $stmt_direct->fetchColumn() ?? 0;

    $stmt_sub = $pdo->prepare("SELECT SUM(parent_commission_amount) FROM sales WHERE parent_partner_id = :id");
    $stmt_sub->execute(['id' => $partner_id]);
    $sub_earnings = $stmt_sub->fetchColumn() ?? 0;
    $total_earnings = $direct_earnings + $sub_earnings;

    // 2. Total Paid
    $stmt_paid = $pdo->prepare("SELECT SUM(request_amount) FROM payout_requests WHERE partner_id = :id AND status = 'Completed'");
    $stmt_paid->execute(['id' => $partner_id]);
    $total_paid = $stmt_paid->fetchColumn() ?? 0;
    
    return $total_earnings - $total_paid;
}
?>
<style>
    /* Re-use styles from other admin pages */
    .summary-box { background-color: #e9f4ff; color: #0056b3; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 5px solid #007bff; }
    .summary-box h3 { margin: 0; }
    .summary-box .amount { font-size: 28px; font-weight: 700; }
    .table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
    .table th, .table td { padding: 12px; text-align: left; vertical-align: top; border-bottom: 1px solid #ddd; }
    .actions-form textarea { width: 100%; margin-top: 10px; padding: 5px; }
    .actions-form button { margin-top: 5px; padding: 5px 10px; cursor: pointer; }
    .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; color: white; }
    .status-Pending { background-color: #ffc107; color: #333; } .status-Completed { background-color: #28a745; } .status-Rejected { background-color: #dc3545; }
</style>

<h1 class="page-header">Payout Requests Management</h1>

<!-- Total Pending Amount Box -->
<div class="summary-box">
    <h3>Total Amount to be Paid Out (Pending)</h3>
    <p class="amount">₹<?php echo number_format($total_pending_amount, 2); ?></p>
</div>

<div class="form-container">
    <table class="table">
        <thead>
            <tr>
                <th>Partner</th>
                <th>Request Details</th>
                <th>Partner's Current Balance</th>
                <th>Status / Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($all_requests)): ?>
                <?php foreach ($all_requests as $request): ?>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars($request['partner_name']); ?></strong><br>
                            <small>Payment Info: <?php echo htmlspecialchars($request['payment_details']); ?></small>
                        </td>
                        <td>
                            Amount: <strong>₹<?php echo number_format($request['request_amount'], 2); ?></strong><br>
                            <small>Date: <?php echo date('d M Y, h:i A', strtotime($request['request_date'])); ?></small>
                        </td>
                        <td>
                            <!-- Your requested feature: Show current balance -->
                            <strong>₹<?php echo number_format(get_partner_balance($pdo, $request['partner_id']), 2); ?></strong>
                        </td>
                        <td>
                            <?php if ($request['status'] === 'Pending'): ?>
                                <form action="payouts.php" method="POST">
                                    <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                    <textarea name="notes" placeholder="Optional: Transaction ID or notes"></textarea>
                                    <button type="submit" name="action" value="complete" style="background-color:#28a745; color:white;">Mark as Completed</button>
                                    <button type="submit" name="action" value="reject" style="background-color:#dc3545; color:white;">Reject</button>
                                </form>
                            <?php else: ?>
                                <span class="status-badge status-<?php echo $request['status']; ?>"><?php echo $request['status']; ?></span><br>
                                <small>Processed on: <?php echo date('d M Y', strtotime($request['processed_date'])); ?></small>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align:center;">No payout requests found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>