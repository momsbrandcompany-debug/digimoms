<?php
require_once 'init.php';

// --- Handle Form Submission to Update Settings ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_settings'])) {
    try {
        $sql = "UPDATE settings SET setting_value = :value WHERE setting_key = :key";
        $stmt = $pdo->prepare($sql);

        // Loop through all settings from the form and update the database
        if (isset($_POST['settings']) && is_array($_POST['settings'])) {
            foreach ($_POST['settings'] as $key => $value) {
                $stmt->execute(['value' => trim($value), 'key' => $key]);
            }
        }
        
        // Handle logo upload separately
        if (isset($_FILES['website_logo']) && $_FILES['website_logo']['error'] == 0) {
            $upload_dir = '../public/uploads/site/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
            $filename = 'logo_' . time() . '_' . basename($_FILES['website_logo']['name']);
            if (move_uploaded_file($_FILES['website_logo']['tmp_name'], $upload_dir . $filename)) {
                $logo_path = 'public/uploads/site/' . $filename;
                $stmt->execute(['value' => $logo_path, 'key' => 'website_logo']);
            }
        }

        header("Location: settings.php?status=success");
        exit;
    } catch (PDOException $e) {
        header("Location: settings.php?status=error&msg=" . urlencode($e->getMessage()));
        exit;
    }
}

// --- Fetch all current settings from the database ---
$settings = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);

include 'header.php';
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .panel { background-color: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); margin-bottom: 30px; }
    .panel-title { font-size: 22px; color: #333; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 25px; margin-top: 0; }
    .form-group { margin-bottom: 20px; }
    label { font-weight: 600; margin-bottom: 8px; display: block; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 16px; }
    textarea.form-control { min-height: 150px; }
    .btn-primary { padding: 12px 25px; border: none; background-color: #007bff; color: white; cursor: pointer; border-radius: 8px; font-size: 16px; font-weight: 600; }
    .alert-success { background-color: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
</style>

<h1 class="page-header">Site Settings</h1>

<?php if (isset($_GET['status']) && $_GET['status'] == 'success') echo '<div class="alert-success">Settings saved successfully!</div>'; ?>

<form action="settings.php" method="POST" enctype="multipart/form-data">
    <div class="panel">
        <h2 class="panel-title">General Settings</h2>
        <div class="form-group">
            <label>Website Name</label>
            <input type="text" name="settings[website_name]" class="form-control" value="<?php echo htmlspecialchars($settings['website_name'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Website Logo</label>
            <input type="file" name="website_logo" class="form-control" accept="image/*">
            <?php if (!empty($settings['website_logo'])): ?>
                <p style="margin-top:10px;">Current Logo: <img src="../<?php echo htmlspecialchars($settings['website_logo']); ?>" alt="logo" height="40"></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="panel">
        <h2 class="panel-title">Contact Information</h2>
        <div class="form-group">
            <label>Contact Email</label>
            <input type="email" name="settings[contact_email]" class="form-control" value="<?php echo htmlspecialchars($settings['contact_email'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Contact Phone / WhatsApp</label>
            <input type="text" name="settings[contact_phone]" class="form-control" value="<?php echo htmlspecialchars($settings['contact_phone'] ?? ''); ?>">
        </div>
    </div>
    
    <div class="panel">
        <h2 class="panel-title">Payment Gateway Settings</h2>
        <div class="form-group">
            <label>Cashfree App ID</label>
            <input type="text" name="settings[cashfree_app_id]" class="form-control" value="<?php echo htmlspecialchars($settings['cashfree_app_id'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Cashfree Secret Key</label>
            <input type="password" name="settings[cashfree_secret_key]" class="form-control" value="<?php echo htmlspecialchars($settings['cashfree_secret_key'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label>Payment Mode</label>
            <select name="settings[payment_mode]" class="form-control">
                <option value="Test" <?php if (($settings['payment_mode'] ?? '') === 'Test') echo 'selected'; ?>>Test (No real money)</option>
                <option value="Live" <?php if (($settings['payment_mode'] ?? '') === 'Live') echo 'selected'; ?>>Live (Real money)</option>
            </select>
        </div>
    </div>
    
    <div class="panel">
        <h2 class="panel-title">Policy Pages Content</h2>
        <div class="form-group">
            <label>Privacy Policy</label>
            <textarea name="settings[privacy_policy]" class="form-control editor"><?php echo htmlspecialchars($settings['privacy_policy'] ?? ''); ?></textarea>
        </div>
        <div class="form-group">
            <label>Terms & Conditions</label>
            <textarea name="settings[terms_conditions]" class="form-control editor"><?php echo htmlspecialchars($settings['terms_conditions'] ?? ''); ?></textarea>
        </div>
        <div class="form-group">
            <label>Refund Policy</label>
            <textarea name="settings[refund_policy]" class="form-control editor"><?php echo htmlspecialchars($settings['refund_policy'] ?? ''); ?></textarea>
        </div>
    </div>

    <button type="submit" name="save_settings" class="btn-primary">Save All Settings</button>
</form>

<!-- Attach TinyMCE to textareas with class 'editor' -->
<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: 'textarea.editor',
    plugins: 'lists link wordcount',
    toolbar: 'undo redo | blocks | bold italic | bullist numlist | link'
  });
</script>

<?php include 'footer.php'; ?>