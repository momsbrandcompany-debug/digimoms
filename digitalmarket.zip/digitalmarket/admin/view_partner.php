<?php
include 'header.php';
require_once '../db_config.php';

// Get partner ID from URL
$partner_id = $_GET['id'] ?? null;
if (!$partner_id) {
    header("Location: partners.php");
    exit();
}

// Fetch partner details from the database
try {
    $stmt = $pdo->prepare("SELECT * FROM partners WHERE id = ?");
    $stmt->execute([$partner_id]);
    $partner = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$partner) {
        die("Partner not found.");
    }
} catch (PDOException $e) {
    die("Error fetching partner details: " . $e->getMessage());
}
?>

<div style="display: flex; justify-content: space-between; align-items: center;">
    <h1 class="page-header">Partner Details</h1>
    <a href="partners.php" style="text-decoration:none;">&laquo; Back to All Partners</a>
</div>

<div class="form-container">
    <table width="100%" border="1" style="border-collapse: collapse;">
        <tr>
            <th style="width: 200px; padding: 12px; background-color: #f2f2f2;">Name</th>
            <td style="padding: 12px;"><?php echo htmlspecialchars($partner['name']); ?></td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Current Status</th>
            <td style="padding: 12px; font-weight: bold; color: <?php echo ($partner['status'] == 'Approved') ? 'green' : 'orange'; ?>;">
                <?php echo htmlspecialchars($partner['status']); ?>
            </td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Mobile / Login ID</th>
            <td style="padding: 12px;"><?php echo htmlspecialchars($partner['mobile']); ?></td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Email</th>
            <td style="padding: 12px;"><?php echo htmlspecialchars($partner['email']); ?></td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Age</th>
            <td style="padding: 12px;"><?php echo htmlspecialchars($partner['age']); ?></td>
        </tr>
         <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Profession</th>
            <td style="padding: 12px;"><?php echo htmlspecialchars($partner['profession']); ?></td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Address</th>
            <td style="padding: 12px;"><?php echo nl2br(htmlspecialchars($partner['address'])); ?></td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Payment Details (UPI/Bank)</th>
            <td style="padding: 12px;"><?php echo nl2br(htmlspecialchars($partner['payment_details'])); ?></td>
        </tr>
        <tr>
            <th style="padding: 12px; background-color: #f2f2f2;">Application Date</th>
            <td style="padding: 12px;"><?php echo date('d M, Y h:i A', strtotime($partner['created_at'])); ?></td>
        </tr>
    </table>
</div>

<?php include 'footer.php'; ?>