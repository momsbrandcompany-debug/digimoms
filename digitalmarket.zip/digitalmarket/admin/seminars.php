<?php
require_once 'init.php';

// Handle seminar approval/rejection on the NEW 'seminars' table
if (isset($_GET['action']) && isset($_GET['id'])) {
    $seminar_id = (int)$_GET['id'];
    $action = $_GET['action'];
    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE seminars SET status = 'Active' WHERE id = :id");
        $stmt->execute(['id' => $seminar_id]);
    } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE seminars SET status = 'Inactive' WHERE id = :id");
        $stmt->execute(['id' => $seminar_id]);
    }
    header("Location: seminars.php");
    exit;
}

// Fetch all seminars from the NEW 'seminars' table
$stmt_seminars = $pdo->query(
    "SELECT s.*, p.name as trainer_name 
     FROM seminars s 
     JOIN partners p ON s.trainer_id = p.id 
     ORDER BY s.status = 'Pending' DESC, s.id DESC"
);
$seminars = $stmt_seminars->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>

<h1 class="page-header">Seminar Approvals</h1>
<div class="table-panel">
    <table class="table">
        <thead><tr><th>Seminar Title</th><th>Trainer</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($seminars as $seminar): ?>
                <tr>
                    <td><?php echo htmlspecialchars($seminar['title']); ?></td>
                    <td><?php echo htmlspecialchars($seminar['trainer_name']); ?></td>
                    <td>₹<?php echo $seminar['price']; ?></td>
                    <td><?php echo $seminar['status']; ?></td>
                    <td>
                        <?php if ($seminar['status'] === 'Pending'): ?>
                            <a href="seminars.php?action=approve&id=<?php echo $seminar['id']; ?>" class="btn-action btn-approve">Approve</a>
                        <?php else: ?>
                            <a href="seminars.php?action=reject&id=<?php echo $seminar['id']; ?>" class="btn-action btn-reject">Deactivate</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>