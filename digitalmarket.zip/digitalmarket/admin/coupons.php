<?php
include 'header.php'; // Includes admin session check, db connection etc.

// --- Handle Status Change Action ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $coupon_id = (int)$_GET['id'];
    $action = $_GET['action'];
    $allowed_actions = ['activate', 'block', 'delete'];

    if (in_array($action, $allowed_actions)) {
        try {
            if ($action === 'delete') {
                $sql = "DELETE FROM coupons WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(['id' => $coupon_id]);
            } else {
                $new_status = ($action === 'activate') ? 'Active' : 'Blocked';
                $sql = "UPDATE coupons SET status = :status WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(['status' => $new_status, 'id' => $coupon_id]);
            }
            // Redirect to the same page to see the changes
            header("Location: coupons.php?status=success");
            exit;
        } catch (PDOException $e) {
            header("Location: coupons.php?status=error");
            exit;
        }
    }
}

// Fetch all coupons with partner names
try {
    $stmt = $pdo->query(
        "SELECT c.*, p.name as partner_name 
         FROM coupons c 
         LEFT JOIN partners p ON c.partner_id = p.id 
         ORDER BY c.status = 'Pending' DESC, c.created_at DESC"
    );
    $all_coupons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $all_coupons = [];
    echo "Database Error: " . $e->getMessage();
}
?>
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
    .table th, .table td { border-bottom: 1px solid #ddd; padding: 12px; text-align: left; }
    .table th { background-color: #f2f2f2; }
    .actions a { text-decoration: none; padding: 5px 10px; border-radius: 4px; color: white; margin-right: 5px; font-size: 13px; }
    .btn-approve { background-color: #28a745; }
    .btn-block { background-color: #ffc107; color: #333 !important; }
    .btn-delete { background-color: #dc3545; }
    .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; color: white; }
    .status-Pending { background-color: #ffc107; color: #333; }
    .status-Active { background-color: #28a745; }
    .status-Blocked { background-color: #dc3545; }
</style>

<h1 class="page-header">Coupon Management</h1>

<?php if(isset($_GET['status']) && $_GET['status'] == 'success') echo '<div style="background-color:#d4edda; color:#155724; padding:15px; border-radius:5px; margin-bottom:20px;">Action completed successfully!</div>'; ?>

<div class="form-container">
    <table class="table">
        <thead>
            <tr>
                <th>Code</th>
                <th>Discount</th>
                <th>Created By</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($all_coupons)): ?>
                <?php foreach ($all_coupons as $coupon): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($coupon['coupon_code']); ?></strong></td>
                        <td><?php echo $coupon['discount_value']; ?>%</td>
                        <td><?php echo $coupon['partner_name'] ? htmlspecialchars($coupon['partner_name']) : 'Admin'; ?></td>
                        <td><span class="status-badge status-<?php echo $coupon['status']; ?>"><?php echo $coupon['status']; ?></span></td>
                        <td class="actions">
                            <?php if ($coupon['status'] === 'Pending'): ?>
                                <a href="coupons.php?action=activate&id=<?php echo $coupon['id']; ?>" class="btn-approve">Approve</a>
                                <a href="coupons.php?action=block&id=<?php echo $coupon['id']; ?>" class="btn-block">Reject</a>
                            <?php elseif ($coupon['status'] === 'Active'): ?>
                                <a href="coupons.php?action=block&id=<?php echo $coupon['id']; ?>" class="btn-block">Block</a>
                            <?php elseif ($coupon['status'] === 'Blocked'): ?>
                                <a href="coupons.php?action=activate&id=<?php echo $coupon['id']; ?>" class="btn-approve">Unblock</a>
                            <?php endif; ?>
                            <a href="coupons.php?action=delete&id=<?php echo $coupon['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to permanently delete this coupon?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align:center;">No coupons found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>