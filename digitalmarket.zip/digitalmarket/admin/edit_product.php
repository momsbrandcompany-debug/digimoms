<?php
require_once 'init.php'; // Handles admin session, db connection

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($product_id === 0) {
    header("Location: products.php");
    exit;
}

$success_msg = $error_msg = "";

// --- Handle Form Submission to UPDATE the product ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve form data
    $title = trim($_POST['title']);
    $category = trim($_POST['category']);
    $sale_price = trim($_POST['sale_price']);
    $market_price = !empty($_POST['market_price']) ? trim($_POST['market_price']) : NULL;
    $description = trim($_POST['description']);
    $course_video_link = trim($_POST['course_video_link']);
    $file_size = trim($_POST['file_size']);
    $file_format = trim($_POST['file_format']);

    // Start building the SQL query
    $sql = "UPDATE products SET title = :title, category = :category, sale_price = :sale_price, market_price = :market_price, description = :description, file_size = :file_size, file_format = :file_format";
    $params = [
        'title' => $title, 'category' => $category, 'sale_price' => $sale_price, 'market_price' => $market_price,
        'description' => $description, 'file_size' => $file_size, 'file_format' => $file_format, 'id' => $product_id
    ];

    // --- Handle Thumbnail Update (if a new one is uploaded) ---
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        // ... (Logic to upload new thumbnail and delete the old one) ...
        $new_thumbnail_path = '...'; // Placeholder for new path
        $sql .= ", thumbnail = :thumbnail";
        $params['thumbnail'] = $new_thumbnail_path;
    }

    // --- Handle Downloadable File/Video Link Update ---
    if (isset($_FILES['downloadable_file']) && $_FILES['downloadable_file']['error'] == 0) {
        // A new downloadable file is uploaded
        // ... (Logic to upload new file and delete the old one) ...
        $new_file_path = '...'; // Placeholder for new path
        $sql .= ", download_file_link = :download_link, course_video_link = NULL";
        $params['download_link'] = $new_file_path;
    } elseif (!empty($course_video_link)) {
        // A video link is provided, so clear the downloadable file link
        $sql .= ", course_video_link = :video_link, download_file_link = NULL";
        $params['video_link'] = $course_video_link;
    }
    
    // Finalize and execute the query
    $sql .= " WHERE id = :id";
    try {
        $stmt = $pdo->prepare($sql);
        if ($stmt->execute($params)) {
            $success_msg = "Product updated successfully!";
        } else {
            $error_msg = "Could not update the product.";
        }
    } catch (PDOException $e) {
        $error_msg = "Database Error: " . $e->getMessage();
    }
}

// --- Fetch the existing product data to populate the form ---
try {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
    $stmt->execute(['id' => $product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$product) {
        header("Location: products.php"); // Redirect if product not found
        exit;
    }
} catch (PDOException $e) {
    die("Error fetching product data.");
}

include 'header.php';
?>

<!-- COMPLETE CSS FOR THIS PAGE (Same as add_product.php) -->
<style>
    .page-header { /* ... */ } .form-container { /* ... */ }
    .form-group { margin-bottom: 20px; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; }
    .btn-submit { padding: 12px 25px; background-color: #007bff; color: white; border: none; border-radius: 5px; }
    .current-file-info { background-color: #f8f9fa; padding: 10px; border-radius: 5px; margin-top: 10px; font-size: 14px; }
</style>

<h1 class="page-header">Edit Product: <?php echo htmlspecialchars($product['title']); ?></h1>

<?php if ($success_msg) echo "<div class='alert-success'>$success_msg</div>"; ?>
<?php if ($error_msg) echo "<div class='alert-error'>$error_msg</div>"; ?>

<div class="form-container">
    <form action="edit_product.php?id=<?php echo $product_id; ?>" method="post" enctype="multipart/form-data">
        
        <div class="form-group">
            <label>Product Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($product['title']); ?>" required>
        </div>

        <div class="form-group">
            <label>Category</label>
            <select name="category" class="form-control" required>
                <option value="Courses" <?php if($product['category'] == "Courses") echo "selected"; ?>>Courses</option>
                <option value="Templates" <?php if($product['category'] == "Templates") echo "selected"; ?>>Templates</option>
                <option value="AI Prompts" <?php if($product['category'] == "AI Prompts") echo "selected"; ?>>AI Prompts</option>
                <option value="Exam Guides" <?php if($product['category'] == "Exam Guides") echo "selected"; ?>>Exam Guides</option>
                <option value="Digital Notes" <?php if($product['category'] == "Digital Notes") echo "selected"; ?>>Digital Notes</option>
                <option value="Ebooks/PDF Forms" <?php if($product['category'] == "Ebooks/PDF Forms") echo "selected"; ?>>Ebooks/PDF Forms</option>
            </select>
        </div>
        
        <div class="form-group">
            <label>Sale Price (₹)</label>
            <input type="number" step="0.01" name="sale_price" class="form-control" value="<?php echo htmlspecialchars($product['sale_price']); ?>" required>
        </div>

        <div class="form-group">
            <label>Market Price (₹) - Optional</label>
            <input type="number" step="0.01" name="market_price" class="form-control" value="<?php echo htmlspecialchars($product['market_price']); ?>">
        </div>

        <div class="form-group">
            <label>Product Description</label>
            <textarea name="description" class="form-control editor"><?php echo htmlspecialchars($product['description']); ?></textarea>
        </div>

        <div class="form-group">
            <label>Product Thumbnail (Image)</label>
            <input type="file" name="thumbnail" class="form-control" accept="image/*">
            <div class="current-file-info">
                Current Thumbnail: <img src="../<?php echo htmlspecialchars($product['thumbnail']); ?>" alt="thumbnail" height="50">
                <br><small>To change, upload a new image. Otherwise, leave this field empty.</small>
            </div>
        </div>
        
        <p style="font-weight: bold; color: #d9534f;">গুরুত্বপূর্ণ: নিচের দুটি বিকল্পের মধ্যে যেকোনো একটি পূরণ করুন।</p>

        <div class="form-group">
            <label>Upload New Downloadable File (PDF, ZIP, etc.)</label>
            <input type="file" name="downloadable_file" class="form-control">
            <?php if (!empty($product['download_file_link'])): ?>
                <div class="current-file-info">Current File: <?php echo basename($product['download_file_link']); ?></div>
            <?php endif; ?>
        </div>
        
        <div class="form-group">
            <label>OR Course Video Link (YouTube, Google Drive, etc.)</label>
            <input type="text" name="course_video_link" class="form-control" placeholder="ভিডিও কোর্সের জন্য এখানে লিঙ্ক দিন" value="<?php echo htmlspecialchars($product['course_video_link']); ?>">
        </div>

        <div class="form-group">
            <label>Download Size (e.g., 25 MB)</label>
            <input type="text" name="file_size" class="form-control" value="<?php echo htmlspecialchars($product['file_size']); ?>">
        </div>

        <div class="form-group">
            <label>File Format (e.g., PDF, ZIP)</label>
            <input type="text" name="file_format" class="form-control" value="<?php echo htmlspecialchars($product['file_format']); ?>">
        </div>

        <button type="submit" class="btn-submit">Update Product</button>
    </form>
</div>

<?php include 'footer.php'; ?>