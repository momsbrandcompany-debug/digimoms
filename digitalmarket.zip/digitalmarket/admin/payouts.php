<?php
require_once 'init.php';

// --- Handle 'Mark as Paid' Action ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['mark_as_paid'])) {
    $partner_id = (int)$_POST['partner_id'];
    $amount = (float)$_POST['amount'];
    $notes = trim($_POST['notes']);

    if ($amount > 0) {
        try {
            // Insert into the new unified 'payout_history' table
            $sql = "INSERT INTO payout_history (partner_id, amount, notes) VALUES (:partner_id, :amount, :notes)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['partner_id' => $partner_id, 'amount' => $amount, 'notes' => $notes]);
            header("Location: payouts.php?status=paid_success");
            exit;
        } catch (PDOException $e) {
            header("Location: payouts.php?status=error");
            exit;
        }
    }
}

// --- Fetch ALL partners and calculate their complete earnings ---
$payout_data = [];
try {
    $stmt_partners = $pdo->query("SELECT id, name, payment_details FROM partners WHERE status = 'Approved'");
    $partners = $stmt_partners->fetchAll(PDO::FETCH_ASSOC);

    foreach ($partners as $partner) {
        $partner_id = $partner['id'];
        
        // 1. Total Affiliate Earnings
        $stmt_aff_earnings = $pdo->prepare("SELECT (SELECT SUM(commission_amount) FROM sales WHERE partner_id = :id1) as direct, (SELECT SUM(parent_commission_amount) FROM sales WHERE parent_partner_id = :id2) as sub");
        $stmt_aff_earnings->execute(['id1' => $partner_id, 'id2' => $partner_id]);
        $aff_earnings = $stmt_aff_earnings->fetch(PDO::FETCH_ASSOC);
        $total_affiliate_earnings = ($aff_earnings['direct'] ?? 0) + ($aff_earnings['sub'] ?? 0);

        // 2. Total Seminar Earnings
        $stmt_sem_earnings = $pdo->prepare("SELECT SUM(trainer_earning) FROM seminar_attendees WHERE trainer_id = :id");
        $stmt_sem_earnings->execute(['id' => $partner_id]);
        $total_seminar_earnings = $stmt_sem_earnings->fetchColumn() ?? 0;

        $grand_total_earnings = $total_affiliate_earnings + $total_seminar_earnings;

        // 3. Grand Total Paid (from the new unified table)
        $stmt_paid = $pdo->prepare("SELECT SUM(amount) FROM payout_history WHERE partner_id = :id");
        $stmt_paid->execute(['id' => $partner_id]);
        $grand_total_paid = $stmt_paid->fetchColumn() ?? 0;

        $current_due = $grand_total_earnings - $grand_total_paid;

        if ($grand_total_earnings > 0) {
            $payout_data[] = [
                'id' => $partner_id,
                'name' => $partner['name'],
                'payment_details' => $partner['payment_details'],
                'total_earning' => $grand_total_earnings,
                'total_paid' => $grand_total_paid,
                'current_due' => $current_due
            ];
        }
    }
} catch (PDOException $e) { $error_message = "Database Error: " . $e->getMessage(); }

include 'header.php';
?>
<style>
    /* Your beautiful admin styles from the previous correct version are restored */
    .page-header { font-size: 28px; color: #1a253c; }
    .table-panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: top; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; background-color: #f8f9fa; }
    .due-amount { color: #dc3545; font-weight: bold; font-size: 18px; }
    .action-form { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .action-form input { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
    .action-form button { padding: 8px 12px; border: none; background-color: #28a745; color: white; cursor: pointer; border-radius: 4px; }
</style>

<h1 class="page-header">Unified Partner Payouts</h1>

<div class="table-panel">
    <p>This single report shows the total due amount (Affiliate + Seminar earnings) for every partner. Use this to process all payments.</p>
    <table class="table">
        <thead>
            <tr>
                <th>Partner Details</th>
                <th>Lifetime Earning</th>
                <th>Total Paid</th>
                <th>Current Due</th>
                <th>Mark a New Payment</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($payout_data as $payout): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($payout['name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($payout['payment_details']); ?></small>
                    </td>
                    <td>₹<?php echo number_format($payout['total_earning'], 2); ?></td>
                    <td>₹<?php echo number_format($payout['total_paid'], 2); ?></td>
                    <td><strong class="due-amount">₹<?php echo number_format($payout['current_due'], 2); ?></strong></td>
                    <td>
                        <?php if ($payout['current_due'] > 0): ?>
                            <form class="action-form" action="payouts.php" method="POST" onsubmit="return confirm('Are you sure you have completed this payment? This action cannot be undone.');">
                                <input type="hidden" name="partner_id" value="<?php echo $payout['id']; ?>">
                                <input type="number" name="amount" placeholder="Amount Paid" step="0.01" max="<?php echo $payout['current_due']; ?>" required>
                                <input type="text" name="notes" placeholder="Transaction ID (Optional)">
                                <button type="submit" name="mark_as_paid">Confirm Paid</button>
                            </form>
                        <?php else: ?>
                            All Dues Cleared
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>