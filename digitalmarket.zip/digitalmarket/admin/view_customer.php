<?php
require_once 'init.php';
$customer_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($customer_id === 0) { header("Location: customers.php"); exit; }

// Fetch customer details and their orders
try {
    $stmt_cust = $pdo->prepare("SELECT mobile FROM users WHERE id = :id");
    $stmt_cust->execute(['id' => $customer_id]);
    $customer = $stmt_cust->fetch(PDO::FETCH_ASSOC);

    $stmt_orders = $pdo->prepare(
        "SELECT s.id, s.sale_date, s.sale_amount, p.title 
         FROM sales s 
         JOIN products p ON s.product_id = p.id
         WHERE s.buyer_id = :id ORDER BY s.sale_date DESC"
    );
    $stmt_orders->execute(['id' => $customer_id]);
    $orders = $stmt_orders->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { /* ... */ }

include 'header.php';
?>
<h1 class="page-header">Order History for Customer: <?php echo htmlspecialchars($customer['mobile']); ?></h1>

<div class="table-panel">
    <table class="table">
        <thead><tr><th>Order ID</th><th>Date</th><th>Product</th><th>Amount</th></tr></thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td>#<?php echo $order['id']; ?></td>
                    <td><?php echo date('d M Y', strtotime($order['sale_date'])); ?></td>
                    <td><?php echo htmlspecialchars($order['title']); ?></td>
                    <td>₹<?php echo number_format($order['sale_amount'], 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>