<?php
include 'header.php';

// Fetch all sales records with details from other tables using JOINs
try {
    $stmt = $pdo->query(
        "SELECT 
            s.id, 
            p.title as product_name, 
            s.sale_amount, 
            partner.name as partner_name, 
            s.commission_amount,
            parent.name as parent_partner_name,
            s.parent_commission_amount,
            s.sale_date 
         FROM sales s
         LEFT JOIN products p ON s.product_id = p.id
         LEFT JOIN partners partner ON s.partner_id = partner.id
         LEFT JOIN partners parent ON s.parent_partner_id = parent.id
         ORDER BY s.sale_date DESC"
    );
    $all_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $all_sales = [];
    echo "Database Error: " . $e->getMessage();
}
?>
<style>
    /* Re-use styles from other admin pages */
    .page-header { font-size: 28px; color: #1a253c; }
    .table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
    .table th, .table td { border-bottom: 1px solid #ddd; padding: 12px; text-align: left; }
    .table th { background-color: #f2f2f2; }
    .commission-cell { color: #28a745; font-weight: bold; }
</style>

<h1 class="page-header">All Sales Report</h1>

<div class="form-container">
    <table class="table">
        <thead>
            <tr>
                <th>Sale ID</th>
                <th>Date</th>
                <th>Product</th>
                <th>Sale Amount</th>
                <th>Direct Partner (Commission)</th>
                <th>Upline Partner (Commission)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($all_sales)): ?>
                <?php foreach ($all_sales as $sale): ?>
                    <tr>
                        <td>#<?php echo $sale['id']; ?></td>
                        <td><?php echo date('d M Y, h:i A', strtotime($sale['sale_date'])); ?></td>
                        <td><?php echo htmlspecialchars($sale['product_name']); ?></td>
                        <td><strong>₹<?php echo number_format($sale['sale_amount'], 2); ?></strong></td>
                        <td class="commission-cell">
                            <?php if ($sale['partner_name']): ?>
                                <?php echo htmlspecialchars($sale['partner_name']); ?>
                                (₹<?php echo number_format($sale['commission_amount'], 2); ?>)
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td class="commission-cell">
                             <?php if ($sale['parent_partner_name']): ?>
                                <?php echo htmlspecialchars($sale['parent_partner_name']); ?>
                                (₹<?php echo number_format($sale['parent_commission_amount'], 2); ?>)
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align:center;">No sales have been recorded yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>