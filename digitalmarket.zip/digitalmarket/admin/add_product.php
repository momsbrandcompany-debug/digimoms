<?php
// Include the header
include 'header.php';
require_once '../db_config.php'; // Database connection

// Define variables to hold form data and messages
$title = $category = $market_price = $sale_price = $description = $file_size = $file_format = "";
$success_msg = $error_msg = "";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- 1. Sanitize and retrieve form data ---
    $title = trim($_POST['title']);
    $category = trim($_POST['category']);
    $sale_price = trim($_POST['sale_price']);
    $market_price = !empty($_POST['market_price']) ? trim($_POST['market_price']) : NULL;
    $description = trim($_POST['description']);
    $course_video_link = trim($_POST['course_video_link']);
    $file_size = trim($_POST['file_size']);
    $file_format = trim($_POST['file_format']);

    $thumbnail_path_for_db = "";
    $download_link_for_db = NULL; // Will hold either the file path or video link

    // --- 2. Handle Thumbnail Upload ---
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));

        if (in_array($file_extension, $allowed_extensions)) {
            $upload_dir_thumbnail = '../public/uploads/thumbnails/';
            $unique_filename_thumbnail = time() . '_' . basename($_FILES['thumbnail']['name']);
            $target_file_thumbnail = $upload_dir_thumbnail . $unique_filename_thumbnail;

            if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target_file_thumbnail)) {
                // Store relative path for DB
                $thumbnail_path_for_db = 'public/uploads/thumbnails/' . $unique_filename_thumbnail;
            } else {
                $error_msg = "Sorry, there was an error uploading your thumbnail.";
            }
        } else {
            $error_msg = "Invalid thumbnail file type. Only JPG, JPEG, PNG, GIF are allowed.";
        }
    } else {
        $error_msg = "Thumbnail is required.";
    }

    // --- 3. Handle Product File Upload OR Video Link ---
    if (empty($error_msg)) {
        // A. Check for uploaded digital file (for non-video products)
        if (isset($_FILES['downloadable_file']) && $_FILES['downloadable_file']['error'] == 0) {
            $upload_dir_files = '../public/uploads/digital_files/';
            $unique_filename_file = time() . '_' . basename($_FILES['downloadable_file']['name']);
            $target_file_product = $upload_dir_files . $unique_filename_file;

            if (move_uploaded_file($_FILES['downloadable_file']['tmp_name'], $target_file_product)) {
                $download_link_for_db = 'public/uploads/digital_files/' . $unique_filename_file;
            } else {
                $error_msg = "Sorry, there was an error uploading your product file.";
            }
        } 
        // B. If no file uploaded, check for a video course link
        elseif (!empty($course_video_link)) {
            // For video courses, the link is stored in the `course_video_link` column
            // We set the download file link to NULL and video link to the provided URL
            $download_link_for_db = NULL; // Explicitly set to null
        }
        else {
             $error_msg = "You must provide either a downloadable file or a course video link.";
        }
    }

    // --- 4. Insert data into the database ---
    if (empty($error_msg)) {
        try {
            $sql = "INSERT INTO products (title, category, thumbnail, market_price, sale_price, description, download_file_link, course_video_link, file_size, file_format) 
                    VALUES (:title, :category, :thumbnail, :market_price, :sale_price, :description, :download_file_link, :course_video_link, :file_size, :file_format)";
            
            $stmt = $pdo->prepare($sql);
            
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':category', $category);
            $stmt->bindParam(':thumbnail', $thumbnail_path_for_db);
            $stmt->bindParam(':market_price', $market_price);
            $stmt->bindParam(':sale_price', $sale_price);
            $stmt->bindParam(':description', $description);
            // This is the logic update
            if (isset($_FILES['downloadable_file']) && $_FILES['downloadable_file']['error'] == 0) {
                 $stmt->bindParam(':download_file_link', $download_link_for_db);
                 $course_video_link = NULL; // Ensure video link is null if file is uploaded
                 $stmt->bindParam(':course_video_link', $course_video_link);
            } else {
                 $download_link_for_db = NULL; // Ensure download link is null if video link is provided
                 $stmt->bindParam(':download_file_link', $download_link_for_db);
                 $stmt->bindParam(':course_video_link', $course_video_link);
            }
            $stmt->bindParam(':file_size', $file_size);
            $stmt->bindParam(':file_format', $file_format);

            if ($stmt->execute()) {
                $success_msg = "Product added successfully!";
                // Clear form fields after success
                $title = $category = $market_price = $sale_price = $description = $file_size = $file_format = "";
            } else {
                $error_msg = "Something went wrong. Please try again.";
            }

        } catch (PDOException $e) {
            $error_msg = "Database error: " . $e->getMessage();
        }
    }
}
?>

<h1 class="page-header">Add New Product</h1>

<?php
if ($success_msg) {
    echo "<div style='padding: 15px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 5px; margin-bottom: 20px;'>$success_msg</div>";
}
if ($error_msg) {
    echo "<div style='padding: 15px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin-bottom: 20px;'>$error_msg</div>";
}
?>

<div class="form-container">
    <form action="add_product.php" method="post" enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="title">Product Title</label>
            <input type="text" id="title" name="title" class="form-control" value="<?php echo htmlspecialchars($title); ?>" required>
        </div>

        <div class="form-group">
            <label for="category">Category</label>
            <select id="category" name="category" class="form-control" required>
                <option value="" <?php if($category == "") echo "selected"; ?>>-- Select a Category --</option>
                <option value="Courses" <?php if($category == "Courses") echo "selected"; ?>>Courses</option>
                <option value="Templates" <?php if($category == "Templates") echo "selected"; ?>>Templates</option>
                <option value="AI Prompts" <?php if($category == "AI Prompts") echo "selected"; ?>>AI Prompts</option>
                <option value="Exam Guides" <?php if($category == "Exam Guides") echo "selected"; ?>>Exam Guides</option>
                <option value="Digital Notes" <?php if($category == "Digital Notes") echo "selected"; ?>>Digital Notes</option>
                <option value="Ebooks/PDF Forms" <?php if($category == "Ebooks/PDF Forms") echo "selected"; ?>>Ebooks/PDF Forms</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="sale_price">Sale Price (₹)</label>
            <input type="number" step="0.01" id="sale_price" name="sale_price" class="form-control" value="<?php echo htmlspecialchars($sale_price); ?>" required>
        </div>

        <div class="form-group">
            <label for="market_price">Market Price (₹) - Optional</label>
            <input type="number" step="0.01" id="market_price" name="market_price" class="form-control" value="<?php echo htmlspecialchars($market_price); ?>">
        </div>

        <div class="form-group">
            <label for="description">Product Description</label>
            <textarea id="description" name="description" class="form-control"><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="thumbnail">Product Thumbnail (Image)</label>
            <input type="file" id="thumbnail" name="thumbnail" class="form-control" accept="image/*" required>
        </div>
        
        <p style="font-weight: bold; color: #d9534f;">গুরুত্বপূর্ণ: নিচের দুটি বিকল্পের মধ্যে যেকোনো একটি পূরণ করুন।</p>

        <div class="form-group">
            <label for="downloadable_file">Upload Downloadable File (PDF, ZIP, etc.)</label>
            <input type="file" id="downloadable_file" name="downloadable_file" class="form-control">
        </div>
        
        <div class="form-group">
            <label for="course_video_link">OR Course Video Link (YouTube, Google Drive, etc.)</label>
            <input type="text" id="course_video_link" name="course_video_link" class="form-control" placeholder="ভিডিও কোর্সের জন্য এখানে লিঙ্ক দিন">
        </div>

        <div class="form-group">
            <label for="file_size">Download Size (e.g., 25 MB)</label>
            <input type="text" id="file_size" name="file_size" class="form-control" value="<?php echo htmlspecialchars($file_size); ?>">
        </div>

        <div class="form-group">
            <label for="file_format">File Format (e.g., PDF, ZIP)</label>
            <input type="text" id="file_format" name="file_format" class="form-control" value="<?php echo htmlspecialchars($file_format); ?>">
        </div>

        <button type="submit" class="btn-submit">Add Product</button>
    </form>
</div>

<?php
// Include the footer
include 'footer.php';
?>