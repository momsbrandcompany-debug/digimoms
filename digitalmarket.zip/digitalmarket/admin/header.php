<?php
// Your PHP code at the top remains unchanged
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../db_config.php';
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true) {
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - DigiMoms</title>
    <style>
        /* All your other CSS remains unchanged */
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7fA; margin: 0; display: flex; }
        .sidebar {
            width: 250px;
            background-color: #1a253c;
            color: white;
            height: 100vh; /* Use 100% of the viewport height */
            position: fixed;
            top: 0;
            left: 0;
            display: flex; /* Use flexbox for better layout */
            flex-direction: column;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            font-size: 24px;
            font-weight: 700;
            border-bottom: 1px solid #344059;
            flex-shrink: 0; /* Prevent header from shrinking */
        }

        /* --- THIS IS THE FINAL FIX FOR THE SCROLLBAR --- */
        .sidebar-nav {
            list-style: none;
            padding: 0;
            margin: 0;
            overflow-y: auto; /* Adds a vertical scrollbar only when needed */
            flex-grow: 1; /* Allow this area to grow and fill available space */
        }
        /* Style for the scrollbar itself (optional, for better look) */
        .sidebar-nav::-webkit-scrollbar { width: 6px; }
        .sidebar-nav::-webkit-scrollbar-thumb { background-color: #555; border-radius: 3px; }
        /* ------------------------------------------- */

        .sidebar-nav li a { display: block; color: #ccc; padding: 18px 20px; text-decoration: none; transition: background-color 0.3s, color 0.3s; }
        .sidebar-nav li a:hover, .sidebar-nav li a.active { background-color: #007bff; color: white; }
        
        .main-content { margin-left: 250px; width: calc(100% - 250px); padding: 0; }
        .top-navbar { background-color: #ffffff; padding: 15px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; justify-content: flex-end; align-items: center; }
        /* ... All other styles remain the same */
    </style>
    <!-- Your TinyMCE script remains unchanged -->
    <script src="https://cdn.tiny.cloud/1/y2b6hsioildxg1ss1x6sud2xi4i9t74y25jat2xayptem5hd/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script> tinymce.init({ /* ... */ }); </script>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            DigiMoms
        </div>
        <!-- Your entire sidebar menu list remains unchanged -->
        <ul class="sidebar-nav">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="blog_manager.php">Blog Manager</a></li>
            <li><a href="blog_categories.php">Blog Categories</a></li>
            <li><a href="partners.php">Partners</a></li>
            <li><a href="coupons.php">Coupon Management</a></li>
            <li><a href="sales.php">Sales Report</a></li>
            <li><a href="payouts.php">Partner Payouts</a></li>
            <li><a href="password_resets.php">Password Resets</a></li>
            <li><a href="meetings.php">Live Meetings</a></li>
            <li><a href="trainers.php">Trainer Applications</a></li>
            <li><a href="seminars.php">Seminar Approvals</a></li>
            
            <li><a href="customers.php">Customers</a></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="settings.php">Site Settings</a></li>
           <li><a href="cleanup.php" style="color: #e74c3c;">System Cleanup</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="top-navbar">
            <span>Welcome, <b><?php echo htmlspecialchars($_SESSION["admin_username"]); ?></b></span>
            <a href="logout.php" style="margin-left: 20px;">Logout</a>
        </div>
        <div class="page-content">