<?php
require_once 'init.php'; // Handles admin session, db connection

// Fetch all registered users (customers)
try {
    $stmt = $pdo->query(
        "SELECT u.id, u.mobile, u.created_at, 
                (SELECT COUNT(s.id) FROM sales s WHERE s.buyer_id = u.id) as total_orders
         FROM users u
         ORDER BY u.created_at DESC"
    );
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $customers = [];
    $error_message = "Database Error: " . $e->getMessage();
}

include 'header.php';
?>
<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .page-header { font-size: 28px; color: #1a253c; }
    .table-panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: middle; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; background-color: #f8f9fa; }
    .actions a { text-decoration: none; padding: 5px 10px; border-radius: 4px; color: white; margin-right: 5px; font-size: 13px; }
    .btn-view { background-color: #007bff; }
    .btn-block { background-color: #dc3545; }
</style>

<h1 class="page-header">Customer Management</h1>

<div class="table-panel">
    <p>This page lists all registered customers (users who have created an account to buy courses).</p>
    <table class="table">
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Contact (Mobile)</th>
                <th>Registration Date</th>
                <th>Total Orders</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($customers)): ?>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td>#<?php echo $customer['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($customer['mobile']); ?></strong></td>
                        <td><?php echo date('d M Y', strtotime($customer['created_at'])); ?></td>
                        <td><?php echo $customer['total_orders']; ?></td>
                        <td class="actions">
                            <a href="view_customer.php?id=<?php echo $customer['id']; ?>" class="btn-view">View Orders</a>
                            <!-- Block/Suspend functionality can be added here later -->
                            <a href="#" class="btn-block">Block</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align:center; padding: 20px;">No customers have registered yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>