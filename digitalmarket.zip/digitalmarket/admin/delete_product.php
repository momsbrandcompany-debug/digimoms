<?php
session_start();
require_once '../db_config.php';

// Check if admin is logged in and product ID is provided
if (!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true || !isset($_GET['id'])) {
    header("location: login.php");
    exit;
}

$product_id = $_GET['id'];

try {
    // --- Step 1: First, get the file paths from the database BEFORE deleting the record ---
    $stmt = $pdo->prepare("SELECT thumbnail, download_file_link FROM products WHERE id = :id");
    $stmt->execute(['id' => $product_id]);
    $files = $stmt->fetch(PDO::FETCH_ASSOC);

    // --- Step 2: Delete the product record from the database ---
    $delete_stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
    
    if ($delete_stmt->execute(['id' => $product_id])) {
        // --- Step 3: If DB deletion is successful, delete the actual files from server ---
        
        // Delete thumbnail
        if ($files && !empty($files['thumbnail'])) {
            $thumbnail_path = '../' . $files['thumbnail'];
            if (file_exists($thumbnail_path)) {
                unlink($thumbnail_path);
            }
        }

        // Delete downloadable file
        if ($files && !empty($files['download_file_link'])) {
            // We check if it's a file path and not an external URL like youtube
            if (strpos($files['download_file_link'], 'public/uploads/digital_files/') !== false) {
                $file_path = '../' . $files['download_file_link'];
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            }
        }
    }
    
    // --- Step 4: Redirect back to the products list ---
    header("location: products.php");
    exit;

} catch (PDOException $e) {
    die("ERROR: Could not delete product. " . $e->getMessage());
}
?>