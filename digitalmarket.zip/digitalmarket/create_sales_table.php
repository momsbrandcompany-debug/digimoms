<?php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS sales (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        product_id INT NOT NULL,
        buyer_id INT NULL, -- For logged-in users
        buyer_info VARCHAR(255) NULL, -- For non-logged-in users (e.g., mobile number)
        sale_amount DECIMAL(10, 2) NOT NULL,
        partner_id INT NULL, -- The partner who gets the direct commission
        commission_amount DECIMAL(10, 2) NULL,
        parent_partner_id INT NULL, -- The upline partner
        parent_commission_amount DECIMAL(10, 2) NULL,
        payment_status VARCHAR(50) NOT NULL DEFAULT 'Completed',
        sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id),
        FOREIGN KEY (buyer_id) REFERENCES users(id),
        FOREIGN KEY (partner_id) REFERENCES partners(id),
        FOREIGN KEY (parent_partner_id) REFERENCES partners(id)
    )";

    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'sales' has been created successfully.</p><p><a href='http://localhost/phpmyadmin/'>Click here to check in phpMyAdmin.</a></p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not execute script. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>