<?php
require_once 'db_config.php';
try {
    $sql = "ALTER TABLE live_meetings CHANGE COLUMN meeting_date meeting_date DATETIME NOT NULL";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>The 'live_meetings' table has been updated successfully to support Date and Time.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not update table. Error: " . $e->getMessage() . "</p>");
}
?>