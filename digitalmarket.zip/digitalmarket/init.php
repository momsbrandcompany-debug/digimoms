<?php
// --- digitalmarket/init.php (FINAL AND ERROR-FREE VERSION) ---

// Step 1: Define a Base URL for all asset paths
if (!defined('BASE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $script_name = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
    if (strpos($script_name, '/public/') !== false) { $script_name = str_replace('/public/', '/', $script_name); }
    if (strpos($script_name, '/admin/') !== false) { $script_name = str_replace('/admin/', '/', $script_name); }
    if (strpos($script_name, '/partner/') !== false) { $script_name = str_replace('/partner/', '/', $script_name); }
    define('BASE_URL', $protocol . $host . rtrim($script_name, '/\\') . '/');
}

// --- THIS IS THE FIX ---
// Step 2: Include the Cashfree Autoloader
// This single line will automatically load all necessary Cashfree classes.
require_once __DIR__ . '/lib/cashfree.php';
// --- END OF FIX ---

// Step 3: Start or resume the session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Step 4: Define Root Path and Include Database Configuration
if (!defined('ROOT_PATH')) { define('ROOT_PATH', __DIR__); }
require_once ROOT_PATH . '/db_config.php';

// Step 5: Affiliate Cookie Tracking Logic
if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    setcookie('affiliate_ref', (int)$_GET['ref'], time() + (86400 * 30), "/");
}

// Step 6: Load all website settings into a global variable
try {
    $settings_from_db = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    $site_settings = (object)$settings_from_db;
} catch (PDOException $e) {
    $site_settings = (object)[
        'website_name' => 'DigiMoms', 'website_logo' => '',
        'cashfree_app_id' => '', 'cashfree_secret_key' => '',
        'payment_mode' => 'Test'
    ];
}
?>