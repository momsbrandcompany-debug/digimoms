<?php
require_once 'db_config.php';
try {
    // This SQL statement adds a FULLTEXT index on the columns we want to search.
    // This index makes the MATCH...AGAINST search incredibly fast and efficient.
    $sql = "ALTER TABLE products ADD FULLTEXT(title, description, category)";
    
    $pdo->exec($sql);
    
    echo "<h1>Success!</h1><p>The 'products' table has been updated with a FULLTEXT index for advanced searching.</p>";

} catch (PDOException $e) {
    // It's common for this to show an error if the index already exists.
    if (strpos($e->getMessage(), 'Duplicate key name') !== false) {
        echo "<h1>Already Updated!</h1><p>The FULLTEXT index already exists on the 'products' table.</p>";
    } else {
        die("<h1>Error!</h1><p>Could not update table. Error: " . $e->getMessage() . "</p>");
    }
}
?>