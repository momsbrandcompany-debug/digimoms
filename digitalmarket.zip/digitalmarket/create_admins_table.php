<?php
// create_admins_table.php

// Go up one directory to access db_config.php
require_once 'db_config.php';

try {
    // SQL to create table
    $sql = "CREATE TABLE IF NOT EXISTS admins (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )";

    $pdo->exec($sql);
    echo "Table 'admins' created successfully.<br>";

    // --- Create a default admin user ---
    
    // Check if the admin user already exists
    $stmt = $pdo->prepare("SELECT id FROM admins WHERE username = :username");
    $stmt->execute(['username' => 'admin']);
    
    if ($stmt->rowCount() == 0) {
        // If admin doesn't exist, create one
        $default_username = 'admin';
        // IMPORTANT: Never store plain text passwords. We hash it.
        $default_password = password_hash('admin123', PASSWORD_DEFAULT);

        $insert_sql = "INSERT INTO admins (username, password) VALUES (:username, :password)";
        $insert_stmt = $pdo->prepare($insert_sql);
        
        $insert_stmt->bindParam(':username', $default_username);
        $insert_stmt->bindParam(':password', $default_password);
        
        $insert_stmt->execute();
        echo "Default admin user 'admin' with password 'admin123' created successfully.";
    } else {
        echo "Default admin user 'admin' already exists.";
    }

} catch(PDOException $e) {
    die("ERROR: Could not execute script. " . $e->getMessage());
}

// Close connection
unset($pdo);
?>