<?php
require_once 'db_config.php';

try {
    // Check if the 'thumbnail' column already exists to avoid errors
    $stmt_check = $pdo->query("SHOW COLUMNS FROM `blog_posts` LIKE 'thumbnail'");
    $column_exists = $stmt_check->fetch();

    if ($column_exists) {
        echo "<h1>Already Updated!</h1><p>The 'thumbnail' column already exists in the 'blog_posts' table.</p>";
    } else {
        // SQL statement to add the new 'thumbnail' column
        $sql = "ALTER TABLE blog_posts ADD COLUMN `thumbnail` VARCHAR(255) NULL AFTER `content`";
        $pdo->exec($sql);
        echo "<h1>Success!</h1><p>The 'thumbnail' column has been added to the 'blog_posts' table successfully.</p>";
    }

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not alter the table. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>```

}

// --- Prepare Data for Display ---
$edit_mode = false;
$post_to_edit = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $edit_mode = true;
    $id = (int)$_GET['id'];
    $stmt_post = $pdo->prepare("SELECT * FROM blog_posts WHERE id = :id");
    $stmt_post->execute(['id' => $id]);
    $post_to_edit = $stmt_post->fetch(PDO::FETCH_ASSOC);
}

// Fetch all posts for the list
$posts = $pdo->query("SELECT bp.id, bp.title, bc.name as category_name, bp.created_at FROM blog_posts bp JOIN blog_categories bc ON bp.category_id = bc.id ORDER BY bp.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch categories for the dropdown
$categories = $pdo->query("SELECT * FROM blog_categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>
<style>
    /* All necessary styles are included */
    .page-header { /* ... */ } .panel { /* ... */ } .table { /* ... */ }
</style>

<h1 class="page-header"><?php echo $edit_mode ? 'Edit Post' : 'Write a New Post'; ?></h1>

<div class="panel">
    <form action="blog_manager.php" method="POST" enctype="multipart/form-data">
        <?php if ($edit_mode): ?><input type="hidden" name="post_id" value="<?php echo $post_to_edit['id']; ?>"><?php endif; ?>
        <div class="form-group">
            <label>Post Title</label>
            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($post_to_edit['title'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label>Category</label>
            <select name="category_id" class="form-control" required>
                <option value="">Select a category</option>
                <?php if (empty($categories)) { echo '<option value="" disabled>Please add a category first!</option>'; } ?>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php if ($edit_mode && $cat['id'] == $post_to_edit['category_id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Featured Image (Thumbnail)</label>
            <input type="file" name="thumbnail" class="form-control" accept="image/*">
            <?php if ($edit_mode && !empty($post_to_edit['thumbnail'])): ?>
                <p style="margin-top:10px;">Current image: <img src="../<?php echo htmlspecialchars($post_to_edit['thumbnail']); ?>" alt="" height="60"></p>
                <input type="hidden" name="existing_thumbnail" value="<?php echo htmlspecialchars($post_to_edit['thumbnail']); ?>">
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label>Content</label>
            <textarea name="content" id="editor"><?php echo htmlspecialchars($post_to_edit['content'] ?? ''); ?></textarea>
        </div>
        <button type="submit" name="save_post" class="btn-primary"><?php echo $edit_mode ? 'Update Post' : 'Publish Post'; ?></button>
        <?php if ($edit_mode): ?><a href="blog_manager.php" class="btn-secondary">Cancel Edit</a><?php endif; ?>
    </form>
</div>

<div class="panel table-panel">
    <h2 class="panel-title">All Published Posts</h2>
    <table class="table">
        <thead><tr><th>Title</th><th>Category</th><th>Published On</th><th>Actions</th></tr></thead>
        <tbody>
            <?php foreach ($posts as $post): ?>
            <tr>
                <td><?php echo htmlspecialchars($post['title']); ?></td>
                <td><?php echo htmlspecialchars($post['category_name']); ?></td>
                <td><?php echo date('d M Y', strtotime($post['created_at'])); ?></td>
                <td>
                    <a href="blog_manager.php?action=edit&id=<?php echo $post['id']; ?>">Edit</a> | 
                    <a href="blog_manager.php?action=delete&id=<?php echo $post['id']; ?>" onclick="return confirm('Are you sure you want to delete this post?');" style="color:red;">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>