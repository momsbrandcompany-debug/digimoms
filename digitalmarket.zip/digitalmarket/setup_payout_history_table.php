<?php
require_once 'db_config.php';
try {
    // Step 1: Drop the old, separate payout tables if they exist
    $pdo->exec("DROP TABLE IF EXISTS `affiliate_payouts`;");
    $pdo->exec("DROP TABLE IF EXISTS `trainer_payouts`;");
    echo "<p>Old payout tables ('affiliate_payouts', 'trainer_payouts') removed successfully.</p>";

    // Step 2: Create the new, unified payout history table
    $sql = "CREATE TABLE IF NOT EXISTS payout_history (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        partner_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes TEXT NULL, -- To store transaction ID or other details
        FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>The new unified 'payout_history' table has been created successfully.</p>";

} catch (PDOException $e) {
    die("<h1>Error!</h1><p>" . $e->getMessage() . "</p>");
}
?>