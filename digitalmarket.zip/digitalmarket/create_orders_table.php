<?php
// create_orders_table.php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS orders (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        product_id INT NOT NULL,
        customer_name VARCHAR(100) NOT NULL,
        customer_email VARCHAR(100) NOT NULL,
        amount_paid DECIMAL(10, 2) NOT NULL,
        payment_status VARCHAR(50) NOT NULL DEFAULT 'Pending',
        transaction_id VARCHAR(255) NULL,
        coupon_used VARCHAR(50) NULL,
        order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )";

    $pdo->exec($sql);
    echo "Table 'orders' created successfully.";

} catch(PDOException $e) {
    die("ERROR: Could not able to execute $sql. " . $e->getMessage());
}

// Close connection
unset($pdo);
?>