<?php
require_once 'db_config.php';

try {
    // --- STEP 1: CREATE THE TABLE IF IT DOESN'T EXIST ---
    $sql_create = "CREATE TABLE IF NOT EXISTS password_resets (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        token VARCHAR(255) NOT NULL,
        expires_at DATETIME NOT NULL,
        request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql_create);
    echo "<h3>Step 1: 'password_resets' table checked/created successfully.</h3>";

    // --- STEP 2: ADD NEW COLUMNS IF THEY DON'T EXIST ---
    // Check for 'user_mobile' column
    $stmt_check_mobile = $pdo->query("SHOW COLUMNS FROM `password_resets` LIKE 'user_mobile'");
    if (!$stmt_check_mobile->fetch()) {
        $pdo->exec("ALTER TABLE password_resets ADD COLUMN user_mobile VARCHAR(15) NOT NULL AFTER user_id");
        echo "<p>- 'user_mobile' column added.</p>";
    }

    // Check for 'status' column
    $stmt_check_status = $pdo->query("SHOW COLUMNS FROM `password_resets` LIKE 'status'");
    if (!$stmt_check_status->fetch()) {
        $pdo->exec("ALTER TABLE password_resets ADD COLUMN status ENUM('Pending', 'Completed') NOT NULL DEFAULT 'Pending' AFTER expires_at");
        echo "<p>- 'status' column added.</p>";
    }

    echo "<h2>Success!</h2><p>The 'password_resets' table is now fully set up and updated.</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>An error occurred. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>