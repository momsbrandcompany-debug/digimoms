<?php
require_once 'db_config.php';
try {
    // We add a `user_type` column to distinguish between regular users and trainers.
    // We also add a column to track their trainer application status.
    $sql = "ALTER TABLE users 
            ADD COLUMN `user_type` ENUM('student', 'trainer') NOT NULL DEFAULT 'student',
            ADD COLUMN `trainer_application_status` ENUM('none', 'pending', 'approved', 'rejected') NOT NULL DEFAULT 'none'";
    
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>The 'users' table has been updated for the Trainer feature.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not update table. It might already be updated. Error: " . $e->getMessage() . "</p>");
}
?>
```**করণীয়:** ব্রাউজারে `http://localhost/digitalmarket/update_users_table.php` রান করে টেবিলটি আপডেট করুন। সফল হলে, ফাইলটি ডিলিট করে দিন।

#### **২. `my_account.php` পেজে "Become a Trainer" সেকশন যোগ করা**

এখন আমরা `my_account.php` পেজে একটি নতুন সেকশন যোগ করব, যেখান থেকে ব্যবহারকারীরা ট্রেনার হওয়ার জন্য আবেদন করতে পারবেন।

`public/my_account.php` ফাইলের **পুরোনো সমস্ত কোড মুছে ফেলুন** এবং নিচের **নতুন কোডটি** পেস্ট করুন।

```php
<?php
require_once '../init.php';
include 'header.php';
if (!isset($_SESSION["user_loggedin"])) { header("location: login.php"); exit; }
$user_id = $_SESSION['user_id'];

// --- Handle Trainer Application ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply_trainer'])) {
    // Update the user's status to 'pending'
    $stmt_apply = $pdo->prepare("UPDATE users SET trainer_application_status = 'pending' WHERE id = :user_id");
    $stmt_apply->execute(['user_id' => $user_id]);
    // Refresh the page to show the new status
    header("Location: my_account.php");
    exit;
}

// Fetch user's current status
$stmt_user = $pdo->prepare("SELECT trainer_application_status FROM users WHERE id = :user_id");
$stmt_user->execute(['user_id' => $user_id]);
$user_status = $stmt_user->fetch(PDO::FETCH_ASSOC);
$trainer_status = $user_status['trainer_application_status'];


// Fetch purchased products and meetings (no changes here)
// ... (code to fetch purchases and meetings from previous step)
?>

<!-- Your existing CSS + New CSS for the trainer section -->
<style>
    /* ... (All your existing correct styles for account header, layout, purchase list, noticeboard) ... */
    .trainer-panel {
        background-color: #fff;
        border: 1px solid #eee;
        border-radius: 10px;
        padding: 25px;
        text-align: center;
        margin-top: 40px;
    }
    .trainer-panel h2 { font-size: 22px; color: #1a253c; }
    .btn-apply { padding: 12px 25px; background-color: #ffc107; color: #333 !important; font-weight: 600; border-radius: 50px; text-decoration: none; border: none; cursor: pointer; }
    .status-message { font-weight: 600; padding: 15px; border-radius: 8px; }
    .status-pending { background-color: #fff3cd; color: #856404; }
    .status-approved { background-color: #d4edda; color: #155724; }
</style>

<!-- Your existing HTML for header and account layout -->
<div class="account-header"> <!-- ... --> </div>

<div class="container">
    <div class="account-layout">
        <!-- Left Column: Purchase History -->
        <div>
            <h2>My Purchase History</h2>
            <!-- ... (Your correct purchase list HTML) ... -->
        </div>
        
        <!-- Right Column: Sidebar -->
        <div>
            <!-- ... (Your correct Profile and Seminar panels) ... -->
        </div>
    </div>

    <!-- NEW: Become a Trainer Section at the bottom -->
    <div class="trainer-panel">
        <?php if ($trainer_status === 'none'): ?>
            <h2>Ready to Share Your Knowledge?</h2>
            <p>Become a trainer on our platform and host your own paid seminars. Apply now to start your journey!</p>
            <form method="POST" action="my_account.php">
                <button type="submit" name="apply_trainer" class="btn-apply">Apply to Become a Trainer</button>
            </form>
        <?php elseif ($trainer_status === 'pending'): ?>
            <h2>Application Submitted!</h2>
            <p class="status-message status-pending">Your application to become a trainer is currently under review. We will notify you soon.</p>
        <?php elseif ($trainer_status === 'approved'): ?>
            <h2>Congratulations, Trainer!</h2>
            <p class="status-message status-approved">Your application has been approved! You can now start creating and hosting your seminars.</p>
            <!-- We will add a link to the Trainer Dashboard here later -->
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>