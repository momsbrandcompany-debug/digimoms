<?php
require_once 'db_config.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS live_meetings (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        meeting_title VARCHAR(255) NOT NULL,
        meeting_link TEXT NOT NULL,
        passcode VARCHAR(100) NOT NULL,
        meeting_date DATE NOT NULL,
        is_active BOOLEAN NOT NULL DEFAULT 1
    )";

    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'live_meetings' has been created successfully.</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not create table. Error: " . $e->getMessage() . "</p>");
}
?>