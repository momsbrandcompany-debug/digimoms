<?php
require_once 'db_config.php';
try {
    // Drop foreign key constraint first from 'products' table
    // We need to find the constraint name first
    $stmt_fk = $pdo->query("SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = 'products' AND COLUMN_NAME = 'created_by_trainer_id' AND REFERENCED_TABLE_NAME = 'partners'");
    $fk_name = $stmt_fk->fetchColumn();
    if ($fk_name) {
        $pdo->exec("ALTER TABLE products DROP FOREIGN KEY `{$fk_name}`");
    }
    // Now drop the column itself
    $pdo->exec("ALTER TABLE products DROP COLUMN `created_by_trainer_id`");
    echo "<p>'products' table reverted successfully.</p>";

    // Drop columns from 'sales' table
    $pdo->exec("ALTER TABLE sales DROP COLUMN `trainer_commission`, DROP COLUMN `platform_fee`");
    echo "<p>'sales' table reverted successfully.</p>";
    
    echo "<h2>Success!</h2><p>Database tables have been reverted to their previous state.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not revert tables. They might already be reverted. Error: " . $e->getMessage() . "</p>");
}
?>