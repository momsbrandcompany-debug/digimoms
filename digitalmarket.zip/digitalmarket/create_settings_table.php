<?php
require_once 'db_config.php';
try {
    // This table will store all website settings as key-value pairs
    $sql = "CREATE TABLE IF NOT EXISTS settings (
        setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
        setting_value TEXT NULL
    )";
    $pdo->exec($sql);

    // --- Insert Default Settings ---
    // We use INSERT IGNORE to prevent errors if the keys already exist
    $default_settings = [
        'website_name' => 'DigiMoms',
        'website_logo' => '', // Path to the logo image
        'contact_email' => 'contact@example.com',
        'contact_phone' => '+911234567890',
        'privacy_policy' => 'Your privacy policy content goes here.',
        'terms_conditions' => 'Your terms and conditions content goes here.',
        'refund_policy' => 'Your refund policy content goes here.'
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO settings (setting_key, setting_value) VALUES (:key, :value)");
    foreach ($default_settings as $key => $value) {
        $stmt->execute(['key' => $key, 'value' => $value]);
    }

    echo "<h1>Success!</h1><p>Table 'settings' has been created and default values have been inserted.</p>";

} catch (PDOException $e) {
    die("<h1>Error!</h1><p>". $e->getMessage() . "</p>");
}
?>