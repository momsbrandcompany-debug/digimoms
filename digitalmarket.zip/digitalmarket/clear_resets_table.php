<?php
require_once 'db_config.php';

try {
    // SQL statement to TRUNCATE the table.
    // TRUNCATE is faster than DELETE for emptying a whole table.
    $sql = "TRUNCATE TABLE password_resets";
    
    $pdo->exec($sql);
    
    echo "<h1>Success!</h1><p>The 'password_resets' table has been successfully emptied.</p><p>You can now try the 'Forgot Password' process again from the beginning.</p><p><strong>Important:</strong> You can now delete this file (clear_resets_table.php).</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not empty the table. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>