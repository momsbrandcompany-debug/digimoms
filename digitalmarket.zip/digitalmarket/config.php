<?php
// config.php

// Define the base URL of your project.
// Make sure to have the trailing slash '/'
define('BASE_URL', 'http://localhost/digitalmarket/');

?>