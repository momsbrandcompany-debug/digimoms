<?php
require_once 'db_config.php';
try {
    // Add columns to store the user's mobile and a status
    $sql = "ALTER TABLE password_resets 
            ADD COLUMN user_mobile VARCHAR(15) NOT NULL AFTER user_id,
            ADD COLUMN status ENUM('Pending', 'Completed') NOT NULL DEFAULT 'Pending' AFTER expires_at";
    
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>The 'password_resets' table has been updated successfully.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not update table. It might already be updated. Error: " . $e->getMessage() . "</p>");
}
?>