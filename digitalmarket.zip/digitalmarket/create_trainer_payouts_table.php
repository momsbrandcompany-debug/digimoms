<?php
require_once 'db_config.php';
try {
    $sql = "CREATE TABLE IF NOT EXISTS trainer_payouts (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        trainer_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes TEXT NULL, -- To store transaction ID or other details
        FOREIGN KEY (trainer_id) REFERENCES partners(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'trainer_payouts' created successfully.</p>";
} catch (PDOException $e) { die("<h1>Error!</h1><p>" . $e->getMessage() . "</p>"); }
?>