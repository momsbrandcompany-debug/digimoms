<?php
require_once 'db_config.php';
try {
    $sql = "CREATE TABLE IF NOT EXISTS seminar_attendees (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        seminar_id INT NOT NULL,
        trainer_id INT NOT NULL,
        attendee_name VARCHAR(255) NOT NULL,
        attendee_contact VARCHAR(100) NOT NULL,
        payment_amount DECIMAL(10, 2) NOT NULL,
        platform_fee DECIMAL(10, 2) NOT NULL,
        trainer_earning DECIMAL(10, 2) NOT NULL,
        payment_status VARCHAR(50) DEFAULT 'Completed',
        registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (seminar_id) REFERENCES seminars(id) ON DELETE CASCADE,
        FOREIGN KEY (trainer_id) REFERENCES partners(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>Table 'seminar_attendees' has been created successfully.</p>";
} catch (PDOException $e) { die("<h1>Error!</h1><p>" . $e->getMessage() . "</p>"); }
?>