<?php
include 'header.php';
$message = '';
$message_type = '';

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_payment'])) {
    $payment_details = trim($_POST['payment_details']);
    $stmt = $pdo->prepare("UPDATE partners SET payment_details = :details WHERE id = :id");
    if ($stmt->execute(['details' => $payment_details, 'id' => $partner_id])) {
        $message = "Payment details updated successfully!";
        $message_type = 'success';
    } else {
        $message = "Could not update details. Please try again.";
        $message_type = 'error';
    }
}

// Fetch current partner's data
$stmt = $pdo->prepare("SELECT * FROM partners WHERE id = :id");
$stmt->execute(['id' => $partner_id]);
$partner_data = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<style>
    .page-title { /* ... */ } .panel { /* ... */ } .panel-title { /* ... */ }
    .form-group { margin-bottom: 20px; }
    .form-control-static { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 16px; background-color: #f8f9fa; cursor: not-allowed; }
    .btn-primary { /* ... */ }
    .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
    .alert-success { background-color: #d4edda; color: #155724; }
</style>

<h1 class="page-title">My Profile</h1>

<?php if($message) echo "<div class='alert alert-$message_type'>$message</div>"; ?>

<div class="panel">
    <h2 class="panel-title">Your Details</h2>
    <form action="profile.php" method="post">
        <div class="form-group"><label>Name</label><input type="text" class="form-control-static" value="<?php echo htmlspecialchars($partner_data['name']); ?>" readonly></div>
        <div class="form-group"><label>Mobile (Login ID)</label><input type="text" class="form-control-static" value="<?php echo htmlspecialchars($partner_data['mobile']); ?>" readonly></div>
        <div class="form-group"><label>Your Rank</label><input type="text" class="form-control-static" value="<?php echo htmlspecialchars($partner_data['rank']); ?>" readonly></div>
        <div class="form-group">
            <label for="payment_details">Payment Details (UPI ID / Bank Account)</label>
            <textarea id="payment_details" name="payment_details" class="form-control" rows="3"><?php echo htmlspecialchars($partner_data['payment_details']); ?></textarea>
            <small>This is where we will send your payments. Please keep it updated.</small>
        </div>
        <button type="submit" name="update_payment" class="btn-primary">Update Payment Details</button>
    </form>
</div>

<?php include 'footer.php'; ?>