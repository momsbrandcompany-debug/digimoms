<?php
include 'header.php';
if ($trainer_status !== 'approved') { /* ... Access Denied ... */ exit; }

// Fetch earning summary
$stmt_earning = $pdo->prepare("SELECT SUM(trainer_earning) FROM seminar_attendees WHERE trainer_id = :id");
$stmt_earning->execute(['id' => $partner_id]);
$total_earning = $stmt_earning->fetchColumn() ?? 0;

$stmt_paid = $pdo->prepare("SELECT SUM(amount) FROM trainer_payouts WHERE trainer_id = :id");
$stmt_paid->execute(['id' => $partner_id]);
$total_paid = $stmt_paid->fetchColumn() ?? 0;

$current_due = $total_earning - $total_paid;

// Fetch payout history
$stmt_history = $pdo->prepare("SELECT * FROM trainer_payouts WHERE trainer_id = :id ORDER BY payment_date DESC");
$stmt_history->execute(['id' => $partner_id]);
$payout_history = $stmt_history->fetchAll(PDO::FETCH_ASSOC);
?>

<h1 class="page-title">My Seminar Earnings</h1>

<div class="stats-grid">
    <div class="stat-card"><h3>Total Earning</h3><p class="amount">₹<?php echo number_format($total_earning, 2); ?></p></div>
    <div class="stat-card"><h3>Total Paid Out</h3><p class="amount">₹<?php echo number_format($total_paid, 2); ?></p></div>
    <div class="stat-card"><h3>Current Due Balance</h3><p class="amount">₹<?php echo number_format($current_due, 2); ?></p></div>
</div>

<div class="panel">
    <h2 class="panel-title">Payout History</h2>
    <table class="table">
        <thead><tr><th>Date</th><th>Amount Paid</th><th>Notes (e.g., Txn ID)</th></tr></thead>
        <tbody>
            <?php foreach ($payout_history as $payout): ?>
                <tr>
                    <td><?php echo date('d M Y', strtotime($payout['payment_date'])); ?></td>
                    <td>₹<?php echo number_format($payout['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($payout['notes']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include 'footer.php'; ?>