<?php
session_start();
require_once '../db_config.php';
if (!isset($_SESSION["partner_loggedin"]) || $_SESSION["partner_loggedin"] !== true) {
    header("location: ../public/partner_login.php");
    exit;
}
$partner_id = $_SESSION['partner_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7fA; margin: 0; display: flex; }
        .sidebar { width: 250px; background-color: #2c3e50; color: white; height: 100vh; position: fixed; display: flex; flex-direction: column; }
        .sidebar-header { padding: 20px; text-align: center; font-size: 24px; font-weight: 700; border-bottom: 1px solid #34495e; }
        .sidebar-nav { list-style: none; padding: 0; margin: 0; flex-grow: 1; }
        .sidebar-nav li a { display: block; color: #ecf0f1; padding: 18px 25px; text-decoration: none; border-left: 4px solid transparent; transition: all 0.3s; }
        .sidebar-nav li a:hover { background-color: #34495e; border-left-color: #3498db; }
        .sidebar-footer { padding: 20px; text-align: center; border-top: 1px solid #34495e; }
        .sidebar-footer a { color: #ecf0f1; text-decoration: none; }
        .main-content { margin-left: 250px; width: calc(100% - 250px); }
        .top-navbar { background-color: #ffffff; padding: 15px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; justify-content: flex-end; align-items: center; gap: 20px; }
        .top-navbar .nav-btn { text-decoration: none; padding: 8px 15px; border-radius: 5px; color: white; font-weight: 500; }
        .view-site-btn { background-color: #28a745; } .logout-btn { background-color: #e74c3c; }
        .page-content { padding: 30px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">Partner Panel</div>
        <ul class="sidebar-nav">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="sales.php">Sales Report</a></li>
            <li><a href="team.php">Team Report</a></li>
            <li><a href="become_trainer.php">Become a Trainer</a></li>
            <li><a href="my_seminars.php">My Seminars</a></li>
            <li><a href="earnings.php">My Earnings Report</a></li>
            <li><a href="coupons.php">My Coupons</a></li>
            <li><a href="profile.php">Profile</a></li>
        </ul>
        <div class="sidebar-footer">
            <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION["partner_name"]); ?></strong></p>
        </div>
    </div>
    <div class="main-content">
        <div class="top-navbar">
            <a href="../public/index.php" target="_blank" class="nav-btn view-site-btn">View Website</a>
            <a href="logout.php" class="nav-btn logout-btn">Logout</a>
        </div>
        <div class="page-content">