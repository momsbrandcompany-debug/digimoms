<?php
include 'header.php'; // Includes session, db connection etc.

$message = '';
$message_type = '';

// Handle new coupon request form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $coupon_code = strtoupper(trim($_POST['coupon_code'])); // Convert to uppercase for consistency
    $discount_value = (float)$_POST['discount_value'];
    $product_id = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : NULL;

    // Basic validation
    if (!empty($coupon_code) && $discount_value > 0) {
        try {
            // Check if coupon code already exists
            $stmt_check = $pdo->prepare("SELECT id FROM coupons WHERE coupon_code = :code");
            $stmt_check->execute(['code' => $coupon_code]);

            if ($stmt_check->rowCount() > 0) {
                $message = "This coupon code already exists. Please choose another one.";
                $message_type = 'error';
            } else {
                $sql = "INSERT INTO coupons (coupon_code, discount_value, partner_id, product_id, status) 
                        VALUES (:code, :value, :partner_id, :product_id, 'Pending')";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    'code' => $coupon_code,
                    'value' => $discount_value,
                    'partner_id' => $partner_id,
                    'product_id' => $product_id
                ]);
                $message = "Coupon request submitted successfully! It is now pending admin approval.";
                $message_type = 'success';
            }
        } catch (PDOException $e) {
            $message = "Database error: " . $e->getMessage();
            $message_type = 'error';
        }
    } else {
        $message = "Please fill in all fields correctly.";
        $message_type = 'error';
    }
}

// Fetch existing coupons for this partner
$stmt_my_coupons = $pdo->prepare("SELECT c.*, p.title as product_title FROM coupons c LEFT JOIN products p ON c.product_id = p.id WHERE c.partner_id = :partner_id ORDER BY c.created_at DESC");
$stmt_my_coupons->execute(['partner_id' => $partner_id]);
$my_coupons = $stmt_my_coupons->fetchAll(PDO::FETCH_ASSOC);

// Fetch all products for the dropdown
$stmt_products = $pdo->query("SELECT id, title FROM products WHERE status = 'Active' ORDER BY title ASC");
$all_products = $stmt_products->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
    .page-title { font-size: 28px; color: #2c3e50; margin-top: 0; margin-bottom: 20px; }
    .panel { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); margin-bottom: 30px; }
    .panel-title { font-size: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px; }
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .form-group { margin-bottom: 0; }
    .btn-submit { padding: 12px 25px; border: none; background-color: #007bff; color: white; cursor: pointer; border-radius: 5px; font-size: 16px; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
    .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; color: white; }
    .status-Pending { background-color: #ffc107; color: #333; }
    .status-Active { background-color: #28a745; }
    .status-Blocked { background-color: #dc3545; }
</style>

<h1 class="page-title">My Coupons</h1>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>" style="padding:15px; border-radius:5px; margin-bottom:20px; background-color: <?php echo $message_type == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $message_type == 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<!-- Create New Coupon Panel -->
<div class="panel">
    <h2 class="panel-title">Request a New Coupon</h2>
    <form action="coupons.php" method="POST">
        <div class="form-grid">
            <div class="form-group">
                <label>Coupon Code (e.g., TANMOY10)</label>
                <input type="text" name="coupon_code" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;" required>
            </div>
            <div class="form-group">
                <label>Discount Percentage (%)</label>
                <input type="number" name="discount_value" min="1" max="99" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;" required>
            </div>
            <div class="form-group">
                <label>Specific Product (Optional)</label>
                <select name="product_id" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:5px;">
                    <option value="">Apply to All Products</option>
                    <?php foreach ($all_products as $product): ?>
                        <option value="<?php echo $product['id']; ?>"><?php echo htmlspecialchars($product['title']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn-submit" style="display:block;">Send Request</button>
            </div>
        </div>
    </form>
</div>

<!-- My Coupons List Panel -->
<div class="panel">
    <h2 class="panel-title">My Existing Coupons</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Code</th>
                <th>Discount</th>
                <th>Applicable To</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($my_coupons)): ?>
                <?php foreach ($my_coupons as $coupon): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($coupon['coupon_code']); ?></strong></td>
                        <td><?php echo $coupon['discount_value']; ?>%</td>
                        <td><?php echo $coupon['product_title'] ? htmlspecialchars($coupon['product_title']) : 'All Products'; ?></td>
                        <td><span class="status-badge status-<?php echo $coupon['status']; ?>"><?php echo $coupon['status']; ?></span></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align:center;">You have not created any coupons yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>```

