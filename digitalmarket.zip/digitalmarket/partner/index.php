<?php
include 'header.php'; // This includes session_start(), db_config.php and the base layout

$partner_id = $_SESSION['partner_id'];

// --- Step 1: Fetch Affiliate & Seminar Earnings (Your existing correct logic) ---
// Direct Affiliate Earnings
$stmt_direct = $pdo->prepare("SELECT COUNT(id) as count, SUM(commission_amount) as earnings FROM sales WHERE partner_id = :id");
$stmt_direct->execute(['id' => $partner_id]);
$direct_sales_data = $stmt_direct->fetch(PDO::FETCH_ASSOC);

// Sub-Partner Affiliate Earnings
$stmt_sub = $pdo->prepare("SELECT COUNT(id) as count, SUM(parent_commission_amount) as earnings FROM sales WHERE parent_partner_id = :id");
$stmt_sub->execute(['id' => $partner_id]);
$sub_sales_data = $stmt_sub->fetch(PDO::FETCH_ASSOC);

// Trainer/Seminar Earnings
$stmt_trainer = $pdo->prepare("SELECT COUNT(id) as count, SUM(trainer_earning) as earnings FROM seminar_attendees WHERE trainer_id = :id");
$stmt_trainer->execute(['id' => $partner_id]);
$seminar_sales_data = $stmt_trainer->fetch(PDO::FETCH_ASSOC);

$total_earnings = ($direct_sales_data['earnings'] ?? 0) + ($sub_sales_data['earnings'] ?? 0) + ($seminar_sales_data['earnings'] ?? 0);
$total_sales = ($direct_sales_data['count'] ?? 0) + ($sub_sales_data['count'] ?? 0) + ($seminar_sales_data['count'] ?? 0);


// --- STEP 2: Calculate Total Paid Amount (Correct logic) ---
try {
    $stmt_paid = $pdo->prepare("SELECT SUM(amount) FROM payout_history WHERE partner_id = :id");
    $stmt_paid->execute(['id' => $partner_id]);
    $total_paid = $stmt_paid->fetchColumn() ?? 0;
} catch (PDOException $e) { $total_paid = 0; }


// --- STEP 3: Calculate the correct Pending Payments (Correct logic) ---
$pending_payments = $total_earnings - $total_paid;


// --- STEP 4: THIS IS THE FIX - Fetch Recent 5 Sales with the correct column name ---
try {
    $stmt_recent_sales = $pdo->prepare(
        "(SELECT p.title, s.sale_amount, s.commission_amount AS earnings, s.sale_date, 'Direct Affiliate' as type 
         FROM sales s JOIN products p ON s.product_id = p.id 
         WHERE s.partner_id = :partner_id1)
         UNION ALL
        (SELECT p.title, s.sale_amount, s.parent_commission_amount AS earnings, s.sale_date, 'Sub-Partner Affiliate' as type 
         FROM sales s JOIN products p ON s.product_id = p.id 
         WHERE s.parent_partner_id = :partner_id2)
         UNION ALL
        (SELECT sem.title, sa.payment_amount as sale_amount, sa.trainer_earning AS earnings, sa.registration_date as sale_date, 'Seminar Hosting' as type 
         FROM seminar_attendees sa JOIN seminars sem ON sa.seminar_product_id = sem.id -- Corrected column 'seminar_id' to 'seminar_product_id'
         WHERE sa.trainer_id = :partner_id3)
        ORDER BY sale_date DESC LIMIT 5"
    );
    $stmt_recent_sales->execute(['partner_id1' => $partner_id, 'partner_id2' => $partner_id, 'partner_id3' => $partner_id]);
    $recent_sales = $stmt_recent_sales->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // In case of error, show an empty list and maybe the error for debugging
    $recent_sales = [];
    // For debugging: echo $e->getMessage();
}


// --- Generate Referral Links (Your existing correct logic) ---
$sub_partner_referral_link = "http://localhost/digitalmarket/public/become_a_partner.php?ref=" . $partner_id;
$global_affiliate_link = "http://localhost/digitalmarket/public/index.php?ref=" . $partner_id;
?>

<!-- Your entire beautiful HTML and CSS are restored and kept unchanged -->
<style>
    .page-title { font-size: 28px; color: #2c3e50; margin-top: 0; margin-bottom: 20px; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .stat-card { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); transition: transform 0.2s; }
    .stat-card:hover { transform: translateY(-5px); }
    .stat-card h3 { margin: 0 0 10px 0; font-size: 16px; color: #555; text-transform: uppercase; }
    .stat-card .amount { font-size: 32px; font-weight: 700; color: #2c3e50; }
    .stat-card .due { color: #dc3545; }
    .panel { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); margin-top: 30px; }
    .panel-title { font-size: 20px; margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
    .table th { font-weight: 600; }
    .link-box { margin-bottom: 20px; }
    .link-box label { font-weight: 600; display: block; margin-bottom: 5px; }
    .link-input-group { display: flex; }
    .link-input { flex-grow: 1; padding: 10px; border: 1px solid #ddd; border-radius: 5px 0 0 5px; background-color: #f9f9f9; }
    .copy-btn { padding: 10px 15px; border: none; background-color: #007bff; color: white; cursor: pointer; border-radius: 0 5px 5px 0; }
</style>

<h1 class="page-title">Dashboard Overview</h1>

<div class="stats-grid">
    <div class="stat-card"><h3>Total Lifetime Earnings</h3><p class="amount">₹<?php echo number_format($total_earnings, 2); ?></p></div>
    <div class="stat-card"><h3>Total Sales Made</h3><p class="amount"><?php echo $total_sales; ?></p></div>
    <div class="stat-card"><h3>Pending Payments</h3><p class="amount due">₹<?php echo number_format($pending_payments, 2); ?></p></div>
</div>

<div class="panel">
    <h2 class="panel-title">Your Referral Links</h2>
    <div class="link-box">
        <label for="global-affiliate-link">Global Affiliate Link (for Sales)</label>
        <div class="link-input-group">
            <input type="text" id="global-affiliate-link" class="link-input" value="<?php echo htmlspecialchars($global_affiliate_link); ?>" readonly>
            <button class="copy-btn" onclick="copyToClipboard('global-affiliate-link')">Copy</button>
        </div>
    </div>
    <div class="link-box">
        <label for="sub-partner-link">Sub-Partner Recruitment Link</label>
        <div class="link-input-group">
            <input type="text" id="sub-partner-link" class="link-input" value="<?php echo htmlspecialchars($sub_partner_referral_link); ?>" readonly>
            <button class="copy-btn" onclick="copyToClipboard('sub-partner-link')">Copy</button>
        </div>
    </div>
</div>

<div class="panel">
    <h2 class="panel-title">Recent Earnings Activity</h2>
    <table class="table">
        <thead><tr><th>Source</th><th>Your Earnings</th><th>Type</th><th>Date</th></tr></thead>
        <tbody>
            <?php if (!empty($recent_sales)): ?>
                <?php foreach ($recent_sales as $sale): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($sale['title']); ?></td>
                        <td><strong>₹<?php echo number_format($sale['earnings'], 2); ?></strong></td>
                        <td><?php echo $sale['type']; ?></td>
                        <td><?php echo date('d M, Y', strtotime($sale['sale_date'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align:center; padding:20px;">No recent earnings activity.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
    function copyToClipboard(elementId) {
        var copyText = document.getElementById(elementId);
        copyText.select();
        document.execCommand("copy");
        alert("Link copied!");
    }
</script>

<?php include 'footer.php'; ?>