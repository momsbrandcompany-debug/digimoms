<?php
session_start();
// Security Check: If not logged in, redirect to login page
if (!isset($_SESSION["partner_loggedin"]) || $_SESSION["partner_loggedin"] !== true) {
    header("location: ../public/partner_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Dashboard</title>
    <!-- We will use similar styles to the admin panel, but with a green theme -->
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7fA; margin: 0; display: flex; }
        .sidebar { width: 250px; background-color: #1d2a1f; color: white; height: 100vh; position: fixed; }
        .sidebar-header { padding: 20px; text-align: center; font-size: 24px; font-weight: 700; border-bottom: 1px solid #4a5c4d; }
        .sidebar-nav { list-style: none; padding: 0; margin: 0; }
        .sidebar-nav li a { display: block; color: #ccc; padding: 18px 20px; text-decoration: none; transition: background-color 0.3s; }
        .sidebar-nav li a:hover, .sidebar-nav li a.active { background-color: #28a745; color: white; }
        .main-content { margin-left: 250px; width: calc(100% - 250px); }
        .top-navbar { background-color: #ffffff; padding: 15px 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; justify-content: flex-end; align-items: center; }
        .top-navbar a { background-color: #dc3545; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; }
        .page-content { padding: 30px; }
        .page-header { font-size: 28px; color: #1d2a1f; margin-top: 0; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">Partner Panel</div>
        <ul class="sidebar-nav">
            <li><a href="dashboard.php" class="active">Dashboard</a></li>
            <li><a href="#">My Affiliate Links</a></li>
            <li><a href="#">Earnings & Sales</a></li>
            <li><a href="#">Withdraw Requests</a></li>
            <li><a href="#">Sub-Partners</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="top-navbar">
            <span>Welcome, <b><?php echo htmlspecialchars($_SESSION["partner_name"]); ?></b></span>
            <a href="partner_logout.php" style="margin-left: 20px;">Logout</a>
        </div>
        <div class="page-content">