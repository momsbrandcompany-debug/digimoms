<?php
include 'header.php'; // Includes session, db connection etc.

$message = '';
$message_type = '';

// --- Calculate Earnings & Payouts ---
try {
    // 1. Calculate Total Earnings (Direct + Sub-partner)
    $stmt_direct = $pdo->prepare("SELECT SUM(commission_amount) FROM sales WHERE partner_id = :id");
    $stmt_direct->execute(['id' => $partner_id]);
    $direct_earnings = $stmt_direct->fetchColumn() ?? 0;

    $stmt_sub = $pdo->prepare("SELECT SUM(parent_commission_amount) FROM sales WHERE parent_partner_id = :id");
    $stmt_sub->execute(['id' => $partner_id]);
    $sub_earnings = $stmt_sub->fetchColumn() ?? 0;
    
    $total_earnings = $direct_earnings + $sub_earnings;

    // 2. Calculate Total Amount Paid Out
    $stmt_paid = $pdo->prepare("SELECT SUM(request_amount) FROM payout_requests WHERE partner_id = :id AND status = 'Completed'");
    $stmt_paid->execute(['id' => $partner_id]);
    $total_paid = $stmt_paid->fetchColumn() ?? 0;

    // 3. Calculate Current Balance (Pending Payments)
    $current_balance = $total_earnings - $total_paid;
    
    // 4. Fetch Payout History
    $stmt_history = $pdo->prepare("SELECT * FROM payout_requests WHERE partner_id = :id ORDER BY request_date DESC");
    $stmt_history->execute(['id' => $partner_id]);
    $payout_history = $stmt_history->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}


// --- Handle Withdraw Request Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_payout'])) {
    $request_amount = (float)$_POST['amount'];

    if ($request_amount > 0 && $request_amount <= $current_balance) {
        try {
            $sql = "INSERT INTO payout_requests (partner_id, request_amount) VALUES (:partner_id, :amount)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['partner_id' => $partner_id, 'amount' => $request_amount]);
            
            $message = "Your payout request of ₹" . number_format($request_amount, 2) . " has been submitted successfully.";
            $message_type = 'success';
            // Refresh the page to show the new request in the history
            header("Location: payments.php?status=success");
            exit;
        } catch (PDOException $e) {
            $message = "Could not submit your request. Please try again.";
            $message_type = 'error';
        }
    } else {
        $message = "Invalid request amount. Please enter an amount greater than 0 and less than or equal to your current balance.";
        $message_type = 'error';
    }
}
?>
<style>
    /* Re-use styles from other partner pages */
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .stat-card { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .stat-card .amount { font-size: 32px; font-weight: 700; color: #2c3e50; }
    .panel { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); margin-top: 30px; }
    .btn-request { padding: 12px 25px; border: none; background-color: #28a745; color: white; cursor: pointer; border-radius: 5px; font-size: 16px; }
    .status-badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; color: white; }
    .status-Pending { background-color: #ffc107; color: #333; } .status-Completed { background-color: #28a745; } .status-Rejected { background-color: #dc3545; }
</style>

<h1 class="page-title">My Payments</h1>

<?php if (isset($_GET['status']) && $_GET['status'] == 'success') $message = "Your payout request has been submitted successfully."; ?>
<?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>" style="padding:15px; border-radius:5px; margin-bottom:20px; background-color: <?php echo $message_type == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $message_type == 'success' ? '#155724' : '#721c24'; ?>;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<div class="stats-grid">
    <div class="stat-card"><h3>Total Lifetime Earnings</h3><p class="amount">₹<?php echo number_format($total_earnings, 2); ?></p></div>
    <div class="stat-card"><h3>Total Paid Out</h3><p class="amount">₹<?php echo number_format($total_paid, 2); ?></p></div>
    <div class="stat-card" style="border: 2px solid #28a745;"><h3>Current Balance</h3><p class="amount">₹<?php echo number_format($current_balance, 2); ?></p></div>
</div>

<!-- Withdraw Request Panel -->
<div class="panel">
    <h2>Request a Payout</h2>
    <?php if ($current_balance > 0): ?>
        <form action="payments.php" method="POST">
            <p>You can request a payout of your current balance.</p>
            <div style="display:flex; align-items:center; gap: 15px;">
                <input type="number" name="amount" value="<?php echo floor($current_balance); ?>" max="<?php echo $current_balance; ?>" step="0.01" style="width:200px; padding:10px; border:1px solid #ddd; border-radius:5px;" required>
                <button type="submit" name="request_payout" class="btn-request">Submit Request</button>
            </div>
        </form>
    <?php else: ?>
        <p>You do not have any balance to withdraw at the moment.</p>
    <?php endif; ?>
</div>

<!-- Payout History Panel -->
<div class="panel">
    <h2>Payout History</h2>
    <table class="table" style="width:100%; border-collapse: collapse;">
        <thead><tr><th>Request Date</th><th>Amount</th><th>Status</th><th>Processed Date</th></tr></thead>
        <tbody>
            <?php if (!empty($payout_history)): ?>
                <?php foreach ($payout_history as $request): ?>
                    <tr>
                        <td><?php echo date('d M Y, h:i A', strtotime($request['request_date'])); ?></td>
                        <td><strong>₹<?php echo number_format($request['request_amount'], 2); ?></strong></td>
                        <td><span class="status-badge status-<?php echo $request['status']; ?>"><?php echo $request['status']; ?></span></td>
                        <td><?php echo $request['processed_date'] ? date('d M Y', strtotime($request['processed_date'])) : 'N/A'; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align:center;">No payout requests have been made yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>