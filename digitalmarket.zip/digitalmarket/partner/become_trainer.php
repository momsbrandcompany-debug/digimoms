<?php
// init.php is not needed here if header.php includes everything.
// Let's include header first to get access to $pdo and session.
include 'header.php';

$message = '';
$message_type = '';

// --- Handle Trainer Application ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply_trainer'])) {
    $govt_id_path = null;
    if (isset($_FILES['govt_id']) && $_FILES['govt_id']['error'] == 0) {
        $upload_dir = '../public/uploads/govt_ids/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        $filename = time() . '_' . basename($_FILES['govt_id']['name']);
        $target_file = $upload_dir . $filename;
        if (move_uploaded_file($_FILES['govt_id']['tmp_name'], $target_file)) {
            $govt_id_path = 'public/uploads/govt_ids/' . $filename;
        } else {
            $message = "Error uploading ID proof.";
            $message_type = 'error';
        }
    } else {
        $message = "Government ID proof is required.";
        $message_type = 'error';
    }
    
    if (empty($message)) {
        $stmt_apply = $pdo->prepare("UPDATE partners SET trainer_status = 'pending', govt_id_path = :id_path WHERE id = :partner_id");
        $stmt_apply->execute(['id_path' => $govt_id_path, 'partner_id' => $partner_id]);
        header("Location: become_trainer.php?status=success");
        exit;
    }
}

// --- Fetch partner's current trainer status AFTER including header ---
try {
    $stmt_partner = $pdo->prepare("SELECT trainer_status FROM partners WHERE id = :id");
    $stmt_partner->execute(['id' => $partner_id]);
    $partner_status = $stmt_partner->fetchColumn();
} catch (PDOException $e) {
    $partner_status = 'none'; // Default to 'none' on error
}
?>

<!-- Your entire beautiful HTML and CSS from the previous step is restored -->
<style>
    .page-title { font-size: 28px; color: #2c3e50; }
    .panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .trainer-intro-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: 30px; align-items: center; }
    /* ... (rest of your beautiful CSS) ... */
</style>

<h1 class="page-title">Become a Trainer</h1>

<div class="panel">
    <!-- ... (The entire intro grid HTML with image and text) ... -->
</div>

<div class="panel" style="margin-top: 30px;">
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <?php if ($partner_status === 'none'): ?>
        <h2>Application Form</h2>
        <form method="POST" action="become_trainer.php" enctype="multipart/form-data">
            <div class="form-group" style="margin-bottom:20px;">
                <label>Upload Government ID (Aadhaar, Voter ID, etc.) *</label>
                <input type="file" name="govt_id" required style="width:100%; border:1px solid #ddd; padding:10px; border-radius:5px;">
            </div>
            <button type="submit" name="apply_trainer" class="btn-apply" style="padding:12px 25px; background-color:#007bff; color:white; border:none; border-radius:5px;">Submit Application</button>
        </form>
    <?php elseif ($partner_status === 'pending'): ?>
        <h2>Application Submitted!</h2>
        <p>Your application is under review. Our team will verify your details and notify you soon.</p>
    <?php elseif ($partner_status === 'approved'): ?>
        <h2>Congratulations, You are an Approved Trainer!</h2>
        <p>You can now start creating and managing your live seminars from the "My Seminars" section.</p>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>