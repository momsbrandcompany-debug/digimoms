<?php
include 'header.php';

// Fetch all active products
try {
    $stmt = $pdo->query("SELECT id, title, sale_price FROM products WHERE status = 'Active' ORDER BY title ASC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $products = [];
}
?>

<style>
    .product-list-table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
    .product-list-table th, .product-list-table td { border-bottom: 1px solid #ddd; padding: 15px; text-align: left; }
    .product-list-table th { background-color: #f2f2f2; }
    .link-box { display: flex; align-items: center; }
    .aff-link { flex-grow: 1; padding: 8px; border: 1px solid #ccc; border-radius: 4px; background-color: #f9f9f9; }
    .copy-btn { margin-left: 10px; padding: 8px 12px; cursor: pointer; }
</style>

<h1>Product Affiliate Links</h1>
<p>Share these links to earn <strong>60% commission</strong> on every successful sale.</p>

<table class="product-list-table">
    <thead>
        <tr>
            <th>Product Name</th>
            <th>Your Affiliate Link</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $index => $product): 
                $affiliate_link = "http://localhost/digitalmarket/public/product.php?id=" . $product['id'] . "&ref=" . $partner_id;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['title']); ?></td>
                    <td>
                        <div class="link-box">
                            <input type="text" id="link-<?php echo $index; ?>" class="aff-link" value="<?php echo htmlspecialchars($affiliate_link); ?>" readonly>
                            <button class="copy-btn" onclick="copyLink('link-<?php echo $index; ?>')">Copy</button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="2" style="text-align:center;">No products available for promotion yet.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<script>
function copyLink(elementId) {
    var copyText = document.getElementById(elementId);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    alert("Link copied!");
}
</script>

<?php include 'footer.php'; ?>