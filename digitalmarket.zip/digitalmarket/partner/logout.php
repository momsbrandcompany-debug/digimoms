<?php
session_start();
$_SESSION = array();
session_destroy();
header("location: ../public/partner_login.php");
exit;
?>