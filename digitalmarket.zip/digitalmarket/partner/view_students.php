<?php
include 'header.php';
$seminar_id_from_url = isset($_GET['seminar_id']) ? (int)$_GET['seminar_id'] : 0;

// Security check: ensure this seminar belongs to the logged-in trainer
try {
    $stmt_seminar = $pdo->prepare("SELECT title FROM seminars WHERE id = :id AND trainer_id = :trainer_id");
    $stmt_seminar->execute(['id' => $seminar_id_from_url, 'trainer_id' => $partner_id]);
    $seminar = $stmt_seminar->fetch(PDO::FETCH_ASSOC);
    if (!$seminar) {
        die("Access Denied or Seminar not found.");
    }
} catch (PDOException $e) { die("Database Error."); }

// --- THIS IS THE FIX for the "Unknown column" ERROR ---
// Fetch all attendees for this seminar using the correct column name 'seminar_product_id'
try {
    $stmt_attendees = $pdo->prepare("SELECT * FROM seminar_attendees WHERE seminar_product_id = :seminar_id ORDER BY registration_date DESC");
    $stmt_attendees->execute(['seminar_id' => $seminar_id_from_url]); // Use the correct column name in the WHERE clause
    $attendees = $stmt_attendees->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { $attendees = []; }
?>
<style>
    .page-title { font-size: 28px; color: #2c3e50; }
    .panel { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
    .table th { background-color: #f8f9fa; }
</style>

<h1 class="page-title">Student List for "<?php echo htmlspecialchars($seminar['title']); ?>"</h1>

<div class="panel">
    <p>This is the list of students who have paid and registered for your seminar. You can contact them on their provided number to share the final meeting link, time, and other details.</p>
    <table class="table">
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Contact Number (WhatsApp)</th>
                <th>Registration Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($attendees)): ?>
                <?php foreach ($attendees as $student): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($student['attendee_name']); ?></td>
                        <td><?php echo htmlspecialchars($student['attendee_contact']); ?></td>
                        <td><?php echo date('d M Y, h:i A', strtotime($student['registration_date'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="3" style="text-align:center; padding:20px;">No students have registered for this seminar yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>