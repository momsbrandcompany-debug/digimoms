<?php
include 'header.php'; // Includes session, db connection etc.

// Fetch ALL sales data for the logged-in partner
$stmt = $pdo->prepare(
    "(SELECT p.title, s.sale_amount, s.commission_amount AS earnings, s.sale_date, 'Direct' as type 
     FROM sales s JOIN products p ON s.product_id = p.id 
     WHERE s.partner_id = :partner_id1)
     UNION ALL
    (SELECT p.title, s.sale_amount, s.parent_commission_amount AS earnings, s.sale_date, 'Sub-Partner' as type 
     FROM sales s JOIN products p ON s.product_id = p.id 
     WHERE s.parent_partner_id = :partner_id2)
    ORDER BY sale_date DESC"
);
$stmt->execute(['partner_id1' => $partner_id, 'partner_id2' => $partner_id]);
$all_sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total earnings from all sales for the summary box
$total_earnings = array_sum(array_column($all_sales, 'earnings'));
?>
<style>
    .page-title { font-size: 28px; color: #2c3e50; margin-top: 0; margin-bottom: 20px; }
    .panel { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.07); margin-bottom: 30px; }
    .summary-box { text-align: center; }
    .summary-box h3 { text-transform: uppercase; color: #555; font-size: 16px; }
    .summary-box .amount { font-size: 36px; font-weight: 700; color: #28a745; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
    .table th { background-color: #f8f9fa; font-weight: 600; }
    .badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: 600; }
    .badge.direct { background-color: #d4edda; color: #155724; }
    .badge.sub-partner { background-color: #e9f4ff; color: #0056b3; }
</style>

<h1 class="page-title">Sales Report</h1>

<div class="panel summary-box">
    <h3>Total Earnings from All Sales</h3>
    <p class="amount">₹<?php echo number_format($total_earnings, 2); ?></p>
</div>

<div class="panel">
    <table class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Product Name</th>
                <th>Sale Amount</th>
                <th>Commission Type</th>
                <th>Your Earnings</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($all_sales)): ?>
                <?php foreach ($all_sales as $sale): ?>
                    <tr>
                        <td><?php echo date('d M Y, h:i A', strtotime($sale['sale_date'])); ?></td>
                        <td><?php echo htmlspecialchars($sale['title']); ?></td>
                        <td>₹<?php echo number_format($sale['sale_amount'], 2); ?></td>
                        <td>
                            <span class="badge <?php echo strtolower(str_replace('-','',$sale['type'])); ?>">
                                <?php echo $sale['type']; ?>
                            </span>
                        </td>
                        <td><strong>₹<?php echo number_format($sale['earnings'], 2); ?></strong></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align:center; padding: 20px;">You have not generated any sales yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>