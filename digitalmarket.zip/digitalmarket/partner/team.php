<?php
include 'header.php';

// Fetch all sub-partners (team members) recruited by the logged-in partner
try {
    $stmt_members = $pdo->prepare("SELECT id, name, mobile, email, created_at, `rank` FROM partners WHERE parent_partner_id = :parent_id ORDER BY created_at DESC");
    $stmt_members->execute(['parent_id' => $partner_id]);
    $team_members = $stmt_members->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { $team_members = []; }

// --- THIS IS THE FIX for the earning calculation ---
// We now directly sum the `parent_commission_amount` which is ALWAYS 10% of the sale_amount.
$team_earnings = 0;
$team_sales_count = 0;
try {
    $stmt_stats = $pdo->prepare(
        "SELECT COUNT(id) as count, SUM(parent_commission_amount) as earnings 
         FROM sales 
         WHERE parent_partner_id = :parent_id"
    );
    $stmt_stats->execute(['parent_id' => $partner_id]);
    $team_stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);
    
    $team_sales_count = $team_stats['count'] ?? 0;
    $team_earnings = $team_stats['earnings'] ?? 0;
} catch (PDOException $e) { /* Handle error */ }
?>

<style>
    .page-title { font-size: 28px; color: #2c3e50; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
    .stat-card { background-color: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 5px B20px rgba(0,0,0,0.08); text-align: center; }
    .stat-card h3 { margin: 0 0 10px 0; font-size: 16px; color: #555; text-transform: uppercase; }
    .stat-card .amount { font-size: 36px; font-weight: 700; color: #007bff; }
    .panel { background-color: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); }
    .panel-title { font-size: 22px; color: #333; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 25px; margin-top: 0; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
    .table th { background-color: #f8f9fa; font-weight: 600; }
</style>

<h1 class="page-title">My Team Report</h1>

<div class="stats-grid">
    <div class="stat-card">
        <h3>Total Team Members</h3>
        <p class="amount"><?php echo count($team_members); ?></p>
    </div>
    <div class="stat-card">
        <h3>Total Sales by Team</h3>
        <p class="amount"><?php echo $team_sales_count; ?></p>
    </div>
    <div class="stat-card">
        <h3>Your Earnings from Team (10%)</h3>
        <p class="amount" style="color:#28a745;">₹<?php echo number_format($team_earnings, 2); ?></p>
    </div>
</div>

<div class="panel">
    <h2 class="panel-title">My Team Member List</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Contact (Mobile / Email)</th>
                <th>Joining Date</th>
                <th>Rank</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($team_members)): ?>
                <?php foreach ($team_members as $member): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($member['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($member['mobile']); ?><br><small><?php echo htmlspecialchars($member['email']); ?></small></td>
                        <td><?php echo date('d M Y', strtotime($member['created_at'])); ?></td>
                        <td><?php echo htmlspecialchars($member['rank']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align:center; padding:20px;">You have not recruited any team members yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>