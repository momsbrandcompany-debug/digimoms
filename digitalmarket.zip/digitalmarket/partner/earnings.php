<?php
include 'header.php'; // Includes partner session, db connection

// --- THIS IS THE FIX for the 'Undefined variable $trainer_status' ERROR ---
// We need to check the trainer status on this page to decide if we should show seminar earnings.
try {
    $stmt_check_trainer = $pdo->prepare("SELECT trainer_status FROM partners WHERE id = :id");
    $stmt_check_trainer->execute(['id' => $partner_id]);
    $trainer_status = $stmt_check_trainer->fetchColumn();
} catch (PDOException $e) {
    $trainer_status = 'none'; // Default to 'none' on error
}


// --- 1. Fetch Affiliate Earnings (Direct & Sub-Partner) ---
try {
    $stmt_affiliate = $pdo->prepare(
        "SELECT 
            (SELECT SUM(commission_amount) FROM sales WHERE partner_id = :id1) as direct,
            (SELECT SUM(parent_commission_amount) FROM sales WHERE parent_partner_id = :id2) as sub"
    );
    $stmt_affiliate->execute(['id1' => $partner_id, 'id2' => $partner_id]);
    $affiliate_earnings = $stmt_affiliate->fetch(PDO::FETCH_ASSOC);
    $total_affiliate_earnings = ($affiliate_earnings['direct'] ?? 0) + ($affiliate_earnings['sub'] ?? 0);
} catch (PDOException $e) {
    $total_affiliate_earnings = 0;
}


// --- 2. Fetch Trainer/Seminar Earnings (only if they are an approved trainer) ---
$total_seminar_earnings = 0;
if ($trainer_status === 'approved') {
    try {
        $stmt_seminar = $pdo->prepare("SELECT SUM(trainer_earning) FROM seminar_attendees WHERE trainer_id = :id");
        $stmt_seminar->execute(['id' => $partner_id]);
        $total_seminar_earnings = $stmt_seminar->fetchColumn() ?? 0;
    } catch (PDOException $e) {
        $total_seminar_earnings = 0;
    }
}

// --- 3. Fetch Grand Total Paid from the unified 'payout_history' table ---
try {
    $stmt_paid = $pdo->prepare("SELECT SUM(amount) FROM payout_history WHERE partner_id = :id");
    $stmt_paid->execute(['id' => $partner_id]);
    $grand_total_paid = $stmt_paid->fetchColumn() ?? 0;
} catch (PDOException $e) {
    $grand_total_paid = 0;
}


// --- 4. Calculate Final Totals ---
$grand_total_earnings = $total_affiliate_earnings + $total_seminar_earnings;
$current_due_balance = $grand_total_earnings - $grand_total_paid;


// --- 5. Fetch Payout History from the unified 'payout_history' table ---
try {
    $stmt_history = $pdo->prepare("SELECT * FROM payout_history WHERE partner_id = :id ORDER BY payment_date DESC");
    $stmt_history->execute(['id' => $partner_id]);
    $payout_history = $stmt_history->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $payout_history = [];
}
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .page-title { font-size: 28px; color: #2c3e50; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
    .stat-card { background-color: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); text-align: center; }
    .stat-card h3 { margin: 0 0 10px 0; font-size: 16px; color: #555; text-transform: uppercase; }
    .stat-card .amount { font-size: 36px; font-weight: 700; color: #2c3e50; }
    .stat-card .due { color: #dc3545; }
    .panel { background-color: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); margin-bottom: 30px; }
    .panel-title { font-size: 22px; color: #333; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 25px; margin-top: 0; }
    .earning-breakdown { list-style: none; padding: 0; margin: 0; }
    .earning-breakdown li { display: flex; justify-content: space-between; align-items: center; padding: 15px 0; border-bottom: 1px solid #f0f0f0; font-size: 16px; }
    .earning-breakdown li:last-child { border-bottom: none; }
    .earning-breakdown span { color: #555; }
    .earning-breakdown strong { font-size: 18px; font-weight: 600; color: #28a745; }
    .payment-info-box { background-color: #e9f4ff; border-left: 4px solid #007bff; padding: 20px; border-radius: 8px; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
    .table th { background-color: #f8f9fa; }
</style>

<h1 class="page-title">My Complete Earnings Report</h1>

<div class="stats-grid">
    <div class="stat-card">
        <h3>Lifetime Total Earnings</h3>
        <p class="amount">₹<?php echo number_format($grand_total_earnings, 2); ?></p>
    </div>
    <div class="stat-card">
        <h3>Total Paid Out</h3>
        <p class="amount">₹<?php echo number_format($grand_total_paid, 2); ?></p>
    </div>
    <div class="stat-card">
        <h3>Current Due Balance</h3>
        <p class="amount due">₹<?php echo number_format($current_due_balance, 2); ?></p>
    </div>
</div>

<div class="panel">
    <h2 class="panel-title">Earning Source Breakdown</h2>
    <ul class="earning-breakdown">
        <li>
            <span>Affiliate Commission (Direct Sales)</span>
            <strong>₹<?php echo number_format($affiliate_earnings['direct'] ?? 0, 2); ?></strong>
        </li>
        <li>
            <span>Affiliate Commission (Sub-Partner Sales)</span>
            <strong>₹<?php echo number_format($affiliate_earnings['sub'] ?? 0, 2); ?></strong>
        </li>
        <?php if ($trainer_status === 'approved'): ?>
        <li>
            <span>Seminar Hosting Earnings</span>
            <strong>₹<?php echo number_format($total_seminar_earnings, 2); ?></strong>
        </li>
        <?php endif; ?>
    </ul>
</div>

<div class="panel">
    <h2 class="panel-title">Payout History</h2>
    <table class="table">
        <thead><tr><th>Date</th><th>Amount Paid</th><th>Notes (e.g., Transaction ID)</th></tr></thead>
        <tbody>
            <?php if (!empty($payout_history)): ?>
                <?php foreach ($payout_history as $payout): ?>
                    <tr>
                        <td><?php echo date('d M Y', strtotime($payout['payment_date'])); ?></td>
                        <td>₹<?php echo number_format($payout['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($payout['notes']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="3" style="text-align:center; padding: 20px;">No payments have been processed yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<div class="panel">
    <h2 class="panel-title">Payout Information</h2>
    <div class="payment-info-box">
        <p><strong>Payment Schedule:</strong> Payments are processed twice a month.</p>
        <ul>
            <li>Earnings from 1st to 15th of the month are paid by the <strong>20th</strong>.</li>
            <li>Earnings from 16th to the end of the month are paid by the <strong>7th</strong> of the next month.</li>
        </ul>
        <p>No payout request is needed from your side. Please ensure your payment details are up-to-date on your <a href="profile.php">Profile Page</a> to receive payments on time.</p>
    </div>
</div>

<?php include 'footer.php'; ?>