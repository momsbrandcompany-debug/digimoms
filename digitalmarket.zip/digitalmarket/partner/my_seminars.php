<?php
include 'header.php';

// Check if the partner is an approved trainer
$stmt_check_trainer = $pdo->prepare("SELECT trainer_status FROM partners WHERE id = :id");
$stmt_check_trainer->execute(['id' => $partner_id]);
$trainer_status = $stmt_check_trainer->fetchColumn();

if ($trainer_status !== 'approved') {
    echo "<h1 class='page-title' style='color:#dc3545;'>Access Denied</h1><p>You must be an approved trainer to access this page.</p>";
    include 'footer.php';
    exit;
}

// --- Handle "Mark as Completed" action ---
if (isset($_GET['action']) && $_GET['action'] === 'complete' && isset($_GET['seminar_id'])) {
    $seminar_id_to_complete = (int)$_GET['seminar_id'];
    // Security check: ensure this seminar belongs to the logged-in trainer
    $stmt_check_owner = $pdo->prepare("SELECT id FROM seminars WHERE id = :id AND trainer_id = :trainer_id AND status = 'Active'");
    $stmt_check_owner->execute(['id' => $seminar_id_to_complete, 'trainer_id' => $partner_id]);
    if ($stmt_check_owner->rowCount() > 0) {
        $stmt_complete = $pdo->prepare("UPDATE seminars SET status = 'Completed' WHERE id = :id");
        $stmt_complete->execute(['id' => $seminar_id_to_complete]);
    }
    header("Location: my_seminars.php?status=completed");
    exit;
}

// --- Handle new seminar submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_seminar'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price = (float)$_POST['price'];
    
    $thumbnail_path = '';
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        $upload_dir = '../public/uploads/seminar_thumbnails/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        $filename = time() . '_' . uniqid() . '_' . basename($_FILES['thumbnail']['name']);
        if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $upload_dir . $filename)) {
            $thumbnail_path = 'public/uploads/seminar_thumbnails/' . $filename;
        }
    }
    
    $sql = "INSERT INTO seminars (title, description, price, thumbnail, trainer_id, status) 
            VALUES (:title, :desc, :price, :thumb, :trainer_id, 'Pending')";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['title' => $title, 'desc' => $description, 'price' => $price, 'thumb' => $thumbnail_path, 'trainer_id' => $partner_id]);
    header("Location: my_seminars.php?status=submitted");
    exit;
}

// --- Fetch seminars with student count and earnings ---
$stmt_seminars = $pdo->prepare(
    "SELECT s.id, s.title, s.price, s.status, 
            (SELECT COUNT(sa.id) FROM seminar_attendees sa WHERE sa.seminar_product_id = s.id) as student_count,
            (SELECT SUM(sa.trainer_earning) FROM seminar_attendees sa WHERE sa.seminar_product_id = s.id) as total_earning
     FROM seminars s 
     WHERE s.trainer_id = :id 
     ORDER BY s.id DESC"
);
$stmt_seminars->execute(['id' => $partner_id]);
$my_seminars = $stmt_seminars->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- COMPLETE CSS FOR THIS PAGE -->
<style>
    .page-title { font-size: 28px; color: #2c3e50; }
    .panel { background-color: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); margin-bottom: 30px; }
    .panel-title { font-size: 22px; color: #333; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 25px; margin-top: 0; }
    .form-group { margin-bottom: 20px; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 16px; }
    label { font-weight: 600; margin-bottom: 8px; display: block; }
    .btn-primary { padding: 12px 25px; border: none; background-color: #007bff; color: white; cursor: pointer; border-radius: 8px; font-size: 16px; font-weight: 600; }
    .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    .table th, .table td { padding: 15px; text-align: left; vertical-align: middle; border-bottom: 1px solid #eee; }
    .table th { background-color: #f8f9fa; font-weight: 600; color: #555; }
    .status-badge { padding: 5px 12px; border-radius: 50px; font-size: 12px; font-weight: 600; }
    .status-active { background-color: #d4edda; color: #155724; }
    .status-pending { background-color: #fff3cd; color: #856404; }
    .status-completed { background-color: #e2e3e5; color: #383d41; }
    .actions a { text-decoration: none; display: block; margin-bottom: 5px; color: #007bff; font-weight: 500; }
</style>

<h1 class="page-title">My Seminars</h1>

<div class="panel">
    <h2 class="panel-title">Create a New Seminar</h2>
    <form method="POST" action="my_seminars.php" enctype="multipart/form-data">
        <div class="form-group"><label>Seminar Title *</label><input type="text" name="title" class="form-control" required></div>
        <div class="form-group"><label>Seminar Thumbnail (Image) *</label><input type="file" name="thumbnail" class="form-control" accept="image/*" required></div>
        <div class="form-group"><label>Seminar Description *</label><textarea name="description" class="form-control" rows="4" required></textarea></div>
        <div class="form-group"><label>Price (₹) *</label><input type="number" name="price" step="1" min="99" class="form-control" required></div>
        <button type="submit" name="add_seminar" class="btn-primary">Submit for Approval</button>
    </form>
</div>

<div class="panel">
    <h2 class="panel-title">My Submitted Seminars</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Students / Earning</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($my_seminars as $seminar): ?>
                <tr>
                    <td><?php echo htmlspecialchars($seminar['title']); ?></td>
                    <td>
                        <strong><?php echo $seminar['student_count']; ?></strong> Students<br>
                        <small>Earning: ₹<?php echo number_format($seminar['total_earning'] ?? 0, 2); ?></small>
                    </td>
                    <td><span class="status-badge status-<?php echo strtolower($seminar['status']); ?>"><?php echo $seminar['status']; ?></span></td>
                    <td class="actions">
                        <?php if ($seminar['status'] === 'Active'): ?>
                            <a href="my_seminars.php?action=complete&seminar_id=<?php echo $seminar['id']; ?>" onclick="return confirm('Are you sure you have completed this seminar? This makes the earnings eligible for payout.');">Mark as Completed</a>
                            <a href="view_students.php?seminar_id=<?php echo $seminar['id']; ?>">View Students</a>
                            <a href="../public/seminar_join.php?id=<?php echo $seminar['id']; ?>" target="_blank">Public Link</a>
                        <?php elseif ($seminar['status'] === 'Completed'): ?>
                            <a href="view_students.php?seminar_id=<?php echo $seminar['id']; ?>">View Students</a>
                        <?php else: ?>
                            Awaiting Approval
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>