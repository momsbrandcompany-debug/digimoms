<?php
include 'header.php';

// --- Placeholder data ---
// We will make this dynamic once the sales tracking system is built
$total_earnings = 0.00;
$total_sales_count = 0;
$pending_payments = 0.00;

// This is the Global Referral Link for recruiting sub-partners
$sub_partner_referral_link = "http://localhost/digitalmarket/public/become_a_partner.php?ref=" . $partner_id;

// This is the Global Affiliate Link for tracking sales
$global_affiliate_link = "http://localhost/digitalmarket/public/index.php?ref=" . $partner_id;
?>

<style>
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
    .stat-card { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
    .stat-card h3 { margin: 0 0 10px 0; font-size: 18px; color: #555; }
    .stat-card .amount { font-size: 32px; font-weight: 700; color: #2c3e50; }
    .panel { background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.08); margin-top: 30px; }
    .panel h2 { margin-top: 0; }
    .link-input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; background-color: #f9f9f9; }
</style>

<h1>Dashboard</h1>

<!-- Statistics Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <h3>Total Earnings</h3>
        <p class="amount">₹<?php echo number_format($total_earnings, 2); ?></p>
    </div>
    <div class="stat-card">
        <h3>Total Sales</h3>
        <p class="amount"><?php echo $total_sales_count; ?></p>
    </div>
    <div class="stat-card">
        <h3>Pending Payments</h3>
        <p class="amount">₹<?php echo number_format($pending_payments, 2); ?></p>
    </div>
</div>

<!-- Global Links Panel -->
<div class="panel">
    <h2>Your Referral Links</h2>
    
    <div style="margin-bottom: 20px;">
        <label for="global-affiliate-link"><strong>Global Affiliate Link (for Sales)</strong></label>
        <p style="font-size:14px; color:#555;">Share this link. Any product purchased through this link will earn you a commission.</p>
        <input type="text" id="global-affiliate-link" class="link-input" value="<?php echo htmlspecialchars($global_affiliate_link); ?>" readonly>
        <button onclick="copyToClipboard('global-affiliate-link')" style="margin-top: 10px;">Copy Sales Link</button>
    </div>
    
    <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">

    <div style="margin-bottom: 20px;">
        <label for="sub-partner-link"><strong>Sub-Partner Recruitment Link</strong></label>
        <p style="font-size:14px; color:#555;">Share this link to recruit new partners. You will earn 10% from their sales.</p>
        <input type="text" id="sub-partner-link" class="link-input" value="<?php echo htmlspecialchars($sub_partner_referral_link); ?>" readonly>
        <button onclick="copyToClipboard('sub-partner-link')" style="margin-top: 10px;">Copy Recruitment Link</button>
    </div>
</div>

<script>
    function copyToClipboard(elementId) {
        var copyText = document.getElementById(elementId);
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        document.execCommand("copy");
        alert("Link copied to clipboard!");
    }
</script>

<?php include 'footer.php'; ?>