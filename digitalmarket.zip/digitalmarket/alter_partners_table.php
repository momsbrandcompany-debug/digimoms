<?php
require_once 'db_config.php';

try {
    // SQL statement to add the new column to the 'partners' table
    $sql = "ALTER TABLE partners ADD COLUMN parent_partner_id INT NULL AFTER status";
    
    $pdo->exec($sql);
    
    echo "<h1>Success!</h1><p>The 'parent_partner_id' column has been added to the 'partners' table successfully.</p>";

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not alter the table. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>