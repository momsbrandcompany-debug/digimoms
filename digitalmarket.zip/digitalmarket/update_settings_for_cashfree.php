<?php
require_once 'db_config.php';
try {
    $settings_to_add = [
        'cashfree_app_id' => '',
        'cashfree_secret_key' => '',
        'payment_mode' => 'Test' // Possible values: 'Test', 'Live'
    ];

    $sql = "INSERT INTO settings (setting_key, setting_value) VALUES (:key, :value)
            ON DUPLICATE KEY UPDATE setting_value = :value";
    $stmt = $pdo->prepare($sql);

    foreach ($settings_to_add as $key => $value) {
        $stmt->execute(['key' => $key, 'value' => $value]);
    }

    echo "<h1>Success!</h1><p>The 'settings' table has been updated for Cashfree integration.</p><p>Please go to your Admin Panel -> Site Settings to add your Cashfree App ID and Secret Key.</p>";

} catch (PDOException $e) {
    die("<h1>Error!</h1><p>" . $e->getMessage() . "</p>");
}
?>