<?php
// --- digitalmarket/init.php (FINAL AND ERROR-FREE VERSION) ---

// Step 1: Define Base URL
if (!defined('BASE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    // This will correctly form the base path, e.g., /digitalmarket/
    $script_name = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
    // For XAMPP, this might be something like /digitalmarket/public/, we need to go up one level
    if (strpos($script_name, '/public/') !== false) {
        $script_name = str_replace('/public/', '/', $script_name);
    }
    define('BASE_URL', $protocol . $host . rtrim($script_name, '/\\') . '/');
}

// Step 2: Include the Cashfree Autoloader
// __DIR__ gives the absolute path to the current directory (digitalmarket/)
require_once __DIR__ . '/lib/cashfree.php';

// Step 3: Start or resume the session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Step 4: Define Root Path and Include Database Configuration
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', __DIR__);
}
require_once ROOT_PATH . '/db_config.php';

// Step 5: Affiliate Cookie Tracking Logic
if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    $partner_id = (int)$_GET['ref'];
    setcookie('affiliate_ref', $partner_id, time() + (86400 * 30), "/");
}

// Step 6: Load all website settings into a global variable
try {
    $settings_from_db = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    $site_settings = (object)$settings_from_db;
} catch (PDOException $e) {
    // --- THIS IS THE FIX for the Parse error ---
    // Use the correct key => value syntax for the default object
    $site_settings = (object)[
        'website_name' => 'DigiMoms',
        'website_logo' => '',
        'cashfree_app_id' => '',
        'cashfree_secret_key' => '',
        'payment_mode' => 'Test'
    ];
}
?>