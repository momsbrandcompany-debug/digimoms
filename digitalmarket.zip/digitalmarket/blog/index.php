<?php
require_once '../db_config.php';
$search_query = $_GET['q'] ?? '';

// Base query
$sql = "SELECT bp.title, bp.slug, bp.featured_image, bp.created_at, bc.name as category_name FROM blog_posts bp JOIN blog_categories bc ON bp.category_id = bc.id WHERE bp.status = 'Published'";

// Add search condition if a query exists
if (!empty($search_query)) {
    $sql .= " AND (bp.title LIKE :query OR bp.content LIKE :query)";
}
$sql .= " ORDER BY bp.created_at DESC";

$stmt = $pdo->prepare($sql);
if (!empty($search_query)) {
    $stmt->bindValue(':query', '%' . $search_query . '%');
}
$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Blog - DigiMoms</title>
    <style>
        body{font-family:'Segoe UI',sans-serif;margin:0;background-color:#f9fbfd;color:#333}.container{width:90%;max-width:1200px;margin:0 auto}.navbar{background-color:#fff;padding:15px 0;box-shadow:0 2px 5px rgba(0,0,0,.08)}.navbar-content{display:flex;justify-content:space-between;align-items:center}.navbar .logo{font-size:26px;font-weight:700;color:#007bff}.navbar .nav-links a{color:#333;text-decoration:none;margin:0 18px;font-weight:500}.section{padding:60px 0}.page-title{text-align:center;font-size:42px;margin-bottom:40px;color:#0056b3;font-weight:700}.blog-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:30px}.article-card{background-color:#fff;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,.07);overflow:hidden;text-decoration:none;color:inherit;transition:transform .3s,box-shadow .3s}.article-card:hover{transform:translateY(-8px);box-shadow:0 10px 20px rgba(0,0,0,.1)}.article-card img{width:100%;height:200px;object-fit:cover}.article-content{padding:20px}.article-content h3{font-size:22px;margin:0 0 10px;height:56px;overflow:hidden}.article-content p{color:#777;font-size:14px;margin:0}
        .blog-search{max-width:500px;margin:0 auto 40px;}.blog-search form{display:flex;border:1px solid #ddd;border-radius:50px;padding:5px;}.blog-search input{flex-grow:1;border:none;outline:none;padding:0 15px;font-size:16px;}.blog-search button{background-color:#555;color:#fff;border:none;padding:10px 20px;border-radius:50px;cursor:pointer;}
    </style>
</head>
<body>
    <nav class="navbar"><div class="container navbar-content"><div class="logo">DigiMoms</div><div class="nav-links"><a href="index.php">Home</a><a href="blog.php">Blog</a><a href="#">Partner</a><a href="#">Login</a></div></div></nav>
    <main class="container section">
        <h1 class="page-title">Our Blog & Articles</h1>

        <!-- NEW: Blog Search Form -->
        <div class="blog-search">
            <form action="blog.php" method="GET">
                <input type="text" name="q" placeholder="Search articles..." value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <?php if (!empty($search_query)): ?>
            <h3 style="text-align:center;">Showing results for: "<?php echo htmlspecialchars($search_query); ?>"</h3>
        <?php endif; ?>

        <div class="blog-grid">
            <?php if (count($posts) > 0): ?>
                <?php foreach ($posts as $post): ?>
                <a href="article.php?slug=<?php echo $post['slug']; ?>" class="article-card">
                    <img src="../public/uploads/blog_images/<?php echo htmlspecialchars($post['featured_image']); ?>" alt="">
                    <div class="article-content">
                        <h3><?php echo htmlspecialchars($post['title']); ?></h3>
                        <p>In <strong><?php echo $post['category_name']; ?></strong> - <?php echo date('F j, Y', strtotime($post['created_at'])); ?></p>
                    </div>
                </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="grid-column: 1 / -1; text-align: center;">No articles found.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>