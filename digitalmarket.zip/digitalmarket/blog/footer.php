</main>
    <footer style="text-align:center; padding: 20px; margin-top: 40px; background-color: #1a253c; color: white;">
        <p>&copy; <?php echo date("Y"); ?> DigiMoms. All Rights Reserved.</p>
    </footer>
</body>
</html>