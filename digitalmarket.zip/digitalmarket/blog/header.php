<?php require_once '../init.php'; // Use the main init file ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Blog</title>
    <style>
        /* CSS for the blog section */
        body { font-family: 'Segoe UI', sans-serif; margin: 0; background-color: #f9fbfd; }
        .container { width: 90%; max-width: 1100px; margin: 0 auto; }
        .blog-navbar { background-color: #fff; padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.08); }
        .blog-navbar a { text-decoration: none; color: #333; font-weight: 500; margin-right: 20px; }
        .main-site-btn { background-color: #007bff; color: white !important; padding: 10px 20px; border-radius: 50px; }
    </style>
</head>
<body>
    <nav class="blog-navbar">
        <div class="container" style="display:flex; justify-content:space-between; align-items:center;">
            <a href="index.php" style="font-size:24px; font-weight:bold;">Our Blog</a>
            <div>
                <a href="../public/index.php">Home</a>
                <a href="../public/products.php">Products</a>
                <a href="../public/index.php" class="main-site-btn">Back to Main Site</a>
            </div>
        </div>
    </nav>
    <main>