<?php
include 'header.php';
$slug = $_GET['slug'] ?? '';
if (empty($slug)) die("Post not found.");

$stmt = $pdo->prepare("SELECT bp.*, bc.name as category_name FROM blog_posts bp JOIN blog_categories bc ON bp.category_id = bc.id WHERE bp.slug = :slug AND bp.status = 'published'");
$stmt->execute(['slug' => $slug]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) die("Post not found.");
?>
<style>
    .post-container { max-width: 800px; margin: 50px auto; padding: 30px; background-color: #fff; border-radius: 15px; }
    .post-container h1 { font-size: 42px; }
    .post-container .meta { color: #555; margin-bottom: 20px; }
    .post-container .post-thumbnail { width: 100%; max-height: 400px; object-fit: cover; border-radius: 10px; margin-bottom: 30px; }
    .post-content { font-size: 18px; line-height: 1.8; }
    .post-content img { max-width: 100%; height: auto; border-radius: 10px; } /* Style for images inside the content */
</style>

<div class="container">
    <div class="post-container">
        <h1><?php echo htmlspecialchars($post['title']); ?></h1>
        <p class="meta">
            In <strong><?php echo htmlspecialchars($post['category_name']); ?></strong> | 
            Published on: <?php echo date('d M Y', strtotime($post['created_at'])); ?>
        </p>
        <img class="post-thumbnail" src="../<?php echo htmlspecialchars($post['thumbnail']); ?>" alt="">
        <div class="post-content">
            <?php echo $post['content']; // Outputting raw HTML from TinyMCE ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>