<?php
require_once 'db_config.php';
try {
    $sql = "ALTER TABLE partners 
            ADD COLUMN `trainer_status` ENUM('none', 'pending', 'approved', 'rejected') NOT NULL DEFAULT 'none',
            ADD COLUMN `govt_id_path` VARCHAR(255) NULL";
    $pdo->exec($sql);
    echo "<h1>Success!</h1><p>The 'partners' table has been updated for the Trainer feature.</p>";
} catch (PDOException $e) {
    die("<h1>Error!</h1><p>Could not update table. It might already be updated.</p>");
}