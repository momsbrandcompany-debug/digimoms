<?php
require_once 'db_config.php';

try {
    // SQL statement to add the new column for payment details
    // We use "IF NOT EXISTS" to prevent errors if the column already exists
    // Note: MySQL versions older than 8.0 do not support "ADD COLUMN IF NOT EXISTS"
    // In that case, we check first.

    // Check if the column exists
    $stmt = $pdo->query("SHOW COLUMNS FROM `partners` LIKE 'payment_details'");
    $column_exists = $stmt->fetch();

    if ($column_exists) {
        echo "<h1>Already Fixed!</h1><p>The 'payment_details' column already exists in the 'partners' table.</p>";
    } else {
        // If it doesn't exist, add it
        $sql = "ALTER TABLE partners ADD COLUMN payment_details TEXT NULL AFTER address";
        $pdo->exec($sql);
        echo "<h1>Success!</h1><p>The 'payment_details' column has been added to the 'partners' table successfully.</p>";
    }

} catch(PDOException $e) {
    die("<h1>Error!</h1><p>Could not alter the table. Error message: " . $e->getMessage() . "</p>");
}

unset($pdo);
?>