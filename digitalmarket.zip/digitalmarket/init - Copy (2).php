<?php
// --- digitalmarket/init.php (FINAL VERSION) ---

// Step 1: Define Base URL (Your existing correct code)
if (!defined('BASE_URL')) {
    // ... (The code to dynamically define BASE_URL)
}

// --- THIS IS THE FIX ---
// Step 2: Include the Cashfree Autoloader
// This single line will automatically load all necessary Cashfree classes like 'Cashfree', 'Order', etc.
// It must be placed before any Cashfree code is called.
require_once __DIR__ . '/lib/cashfree.php';
// --- END OF FIX ---

// Step 3: Start or resume the session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Step 4: Define Root Path and Include Database Configuration
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', __DIR__);
}
require_once ROOT_PATH . '/db_config.php';

// Step 5: Affiliate Cookie Tracking Logic (Your existing correct code)
if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    // ... (The cookie setting code)
}

// Step 6: Load all website settings into a global variable (Your existing correct code)
try {
    $settings_from_db = $pdo->query("SELECT setting_key, setting_value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
    $site_settings = (object)$settings_from_db;
} catch (PDOException $e) {
    $site_settings = (object)[
        'website_name' => 'DigiMoms',
        'website_logo' => ''
        // Add default cashfree keys to prevent errors if settings table fails
        'cashfree_app_id' => '',
        'cashfree_secret_key' => '',
        'payment_mode' => 'Test'
    ];
}
?>